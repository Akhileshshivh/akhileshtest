<?php
/**
 * The template for displaying all single posts and attachments
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

 get_header(); ?>
 <?php if(have_posts()){while(have_posts()):the_post();
  ?>

   <div class="container">
       <div class="row">
           <div class="col-xs-12">
               <div class="breadcrumb hidden-xs">
                   <ul>
                       <li class="breadcrumb-item"><?php if(function_exists('bcn_display')){ bcn_display();} ?></li>
                   </ul>
               </div>  <!-- breadcrumb -->

           </div>
       </div>
   </div>


     <section>
       <div class="container single-designer product-spacer">
           <div class="row">
               <div class="col-xs-12 col-sm-5">
                   <div class="designer-figure">
                     <a href="#" title="Designer-name">
                       <?php $deginer_image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'full-thumbnail' ); ?>
                      <img src="<?php echo $deginer_image[0]; ?>" class="img-responsive" alt="name-of-designer">

                     </a>
                   </div>
               </div>
               <div class="col-xs-12 col-sm-7">
                  <div class="designer-details">
                       <h1 class="designer-title"><?php if(!empty(get_the_title())) {  echo get_the_title(); } ?></h1>
                      <?php the_content();?>
                   </div>
               </div>
           </div>
       </div>
   </section>
  <!-- Latest Additions -->
  <?php
            $args   =   array(
                       'post_type'     => 'product',
                       'posts_per_page' => 4,
                       'post_status' => 'publish',
                       'meta_query'    => array(
                           array(
                                 'key' => 'product_designer',
                                 'value' => $post->ID,
                                 'compare' => '=',
                                 'type' => 'NUMERIC'
                           ),
                       )

                    );
                    $query = new WP_Query($args);
                    $count = $query->post_count;
                    $designer_Count  = designer_post_count()

      ?>
  <section>
      <div class="container visible-overflow section-spacer">
          <div class="row">
           <div class="col-xs-12 text-center">
             <?php $more_product = ot_get_option('more_product_title');	if(!empty($more_product)){	?>
             <h2><?php echo $more_product; ?> </h2>
             <?php } ?>
             <?php $sub_designer = ot_get_option('by_this_designer_sub_title');	if(!empty($sub_designer)){	?>
             <h3><?php echo $sub_designer; ?></h3>
               <?php } ?>
           </div>
          </div>
          <div class="row">
                  <?php
                    if ( $query->have_posts() ):
                         while ($query->have_posts()) : $query->the_post();
                        $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'product-home-image');
                        $_product = wc_get_product( get_the_ID() );
                        //$mytaxonomy_posts_count = count($query);
                        //echo "count post :".$mytaxonomy_posts_count;
                    ?>
           <div class="col-xs-6 col-sm-6 col-md-3 pd-adj">
                  <div class="feat-prod-wrap">
                      <figure>
                              <div class="product-thumb">
                          <a href="<?php the_permalink(); ?>">
                            <?php  if(! empty($image)){ ?>
   								        	<span class="image-wrap"><img src="<?php echo $image[0]; ?>" class="img-responsive" alt="<?php the_title(); ?>"></span>
                            <?php  } else   { ?>
   									       <span class="image-wrap"><img src="<?php echo bloginfo('template_directory'); ?>/images/no-image.jpg" class="img-responsive" alt="<?php the_title(); ?>"></span>
   									        <?php } ?>
                          <div class="product-name"><?php the_title(); ?></div>
                            </a>
                              </div>
                              <div class="product-details">
                                  <div class="product-brief">
                                       <?php the_excerpt(); ?>
                                       <div class="price-author"><span class="price"><?php echo get_woocommerce_currency_symbol()." ".$_product->get_price(); ?></span>
                                         | <span class="author"><?php single_post_title(); ?></span></div>
                                  </div>
                                    <a href="<?php the_permalink(); ?>" title="View More" class="readmore-red">View More</a>
                              </div>
                      </figure>
                  </div>
              </div>
            <?php endwhile;wp_reset_query();   ?>
          </div>
          <?php
          if($designer_Count>4){
            ?>
            <div class="row">
              <div class="col-xs-12 text-center cta-spacer">
  			       <?php $products_title = ot_get_option('view_more_products_title');	//if(!empty($products_title)){	?>
                    <a href="<?php echo add_query_arg( array('id' => get_the_ID()), get_permalink(ot_get_option('products_designer_url_t') )); ?>" class="readmore-grey"> <?php echo $products_title; ?></a>
                  <?php //}?>
              </div>
            </div>
          <?php
          }
        ?>
          <?php else:  ?>
          <p><?php echo ot_get_option('error_massage_product'); ?></p>
         <?php endif;  ?>
      </div>
  </section>

<?php endwhile;}?>
 <?php get_footer();?>
