<!-- Featured Products -->
<?php 
if( have_rows('Box') ):
?>
<section>
	<div class="box content">
		<div class="clearfix equalizer">
			<?php $i=0; while ( have_rows('Box') ) : the_row();	?>
			<?php
				$width_class = ($i == '0' ? 'col-sm-6' : 'col-sm-6'); 
				$image = get_sub_field('image');
				$image_url = '';
				if(!empty($image))
				{
					if(empty($image['sizes'][$width_class]))
					{						
						$image_url =  $image['url'];
					}
					else
					{
						$image_url =  $image['sizes'][$width_class];
					}
				}
			?>
			<div class="<?php echo $width_class; ?> item no-pad">
					<div class="image-bg-wrapper" 
					<?php  if(!empty($image_url)) { ?>
					style="background-image:url('<?php echo $image_url; ?>');"
					<?php } ?>
					>
						<figure>
							<?php  if(!empty($image_url)) { ?>
							<img src="<?php echo $image_url; ?>" alt="<?php the_sub_field('title'); ?>" style="opacity:0;" class="img-responsive">
							<?php } ?>
						</figure>
						<div class="content-banner text-center">
							<h2><?php the_sub_field('title'); ?></h2>
							<h3><?php the_sub_field('sub_title'); ?></h3>
							<?php
							if(!empty(get_sub_field('custom_url')))
							{ ?>	
								<a href="<?php the_sub_field('custom_url'); ?>" class="readmore-white-big" title="<?php the_sub_field('button_label'); ?>"> <?php the_sub_field('button_label'); ?> </a>
							<?php } ?>
						</div>
					</div>
			</div>
          <?php $i++; endwhile; ?>

		</div>
		<!-- row ends -->
	</div>
	<!-- box ends -->
</section>
<?php endif; ?>
