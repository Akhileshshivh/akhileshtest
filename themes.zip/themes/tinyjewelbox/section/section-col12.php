<?php 
if( have_rows('full_width_box') ):
while ( have_rows('full_width_box') ) : the_row();
$image = get_sub_field('image');	
$mob_image = get_sub_field('background_image_for_mobile');	 //768
$image_url = '';
if(!empty($image))
{
	if(empty($image['sizes']['col-sm-12']))
	{						
		$image_url =  $image['url'];
	}
	else
	{
		$image_url =  $image['sizes']['col-sm-12'];
	}
}
?>
<style>
<?php if(!empty($mob_image)){ ?> @media only screen and (max-width:768px) {.static-bg-mobile{  background-image: url('<?php echo $mob_image['url']; ?>'); }} <?php } ?>
<?php if(!empty($image)){ ?> @media only screen and (min-width:769px) {.static-desktop-mobile{ background-image: url('<?php echo $image_url; ?>');}} <?php } ?>
</style>
<section>
    <div class="container-fluid static-bg-one static-bg-mobile static-desktop-mobile">
      <div class="box-wrap-static">
        <div class="box-content">
            <h2><?php the_sub_field('title'); ?></h2>
            <h3><?php the_sub_field('sub_title'); ?></h3>
            <?php the_sub_field('description'); ?>
			<?php
			 if(!empty(get_sub_field('custom_url')))
			 { ?>	            
				<a href="<?php the_sub_field('custom_url'); ?>" class="readmore-grey" title="<?php the_sub_field('button_label'); ?>"> <?php the_sub_field('button_label'); ?> </a>
			 <?php } ?>
        </div>
      </div>
    </div>
</section>
<?php endwhile; 
endif;
?>

