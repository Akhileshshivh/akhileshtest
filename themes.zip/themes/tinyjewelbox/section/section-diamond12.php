<?php 

while ( have_rows('full_width_box') ) : the_row();
$image = get_sub_field('image');	
$content_image = get_sub_field('content_image');	

if(!empty($image))
{
?>

	<section class="step-container step-<?php echo $i_diamnmond; ?>-bg" style="background:url(<?php echo $image ;?>);">
		<div class="container-fluid">
			<div class="container">
			  <div class="row">
				<div class="col-xs-12 no-pad ">
				<div class="step-content">
					<h3><?php the_sub_field('title'); ?></h3>
					 <article>
						<?php the_sub_field('description'); ?>
					 </article>	
					 <?php if(!empty($content_image))
					{ ?>
					<div class="step-images">
						<figure> <img src="<?php echo $content_image; ?>" class="img-responsive" alt="Cut"> </figure>
					</div>
					<?php } ?>
				</div>
				   
				</div>
	   
			</div>
			<!-- row ends -->
			</div>
			
		</div>
		<!-- box ends -->
	</section>
  
<?php $i_diamnmond++;  } else if(!empty($content_image)){ ?>

<!--Perfect Diamond for perfect love -->
<section class="perfect-match">
    <div class="container-fluid">
        <div class="container">
          <div class="row">
            <div class="col-xs-12 no-pad ">
                <div class="perfect-match-content">
                    <h3><?php the_sub_field('title'); ?></h3>
                    <article class="clearfix">
                        <div class="short-content">
                            <?php the_sub_field('description'); ?>
                        </div>
						 <?php if(!empty($content_image))
						{ ?>
                        <figure id="mobile-switch"> <img src="<?php echo $content_image; ?>" class="img-responsive"> </figure>
						<?php } ?>
                    </article>
                </div>
            </div>
   
            <!-- item ends -->
        </div>
        <!-- row ends -->
        </div>
        
    </div>
    <!-- box ends -->
</section>
<?php } else { ?>
<section>
<div class="container">
  <div class="row">
	<div class="col-xs-12 no-pad ">
	<div class="schedule-content">
		<h3><?php the_sub_field('title'); ?> </h3>
		<article>
			 <?php the_sub_field('description'); ?>
		</article>
	 </div>
	</div>
</div>
<!-- row ends -->
</div>
</section>
<?php } ?>
<?php endwhile;  ?>
