<?php
/**
 * The Header template for our theme
 *
 * Displays all of the <head>
 *
 * @package WordPress
 * @package Tiny Jewelbox
 * @since Tiny Jewelbox 1.0
 */
?><!DOCTYPE html>
<!--[if IE 7]>
<html class="ie ie7" <?php language_attributes(); ?>>
<![endif]-->
<!--[if IE 8]>
<html class="ie ie8" <?php language_attributes(); ?>>
<![endif]-->
<!--[if !(IE 7) & !(IE 8)]><!-->
<html <?php language_attributes(); ?>>
<!--<![endif]-->
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<title><?php wp_title( '|', true, 'right' ); ?></title>
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
	<?php wp_head(); ?>
	<script>try{Typekit.load({ async: true });}catch(e){}</script>
	<script>//var AJAXURL = 'http://<?php echo $_SERVER['SERVER_NAME']; ?>/wp-admin/admin-ajax.php'; </script>
	<?php
	if(isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == "on") {
		 $http = "https";
	} else {
		$http = "http";
	}	?>
	<script>var AJAXURL = '<?php echo admin_url('admin-ajax.php', $http); ?>';
	IMAGE_URL = '<?php echo get_template_directory_uri(); ?>/images/product_loader.gif';
	var is_product = ''; var sliderison = ''; var historyison = '';
	</script>
</head>
<body>
<header>

    <div class="box top">
        <div class="left">
			<?php
			/*
			 * Icon Mega Menu
			 */
			wp_nav_menu(array('theme_location' => 'top', 'container' => 'ul', 'container_class' => '')); ?>
        </div>

		<div class="right">
			<?php wp_nav_menu(array('theme_location' => 'iconmenu', 'container' => 'ul', 'container_class' => 'touchpoints')); ?>
				<?php if(isset($_GET['s']))
				{
					$key = trim(preg_replace('/\s\s+/', ' ', str_replace("\n", " ", $_GET['s'])));
				}
				else
				{
					$key =  '';
				}

				?>
            <!-- Wishlist Menu Use Have Items class if you have items in wishlist -->
            <div id="wishlist_id" class="wishlist-top have-items" style="display:<?php if(isset($_COOKIE["tiny_wishlist"])) { ?> block; <?php } else { ?> none;<?php } ?>">
                <a href="<?php echo get_permalink(ot_get_option('wishlist_user_url') ); ?>" title="See in Wishlist"><img src="<?php bloginfo('template_directory'); ?>/images/wishlist-icon.png" alt="wishlist"></a>
            </div>
			  <form action="<?php echo home_url( '/' ); ?>" id="searchformtop" class="searchbox" method="get" role="search">

					<input type="text" id="search" name="s" value="<?php echo $key; ?>" autocomplete="off" placeholder="Find it..." class="searchbox-input" onkeyup="buttonUp();">
					<input type="submit" value="OK" id="searchsubmit" class="searchbox-submit">
                    <span class="searchbox-icon">GO</span>
                    <div id="auto"></div>
			 </form>
             <div class="branding-rolex">
							 <a href="<?php echo ot_get_option('rolex_url'); ?>" target="_blank" alt="Rolex">
			 					<?php $rolex_image_desktop = ot_get_option('rolex_desktop_image'); 	if(!empty($rolex_image_desktop)){	?>
			 				 <img src="<?php echo $rolex_image_desktop; ?>" height="40" width="90" class="t-hidden-xs" alt="Rolex" title="Rolex" width="">
			 				 <?php } ?>
			 					<?php $rolex_image_phone = ot_get_option('rolex_phone_image');	if(!empty($rolex_image_phone)){	?>
			 				   <img src="<?php echo $rolex_image_phone;  ?>" height="30" width="42" class="t-visible-xs" alt="Rolex" title="Rolex">
			 				 <?php } ?>
			 				</a>
        </div>
		 </div>
		</div><!-- box ends -->

    <nav class="clearfix">
		<?php  $sitelogo = ot_get_option('sitelogo');		?>
        <div class="box branding">
				<div class="logo">
					<?php if(!empty($sitelogo)) {  ?>
						<a href="<?php echo site_url(); ?>"><img src="<?php echo $sitelogo; ?>" alt="logo"/ ></a>
					<?php } ?>
				</div>
	    </div>
        <!-- box ends -->
         <div id="main-menu-wraper">
            <div class="accordian">
			 <?php
			 /*
			 * Main mega Menu
			 */
			 ?>
              <?php wp_nav_menu(array('theme_location' => 'main', 'container' => 'ul')); ?>
            </div>
            <!-- accordian ends -->
        </div>
        <!-- box ends -->
    </nav>

</header>
