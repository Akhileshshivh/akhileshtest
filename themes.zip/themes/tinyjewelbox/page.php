<?php
/**
 * The template for displaying pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that
 * other "pages" on your WordPress site will use a different template.
 *
 * @package WordPress
 * @subpackage Twenty_Fifteen
 * @since Twenty Fifteen 1.0
 */

get_header(); ?>
<!-- Page Static Banner -->
<section>
    <div class="container-fluid darkgrey-bg static-pages">
        <div class="container">
            <div class="row">
                <div class="col-xs-12">
                    <div class="sp-box-wrap">
											<?php $commentitle=get_field('title'); if(!empty($commentitle)){ ?>
                        <h2><?php echo $commentitle;  ?></h2>
												<?php }?>
												<?php $subtitle=get_field('sub_title'); if(!empty($subtitle)){ ?>
                        <h3> <?php echo $subtitle;  ?> </h3>
												<?php } ?>
										</div>
                </div>
            </div>
        </div>
    </div>
</section>

    <!-- Page Static Content -->
<section>
    <div class="container">
        <div class="row">
            <div class="col-xs-12 content-static-wrap">
              <?php while ( have_rows('section_content') ) : the_row(); ?>
                <div class="content-static">
                  <h3><?php if(!empty(get_sub_field('comment_title'))) { echo get_sub_field('comment_title'); }?></h3>
                <?php if(!empty(get_sub_field('commen_content'))) { echo get_sub_field('commen_content'); }?>
              </div><!-- content-static -->
              <?php endwhile; ?>
            </div>
        </div>
    </div>
</section>



<?php get_footer(); ?>
