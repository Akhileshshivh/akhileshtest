<?php
/**
 * The template for displaying search results pages
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */
if(empty($_GET['s'])) { wp_redirect( get_site_url() );  exit;} 
get_header( 'shop' );
global $woocommerce, $post, $product;
$keyword = trim(preg_replace('/\s\s+/', ' ', str_replace("\n", " ", $_GET['s'])));
?>
<script>
var keyword = '<?php echo $keyword; ?>';
var IMAGE_URL = '<?php echo get_template_directory_uri(); ?>/images/product_loader.gif';
</script>
<input type="hidden" name="paged" id="paged" value="1"/>

    <div class="container">
        <div class="row">
            <div class="col-xs-12">
                <div class="breadcrumb hidden-xs">
                    <ul>
						
					    <?php $total_no_post = totalnoofpost($keyword); 
					    if(strlen($keyword) <= 2)
					    {
							$total_no_post =  0;
						}
                        if(!empty($keyword))
                        { 
                        ?>
                        <li class="breadcrumb-item"><a href="#">SEARCH RESULTS :</a></li>
                     
                        <li class="breadcrumb-item active"><?php echo $keyword; ?> (<?php echo $total_no_post ; ?>)</li>
                        <?php } ?> 
                    </ul>
                </div>
                <!-- breadcrumb -->
                <div class="visible-xs category-name-mobile">
                    <h1><?php echo $keyword; ?></h1> </div>
                <!-- product-name-mobile -->
            </div>
            
        </div>
    </div>
    <section>
        <div class="container visible-overflow product-listing search-results">
		<div class="row equalizer"> 	
		<?php 
		if($total_no_post > 0 && (!empty($keyword)) && (strlen($keyword) > 2))
		{ 
			?>
			<div class="more-info clearfix" style="" id="show-data">					
				<div id="load_searchdata">
				
				</div>
			</div>
			<div id="loader-wrap">
			
			</div>
			<?php 
		}
		else if((empty($keyword)))
		{
			echo '<h3 class="no-result-found">Please Enter your keyword.</h3>';
		}
		else if((strlen($keyword) <= 2))
		{
			echo '<h3 class="no-result-found">Character Limit is 3.</h3>';
		}
		else
		{
            echo '<h3 class="no-result-found"> Sorry No Result Found For Your Search... </h3>';
		}
		?>
		</div>
		</div>
	</section>
<?php 
if($total_no_post > 0 && (!empty($keyword)) && (strlen($keyword) > 2))
{ 
?>
<!-- Will add it enque before final go-->
<script type='text/javascript' src='<?php bloginfo('template_directory'); ?>/js/search.js'></script>
<script>search_result_pagination(1);</script>
<?php } ?>
<?php get_footer( 'shop' ); ?>
