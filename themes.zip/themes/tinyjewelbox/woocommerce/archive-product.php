<?php
/**
* The Template for displaying product archives, including the main shop page which is a post type archive
*
* This template can be overridden by copying it to yourtheme/woocommerce/archive-product.php.
*
* HOWEVER, on occasion WooCommerce will need to update template files and you (the theme developer).
* will need to copy the new files to your theme to maintain compatibility. We try to do this.
* as little as possible, but it does happen. When this occurs the version of the template file will.
* be bumped and the readme will list any important changes.
*
* @see 	    http://docs.woothemes.com/document/template-structure/
* @author 		WooThemes
* @package 	WooCommerce/Templates
* @version     2.0.0
*/

if ( ! defined( 'ABSPATH' ) ) {
exit; // Exit if accessed directly
}

get_header( 'shop' );
global $woocommerce, $post, $product;
$term_id = get_queried_object()->term_id;
$queried_object = get_queried_object();
$total_no_post= $queried_object->count;
do_action( 'woocommerce_before_main_content' );
do_action( 'woocommerce_archive_description' ); ?>
<!-- Breadcrumbs -->
<script>
 var CATID = '<?php echo get_queried_object()->slug; ?>';
 var Cat_id = '<?php echo $term_id; ?>';
 var IMAGE_URL = '<?php echo get_template_directory_uri(); ?>/images/product_loader.gif';
</script>
<input type="hidden" name="filteron" id="filteron" value="0"/>
<input type="hidden" name="pageno" id="pageno" value="1"/>
<div class="container">
	<div class="row">
		<div class="col-xs-12 col-sm-9 col-md-9">
			<div class="breadcrumb hidden-xs">
				<ul>
						<li class="breadcrumb-item"><?php if(function_exists('bcn_display')){ bcn_display();} ?></li>
				</ul>
			</div>

			<div class="visible-xs category-name-mobile">
				<h1><?php echo single_term_title(); ?></h1> 
			</div>
			
		</div>
	   <?php $filter_check = filter_option_availableto(); 
	   if(!empty($filter_check) && $total_no_post >= 1)
	   {
	   ?> 
		<div class="col-xs-12 col-sm-3 col-md-3 mob-pader">
                 <div class="filter-wrap text-right">
                    <a class="filter-btn">FILTER    </a>
                 </div>
        </div>
		<?php } ?>
	</div>
</div>
<?php $filter_check = filter_option_availableto(); 
if(!empty($filter_check) && $total_no_post >= 1) 
{
?> 
<div class="container-fluid fade filter-menu">
   <div class="container nopad-mb">
	   <form action="" method="" class="" id="filter-menu" >
	   <ul class="category-menu panel-group" id="accordion" role="tablist" aria-multiselectable="true">	
			<?php filter_option_available(); ?>
	   </ul>	   
	   </form>
        <div class="text-right">
            <a href="javascript:void(0)" class="clear-all-btn" title="Clear-All"  onclick="loadcategorypage();"> CLEAR ALL</a>
			<a href="javascript:void(0)" class="clear-all-btn" title="apply"  onclick="filtermenu(1);"> APPLY </a>
            <a href="javascript:void(0)" class="clear-all-btn close-menu-btn" title="Close"> X</a>
        </div>
   </div>
</div>
<div class="overlay"><div class="loader">Loading...</div></div>
<?php } ?>   		
<section class="category-list">
	<div class="container visible-overflow product-listing search-results">
		<div class="row equalizer"> 						
			<?php
				wp_reset_query();
				global $post, $wp_query;
				$post_count=1;
				$viewType = 0; 
				$sectionOne = 4;
				$sectionTwo = 1;
				$counter = 0;
				$output='';
				$page_number='';
				$img_url=get_template_directory_uri();
				if(isset($_REQUEST["pageno"])) { $pageno = $_REQUEST["pageno"];  }else { $pageno = 1;}
				$page_number = filter_var($pageno, FILTER_SANITIZE_NUMBER_INT, FILTER_FLAG_STRIP_HIGH);
				$page_number=($page_number ? $page_number : 1);
				/*query_posts(array(
					'post_type' => 'product',
					'product_cat' =>$queried_object->slug,
				//	'showposts' =>10,
					'post_status'=>'publish',
					'paged' =>$page_number,
					'posts_per_page' => 10
				) );*/
				$args = array(
					'post_type' => 'product',
					'posts_per_page' => '10',
					'post_status' => 'publish',
					'paged' => $pageno,
					'tax_query' => array(
									'relation' => 'AND',
									 array(
										'taxonomy' => 'product_cat',
										'field'    => 'slug',
										'terms'    => $queried_object->slug,
									 ),
					),
				);
				$postt = new WP_Query( $args );
				if ( $postt->have_posts() ) 
				{
					
					?>
					<div class="first_div">
					<?php
					while ($postt->have_posts()) : $postt->the_post();
						include(locate_template('content-category.php'));
					endwhile;
					?>
					</div>
					<div class="more-info clearfix load_html" style="" id="show-data">
						
					</div>
					<input type="hidden" value="<?php echo $total_no_post; ?>" id="total_no_post" name="total_no_post"/>		
					
					<div id="loader-wrap">
						<img style="display:none;" class="loading-info" src="<?php echo get_template_directory_uri(); ?>/images/product_loader.gif">
					</div>
					<?php 
				}
				else
				{
					echo "<h3 class='no-result-found'>No Products Found </h3>";
				}
			 ?>


		</div>
	</div>
</section>
<!-- Latest Additions -->
<!-- gaurav Dixit code function will add in enque after taking dev pull -->
<script type='text/javascript' src='<?php bloginfo('template_directory'); ?>/js/archeive.js'></script>
<!-- gaurav Dixit code -->
<?php get_footer( 'shop' ); ?>
