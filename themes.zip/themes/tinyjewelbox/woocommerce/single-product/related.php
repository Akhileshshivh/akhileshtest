<?php
/**
 * Related Products
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/related.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see 	    https://docs.woocommerce.com/document/template-structure/
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     1.6.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

global $product, $woocommerce_loop;

if ( empty( $product ) || ! $product->exists() ) {
	return;
}

if ( ! $related = $product->get_related( $posts_per_page ) ) {
	return;
}

$args = apply_filters( 'woocommerce_related_products_args', array(
	'post_type'            => 'product',
	'ignore_sticky_posts'  => 1,
	'no_found_rows'        => 1,
	'posts_per_page'       => $posts_per_page,
	'orderby'              => $orderby,
	'post__in'             => $related,
	'post__not_in'         => array( $product->id )
) );

$products                    = new WP_Query( $args );
$woocommerce_loop['name']    = 'related';
$woocommerce_loop['columns'] = apply_filters( 'woocommerce_related_products_columns', $columns );

if ( $products->have_posts() ) : ?>

<?php woocommerce_product_loop_start(); ?>

<?php //while ( $products->have_posts() ) : $products->the_post(); ?>

<?php //wc_get_template_part( 'content', 'product' ); ?>

<section>
<div class="container visible-overflow section-spacer-65 product-spacer">
<div class="row">

<div class="col-xs-12 text-center">
<?php 	$related_title = ot_get_option('title'); ?>
<h2><?php  echo substr($related_title, 0, 20);?></h2>
<?php 	$related_subtitle = ot_get_option('sub_title'); ?>
<h3><?php  echo substr($related_subtitle, 0, 20); ?></h3>
</div>
</div>
<div class="row">
<div class="col-xs-12 relatedslider-wrap">
	<ul id="relatedslider" class="owl-carousel">
	<?php while ( $products->have_posts() ) : $products->the_post();
	?> 
	<li class="pd-adj no-scale">
	<div class="feat-prod-wrap">
	<figure>
	<div class="product-thumb"> 
	<a href="<?php the_permalink(); ?>">
	<span class="image-wrap">
	<?php
		echo product_featured_image();
	?>
	</span>
	<div class="product-name"><?php the_title(); ?></div>
	</a> </div>
	<div class="product-details">
	<div class="product-brief">
	<p><?php the_excerpt(); ?></p>
	<div class="price-author"><span class="price">		
	<?php
	$_product = new WC_Product(get_the_ID());
	echo wc_price($_product->get_price_including_tax(1,$_product->get_price()));
	?>

	</span>  <?php if(!empty(get_field('product_designer'))) { ?>
	| <span class="author">By <?php echo getdesigner_name(get_field('product_designer')); ?>  </span>
	<?php } ?></div>
	</div>
	<a href="<?php the_permalink(); ?>" title="View More" class="readmore-red">View More</a>
	</div>
	</figure>
	</div>
	<!-- feat-prod-wrap -->
	</li>
	<?php endwhile; // end of the loop. ?>
	</ul>
	</div>
	</div>
</div>
</section>

<?php woocommerce_product_loop_end(); ?>

<?php endif;

wp_reset_postdata();
