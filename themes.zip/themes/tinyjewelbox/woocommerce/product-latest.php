<?php
global $product;
$productnum = 4;
if(!empty(get_sub_field('product_list_count')))
{
	$productnum = get_sub_field('product_list_count');
}
$args = array(
	'post_type' => 'product',
	'posts_per_page' => $productnum,
	'order' => 'DESC'
);
$product = new WP_Query( $args );
if ( $product->have_posts() ) : ?>
<section>
    <div class="container visible-overflow section-spacer">
        <div class="row">
         <div class="col-xs-12 text-center">
             <?php the_sub_field('add_product_box_title'); ?>
         </div>
        </div>
        <div class="row mobile-handler">
			<?php
			while ($product->have_posts()) : $product->the_post();
           // $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'product-home-image');
            $_product = wc_get_product( get_the_ID() );
			?>
            <div class="col-xs-6 col-sm-6 col-md-3 pd-adj">
                <div class="feat-prod-wrap">
                    <figure>
                            <div class="product-thumb">
                                <a href="<?php the_permalink(); ?>">
									<?php
										echo product_featured_image();
									?>
                                <div class="product-name"><?php the_title(); ?></div>
                                </a>
                            </div>
                            <div class="product-details">

                                <div class="product-brief">
                                  <p><?php echo get_excerpt(); ?></p>
                                     <div class="price-author"><span class="price"><?php echo get_woocommerce_currency_symbol()." ".$_product->get_price(); ?></span>
                                     <?php if(!empty(get_field('product_designer'))) { ?>
										| <span class="author">By <?php echo getdesigner_name(get_field('product_designer')); ?> </span>
                                     <?php } ?>
                                     </div>
                                </div>
                                <a href="<?php the_permalink(); ?>" title="View More" class="readmore-red">View More</a>
                            </div>
                    </figure>
                </div><!-- feat-prod-wrap -->
            </div>
            <?php
            endwhile;
            wp_reset_query();
            ?>

        </div>
        <?php if(get_sub_field('view_more_product_link'))
         { ?>
			<div class="row">
			  <div class="col-xs-12 text-center cta-spacer">
				  <a href="<?php echo the_sub_field('view_more_product_link'); ?>" class="readmore-grey"> View More Products</a>
				</div>
			</div>
        <?php } ?>
    </div>
</section>
<?php endif; ?>
