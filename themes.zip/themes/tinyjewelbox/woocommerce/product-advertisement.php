<?php
$args = array(
	'post_type' => 'productadvertisement',
	'posts_per_page' => 1,
	'orderby'=>'rand',
	'order'=>'ASC',
	'no_found_rows' => true, 
	'update_post_term_cache' => false,
	'update_post_meta_cache' => false,
);	
$productadvertisement = new WP_Query( $args );
if ( $productadvertisement->have_posts() ) : ?>
<section>
<div class="container section-spacer-65-b">
<div class="clearfix equalizer">
	<?php while ($productadvertisement->have_posts()) : $productadvertisement->the_post(); 
	$image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'home_slider');
	?>
		<div class="col-sm-4  item cream-bg no-pad">
				<div class="box-wrap">
					<div class="box-content">					   
						<h2><?php echo substr(get_the_title(), 0, 25); ?></h2>						
						<?php if(!empty(get_field('sub_title'))) { ?><h3> <?php echo substr(get_field('sub_title'), 0, 250); ?></h3><?php } ?>							
						<p><?php the_content(); ?></p>							
						<a href="<?php echo get_field('button_url'); ?>" class="readmore-red-medium"><?php if(!empty(get_field('button_label'))) { echo get_field('button_label'); }else{ echo 'View More'; }   ?></a>							
					</div>
				</div>
		</div>
		<!-- item ends -->
		<div class="col-sm-8 item no-pad">
				<div class="infographic">
					<?php
					if(! empty($image))
					{ ?>	
						<figure style="background-image:url('<?php echo $image[0]; ?>');">
								<a href="<?php echo get_field('button_url'); ?>" title="image-name"><img src="<?php echo $image[0]; ?>" alt="slide" style="opacity:0;" class="img-responsive"></a>
						</figure>
					<?php } ?>	
				</div>
		</div>
   <?php endwhile; 
   wp_reset_query();
   ?>	
		<!-- item ends -->
</div>
<!-- row ends -->
</div>
<!-- box ends -->
</section>
<?php endif; ?>
