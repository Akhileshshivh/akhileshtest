<?php
/**
 * The template for displaying product content in the single-product.php template
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/content-single-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see 	    https://docs.woocommerce.com/document/template-structure/
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     1.6.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
global $woocommerce, $post, $product;
$productid = get_the_ID();

?>

<?php
/**
 * woocommerce_before_single_product hook.
 *
 * @hooked wc_print_notices - 10
 */
 do_action( 'woocommerce_before_single_product' );

 if ( post_password_required() ) {
	echo get_the_password_form();
	return;
 }
?>
<!---- div------>
<div itemscope itemtype="<?php echo woocommerce_get_product_schema(); ?>" id="product-<?php the_ID(); ?>" <?php post_class(); ?>>
    <!---- container------>
    <div class="container">
		<div class="row">
			<div class="col-xs-12">
			   <div class="breadcrumb hidden-xs">
					<ul>
						<li class="breadcrumb-item">	
							<!-- Breadcrumb NavXT 5.6.0 -->
							<span property="itemListElement" typeof="ListItem"><a property="item" typeof="WebPage" title="Go to Tinyjewellbox." href="<?php echo site_url(); ?>" class="home"><span property="name">Home</span></a><meta property="position" content="1"></span> 
							<?php 
							
							$term_list = wp_get_post_terms($post->ID, 'product_cat', array("fields" => "ids"));
							if(!empty($term_list ))
							{
								$parent =  get_term_top_most_parent($term_list[0], 'product_cat');
								if(!empty($parent))
								{ ?>
								&gt; <span property="itemListElement" typeof="ListItem">
									 <a property="item" typeof="WebPage" title="Go to Tinyjewellbox." href="<?php echo get_term_link($parent, 'product_cat'); ?>" class="home">
									  <span property="name">
										<?php echo $parent->name;?> 
									  </span>
									  </a>
									  <meta property="position" content="2"></span> 
							<?php } } ?>
							&gt; <span property="itemListElement" typeof="ListItem"><span property="name"><?php the_title(); ?></span><meta property="position" content="2"></span>																				   
						</li>
					</ul>
				</div>  
				<div class="visible-xs product-name-mobile">
						<h1><?php the_title(); ?></h1>
				</div>
			</div>
		</div>
	</div>
	<!---- /container------>
	<!---- section------>
	<section>
		<div class="container product-spacer">
			<div class="row">
				<!-- Show product-slider -->
				<div class="col-xs-12 col-sm-7">
				<div class="product-detail-slider">
				<!-- Give it any id or class to identify it with: -->
					<div class="clearfix">

                            <ul id="lightSlider">
							<?php 
							if(have_rows('product_gallery'))
							{	
							   $product_image = array();
							   $key = '';
								while(have_rows('product_gallery') ): the_row();
									$thumbnail_image = get_sub_field('image');
									$checkbox = get_sub_field('is_featured');
									$is_video = get_sub_field('is_video');
									if(!empty($checkbox) && $key != 0 )
									{
										array_unshift($product_image,  array($thumbnail_image , $is_video));
									}
									else
									{
										$product_image[$key] = array($thumbnail_image , $is_video);
									}
									$key++;
								endwhile;
								
								foreach($product_image as $slider_image)
								{
										if ($slider_image[1] == 1) {
										?>
										<li data-thumb="<?php bloginfo('template_directory'); ?>/images/video-thumb.jpg">
											<video width="100%" height="660" controls>
											<source src="<?php echo $slider_image[0]; ?>" type="video/mp4">
											<source src="<?php echo $slider_image[0]; ?>" type="video/ogg">
											</video>
										</li>
										<?php

										}
										else
										{
										?>
										  <li data-thumb="<?php echo $slider_image[0]; ?>">
                                              <div class="zoom-section">
                                                 <div class="zoom-small-image">
                                                    <a href='<?php echo $slider_image[0]; ?>' class='cloud-zoom img-responsive' rel="position:'inside',showTitle:false">
                                                        <img src="<?php echo $slider_image[0]; ?>" class="img-responsive" title="" alt=''/>
                                                      </a>
                                                 </div>
                                                 <div class="zoom-desc"></div>
                                               </div><!--zoom-section end-->												
 										   </li>

										<?php 
										}
							    } 
							}
							else
							{ ?>
							  <li data-thumb="<?php echo get_bloginfo('template_directory'); ?>/images/productdetailno-image.jpg">
								  <div class="zoom-section">
									 <div class="zoom-small-image">
										<a href="<?php echo get_bloginfo('template_directory'); ?>/images/productdetailno-image.jpg" class='cloud-zoom img-responsive' rel="position:'inside',showTitle:false">
											<img src="<?php echo get_bloginfo('template_directory'); ?>/images/productdetailno-image.jpg"class="img-responsive" title="" alt=''/>
										  </a>
									 </div>
									 <div class="zoom-desc"></div>
								   </div><!--zoom-section end-->												
							   </li>								
							<?php }
                            ?>
							?>
                                 
                            </ul>
						</div>

				</div>
				    </div>
				<!-- ending product-slider -->
				<div class="col-xs-12 col-sm-5">
				<div class="product-description">
				   <h1 class="hidden-xs"><?php the_title();?></h1>
					<!--- Show  Price -->
					<div class="pricebox">
							<?php
							 $price = $product->get_price_html();
							 if(!empty($price))
								{
								 ?>
								 <span class="price">
									 <?php echo $price; //echo get_woocommerce_currency_symbol();?><?php //echo $price = $product->price;?>
								 </span> 
							 <?php } ?>
							 <!--- Ending Price -->
							 <!--- Show  SKU -->
							 <?php
							 $SKU = $product->get_sku();
							 if(!empty($SKU)){
							 ?>
							  |	<span class="sku">SKU:<?php echo $SKU; ?></span>
							 <?php }  ?>
							 <!--- Ending  SKU -->
							 <!--- Show  available -->
							<?php if(!empty(get_field('product_available_by_special_order'))) 
							{ ?>
							<div class="availabilty">
								[<?php echo get_field('product_available_by_special_order'); ?>]
							</div>
							<?php } ?>
					</div>
					<!--- Ending  available -->

					<!--- Show  Content -->
					<div class="prod-details">
								<?php  
										 $strlen = strlen(get_the_content());  
										the_content();
								?>  
								
					</div>
					<?php if($strlen > 600 )
					{ ?>
					 <div class="toggler-cstm">
                            <a href="javascript:void(0)" class="cntntMore">[...]</a>
                            <a href="javascript:void(0)" class="cntntClose">[...]</a>
                     </div>
                     <?php } ?>
					<!--- Ending  Content -->

					  <!--- Show  Designer -->
					 <?php if(!empty(get_field('product_designer'))) { ?>
						  <div class="author-area">
								<?php echo getdesigner_name(get_field('product_designer')); ?>  <span class="pipe"> | </span> 
								<a href="<?php echo get_permalink(get_field('product_designer')); ?>" title="<?php echo get_field('product_designer_url');?>">
								<?php
								if(empty(get_field('product_designer_title')))
								{
									echo 'More from this designer';
								}
								else
								{
								     echo get_field('product_designer_title'); 
							    } ?> 
								<span class="pd-arw"></span>
								</a>

							</div>
					<?php } ?>
					<!--Ending Designer -->
					<!-- Show product-AVAILABLE -->
					<?php if(have_rows('product_available')){ ?>
							<div class="also-avail">
									<h4>ALSO AVAILABLE</h4>
									<ul>
										<?php
										while( have_rows('product_available') ): the_row();
										$product_availables = get_sub_field('product_available_name');
										if(!empty($product_availables)){
										?>
											  <li><?php echo $product_availables; ?></li>
										<?php } endwhile; ?>
									</ul>

							</div>
					<?php } ?>

					</div>
					<div class="cta-area">
							<ul>
								<?php 	
								$product_buttons = ot_get_option('product_button');
								if(!empty($product_buttons))
								{   ?>
										<li><a href="#<?php //echo ot_get_option('product_button_url'); ?>"><button class="readmore-red-medium email"><?php echo $product_buttons; ?></button></a></li>

								<?php } ?>
								<li id="wishlist_li">
									<?php 
									if(checkproduct_wishlist($productid))
									{ ?>
									<a href="javascript:void(0)" title="Wishlist" onclick="remove_Wishlist('<?php echo $productid; ?>', 'n');"><i class="sprite sprite-wishlist active-wlist"></i> Wishlist</a>
									<?php } 
									else
									{
									?>
									<a href="javascript:void(0)" title="Wishlist" onclick="add_Wishlist('<?php echo $productid; ?>');"><i class="sprite sprite-wishlist"></i> Wishlist</a>
									<?php } ?>
								</li>
								<li><a href="" title="Hint"><i class="sprite sprite-mail"></i> Hint</a></li>
							</ul>
                        	<div class="wishlist_message"></div>
					</div><!-- cta-area -->
			</div>
			</div>
		</div>
	</section>
	<!---- /section------>

	<?php
     		echo do_shortcode('[related_products per_page="12"]');
	?>
	<!-- Show advertisement Box  -->
	<?php get_template_part( 'woocommerce/product', 'advertisement' ); ?>
	<!-- Ending advertisement Box -->
</div>
<!---- /div------>
