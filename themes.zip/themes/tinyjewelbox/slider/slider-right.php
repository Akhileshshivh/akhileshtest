<?php $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'home_slider'); ?> 
<div class="owl-item">
	<div class="col-sm-8 col-sm-push-4 item no-pad">
		<div class="infographic">
			<figure style="background-image:url('<?php echo $image['0']; ?>');">
				<a href="<?php the_field('add_custom_url') ?>" title="<?php the_title(); ?>"><img src="<?php echo $image['0']; ?>" alt="<?php the_title(); ?>" style="opacity:0;" class="img-responsive"></a>
			</figure>
		</div>
	</div>
	<!-- item ends -->
	<div class="col-sm-4 col-sm-pull-8 item red-bg no-pad">
		<div class="box-wrap">
			<div class="box-content">
				<h2><?php the_title(); ?></h2>
				<h3><?php the_content(); ?></h3>
				 <?php 
				 if(!empty(get_field('add_custom_url')))
				 { ?>
					<a href="<?php the_field('add_custom_url') ?>" class="readmore-white" title="See More"> See More </a> 
				 <?php } ?>
		    </div>
		</div>
	</div>
	<!-- item ends -->
</div>
