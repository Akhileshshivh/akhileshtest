<!-- Slider static For homepage -->
<?php if( have_rows('slider_static_box') ): 
 while ( have_rows('slider_static_box') ) : the_row();	
 $background_color_for_box = get_sub_field('box_background_color');
?>
<section>
    <div class="box content">
        <div class="equalizer clearfix">
                    <div class="col-sm-8 item no-pad">
                        <div class="infographic">
							<?php $slide_image = get_sub_field('slides');	?>
                            <figure style="background-image:url('<?php echo $slide_image['url']?>');">
                                <a href="javascript:void(0)" title="image-name"><img src="<?php echo $slide_image['url']?>" alt="" style="opacity:0;" class="img-responsive"></a>
                            </figure>
                        </div>
                    </div>
                    <!-- item ends -->
                    <div class="col-sm-4 item grey-bg no-pad" <?php if(!empty($background_color_for_box)){ ?> style="background: <?php echo $background_color_for_box; ?> none repeat scroll 0 0;" <?php } ?>>
                        <div class="box-wrap">
                            <div class="box-content">
                                <h2><?php the_sub_field('title'); ?></h2>
                                <h3><?php the_sub_field('sub_title'); ?></h3> 
                                <a href="<?php the_sub_field('custom_url'); ?>" class="readmore-silver" title="<?php the_sub_field('button_label'); ?>"> <?php the_sub_field('button_label'); ?> </a> </div>
                        </div>
                    </div>
                    <!-- item ends -->
               
        </div>
        <!-- row ends -->
    </div>
<!-- box ends -->
</section>
<?php 
	endwhile; 
	endif; 
?>
