<!-- Slider For homepage -->

<?php if( have_rows('slider_box') ): 
 while ( have_rows('slider_box') ) : the_row();	
 $background_color_for_box = get_sub_field('box_background_color');
?>
<section>
    <div class="box content">
        <div class="equalizer clearfix">
            <div class="col-sm-8 col-sm-push-4 item no-pad">
                <div id="homeslider" class="owl-carousel homeslider">
					<?php while ( have_rows('slides') ) : the_row();	 ?>
                    <div class="owl-item">
                        <div class="infographic">
							
							<?php $slide_image = get_sub_field('slide_image');	?>
                            <figure style="background-image:url('<?php echo $slide_image['url']?>');">
                                <a href="<?php echo get_sub_field('slide_url'); ?>" title="image-name">
									<img src="<?php echo $slide_image['url']?>" alt="slide" style="opacity:0;" class="img-responsive">
								</a>
                            </figure>
                        </div>
                    </div>
				   <?php endwhile; ?>
                </div>
            </div>

            <!-- item ends -->
            <div class="col-sm-4 col-sm-pull-8 item red-bg no-pad" <?php if(!empty($background_color_for_box)){ ?> style="background: <?php echo $background_color_for_box; ?> none repeat scroll 0 0;" <?php } ?>>
                <div class="box-wrap">
                    <div class="box-content">
                        <h2><?php the_sub_field('title'); ?></h2>
                        <h3><?php the_sub_field('sub_title'); ?></h3> 
						<?php if(!empty(get_sub_field('button_label'))) { ?>
                        <a href="<?php the_sub_field('custom_url'); ?>" class="readmore-white" title="<?php the_sub_field('button_label'); ?>"> <?php the_sub_field('button_label'); ?> </a> 
						 <?php } ?>
                     </div>
                </div>
            </div>
            <!-- item ends -->
        </div>
        <!-- row ends -->
    </div>
    <!-- box ends -->
</section>
<?php 
endwhile; 
endif; 
?>
