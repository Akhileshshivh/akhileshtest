var track_page=1; //track user scroll as page number, right now page number is 1
var loading  = false; 
var windowWidth = jQuery(window).width();
var loading_filter = false; 
loading_filter_nopost = true;
jQuery(window).scroll(function() 
{ 	
	var total_no_post=parseInt(jQuery('#total_no_post').val());
	var box_footer=jQuery('.footer').height();
	if(jQuery(window).scrollTop() >= jQuery(document).height() - (jQuery(window).height()+box_footer))
	{ 
		var filter = jQuery('#filteron').val();
		if(filter == 0 )
		{
			load_contents(total_no_post);
		}
		if(filter == 1 && loading_filter==false && loading_filter_nopost == true )
		{
			var pageno = jQuery('#pageno').val();
			console.log(pageno);
			filtermenupagination(pageno);
		}
		setTimeout(function(){
		},300);
	}
});

function load_contents(total_no_post)
{
if(loading == false)
{
track_page=track_page+1; 
loading=true;
jQuery('.loading-info').show(); //show loading animation
jQuery.ajax({
	url: AJAXURL,
	type:'POST',	
	data:'action=category_product_call_action&catid='+CATID+'&pageno=' + track_page +'&total_no_post='+total_no_post,
	success:function(data)
		   {
			   loading=false;
				if(data.trim().length == 0 || data=="0"){
					jQuery('.loading-info').hide();
					jQuery('#loader-wrap').html("<h2 style='text-align:center;'>That's all folks !</h2>");
					return;
				}
					/*-------- Dynamic Height for Big Box  ------------*/
				   // jQuery.get('<?php echo get_template_directory_uri(); ?>/js/custom.min.js');
				   
				
				jQuery('.loading-info').hide(); //hide loading animation once data is received
				jQuery('.more-info').append(data); //append data into #results element
				jQuery('.more-info .item').addClass("hidden-scroll").viewportChecker({
					classToAdd: 'visible-scroll animated fadeInDown', // Class to add to the elements when they are visible
					offset: 100
				 });
				equalheight('.equalizer .item');
				equalheight('.equalizer .item .clearfix .col-xs-6.col-sm-6.pd-adj');
				if(windowWidth > 767) {
				   //boxHeight();
				}
			}
  }); //ajax call end
}
} //load_contents function end here


/*
 * 
 * Sakshi Ranga 
 * 
 */ 

function filtermenu(paged)
{	
	loading_filter_nopost = true;
	var filtercheckedbox = jQuery("#filter-menu").serialize();
	//alert(filtercheckedbox);
	//updateURL(filtercheckedbox);
	jQuery('#filteron').val(1);
	jQuery('.first_div').hide();
	jQuery('.mainparent').html('');
	jQuery.ajax({
		url: AJAXURL,
		data: {
			'action' : 'filter_menu' ,
			'data': filtercheckedbox, 
			'Cat_id' :Cat_id,
			'paged' : paged, 
		},
		type: 'POST',
		beforeSend: function() {
			jQuery(".load_html").html('');
			overlay();
		},
		success: function(data) {
			jQuery(".overlay").hide(); 
			if(data == 0)
			{
				//alert(1);
				jQuery('.load_html').html("");
				jQuery('#loader-wrap').html("<h2 style='text-align:center;'>That's all folks !</h2>");
				loading_filter_nopost = false;					
			}
			else if(data == 'nodata')
			{
			//	alert(2);
				loadcategorypage();
			}			
			else if(data != 'nodata')
			{
				//alert(3);
				jQuery("#show-data").addClass('filteron');
				jQuery(".load_html").html(data);
				equalheight('.equalizer .item');
				jQuery('#loader-wrap').html("");
				jQuery('#pageno').val(2);
			}
			//jQuery('html, body').animate({
			//scrollTop: jQuery(".product-listing").offset().top -50 }, 1400);		
		}
	});		
	
}	

function filtermenupagination(paged)
{	
	
	var filtercheckedbox = jQuery("#filter-menu").serialize();
//	var pageno = jQuery('#pageno').val();
	if(loading_filter == false)
	{
		loading_filter = true;
		var counter = 1;
		counter = parseInt(+paged + +counter);
	//	console.log(counter);
		jQuery.ajax({
			url: AJAXURL,
			data: {
				'action' : 'filter_menu' ,
				'data': filtercheckedbox, 
				'Cat_id' :Cat_id,
				'paged' : paged, 
			},
			type: 'POST',
			beforeSend: function() {
				jQuery('#loader-wrap').html('<img class="loading-info" src=' + IMAGE_URL + '>');
			},
			success: function(data) {
				loading_filter = false;
				if(data == 0)
				{
				
					loading_filter_nopost = false;	
					//jQuery(".load_html").append("<h2 style='text-align:center;'>That's all folks !</h2>");	
					//jQuery('#pageno').val(1);	
					jQuery('#loader-wrap').html("<h2 style='text-align:center;'>That's all folks !</h2>");
					//return;	
				}
				else
				{	
					jQuery('#pageno').val(counter);
					setTimeout(function(){
					},300);					
					jQuery('#loader-wrap').html('');
					jQuery(".load_html").append(data);				
					equalheight('.equalizer .item');
					//jQuery('#loader-wrap').html('<img class="loading-info" src=' + IMAGE_URL + '>');
				}
			}
		});		
	 }
}
	
function loadcategorypage()
{
	//overlay();
	jQuery("#show-data").removeClass('filteron');
	track_page = 1;
	jQuery('#filter-menu')[0].reset();
	jQuery('#filteron').val(0);
	jQuery('.load_html').html('');	
	jQuery('#pageno').val(1);
	jQuery('#loader-wrap').html('<img  style="display:none;" class="loading-info" src=' + IMAGE_URL + '>');
	jQuery('.first_div').show();
	//jQuery(".overlay").hide(); 
}
 /*----Overlay and scroll Function ---*/

function overlay() { 
    jQuery(".overlay").show(); //hide overlay on popin
}
/*
 function updateURL(params) {
	// console.log(window.location);
      if (history.pushState) {
          var newurl = window.location.href +'&'+params;
          window.history.pushState({path:newurl},'',newurl);
      }
    }
*/
