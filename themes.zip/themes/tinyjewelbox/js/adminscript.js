
jQuery(document).ready(function(){
  //alert("hi");
//  jQuery('.acf-checkbox-list input:first').prop('checked',true);
  jQuery('.acf-checkbox-list input').on('change',function(){
  jQuery('.acf-checkbox-list input').not(this).prop('checked',false);
  });
});
