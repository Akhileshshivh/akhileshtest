jQuery('#homeslider').owlCarousel({
	loop:true, 
	nav:true,
	items:1,
	autoplay:true,
	autoplayTimeout:4000,
	autoplayHoverPause:true,
	autoplaySpeed:2000
});
/* Copy or rename to custom.js and enable in the Control Panel to use */
jQuery( document ).ready( function($){


	var d = new Date(),
	  plus  = d.getHours()+1;
	  d.setHours(plus);
	jQuery('#timers').timepicker().timepicker('setTime', d);


	/*********** Uber menu API****/
	jQuery( '.ubermenu-responsive-toggle' ).on( 'ubermenutoggledopen' , function(e){
	 console.log('toogleopen');
		jQuery('.accordian .ubermenu-responsive-toggle').html('<i class="remove"></i>');
        jQuery("#searchformtop #auto").hide();
        jQuery("#searchformtop").removeClass('searchbox-open');
        jQuery("#search").blur(); 


	});
	jQuery( '.ubermenu-responsive-toggle' ).on( 'ubermenutoggledclose' , function(e){
	   console.log('toogleclose');
		jQuery('.accordian .ubermenu-responsive-toggle').html('<i class="fa fa-bars"></i>');
        jQuery("#searchformtop #auto").hide();
        jQuery(".ubermenu-item").removeClass('ubermenu-active');
        jQuery("#search").blur(); 


	});
	/***** Product filter *****/

	/*jQuery( 'input:checkbox' ).on( 'click' , function(event){
		event.preventDefault();
		var $inputs = $('#filterbox :input');

		$('input[type="checkbox"]:checked').each(function() {
				console.log(this.value);
		}
	});*/

	jQuery(".map").click(function(){
		 jQuery('#myModal-map').modal('show');
	});
	jQuery(".email").click(function(){
		 jQuery('#myModal').modal('show');
	});


var searchRequest = null;
var ajaxSearchRequest = null;
jQuery(function () {
    var minlength = 3;
    jQuery("#search").keyup(function (e) {
           var that = this,
           value = jQuery(this).val();
            if (ajaxSearchRequest) {
                ajaxSearchRequest.abort();
            }
			 if (value.length >= minlength ) {
					ajaxSearchRequest = jQuery.ajax({
										url: AJAXURL,
										data: {
											'action' : 'search_autosearch',
											'keyword': value, 
										},
										type: 'POST',
										beforeSend: function() {
										//	jQuery('#loader-wrap').html('<img class="loading-info" src=' + IMAGE_URL + '>');
										},
										success: function(data) {			
												jQuery("#auto").html('<div class="autosearch"><ul>'+data+'</ul></div>');
												e.stopPropagation();
												jQuery(".searchformtop #auto").show();
										}	
									    });
			}
			else
			{
				jQuery("#auto").html('');		
			}
    });
});

jQuery.validator.addMethod(
    "multiemail",
     function(value, element) {
         if (this.optional(element)) // return true on optional element 
             return true;
         var emails = value.split(/[,]+/); // split element by , and ;
         valid = true;
         for (var i in emails) {
             value = emails[i];
             valid = valid &&
                     jQuery.validator.methods.email.call(this, $.trim(value), element);
         }
         return valid;
     },

    jQuery.validator.messages.email
);
// validate signup form on keyup and submit
$("#wishlist_form").validate({
	rules: {
		gendertype: {required: true},
		firstname: {required: true, minlength :3},
		lastname:  {required: true, minlength :3},
		message:  {required: true, minlength :3},
		telephone: {rangelength:[2,10] },
		email: {required: true, multiemail: true},
		sendergendertype: {required: true},
		senderfirstname: {required: true, minlength :3},
		senderlastname:  {required: true, minlength :3},
		senderemail: {required: true, email: true	},
	},
	errorElement : 'div',
	messages: {
			sendergendertype:{ required: "Please Select" },
			gendertype:{ required: "Please Select" },
			firstname: {
					required: "Please enter a recipient first name",
					minlength: "Your recipient first Name must consist of at least 3 characters"
			},
			lastname: {
					required: "Please enter a recipient last name",
					minlength: "Your recipient last name must consist of at least 3 characters"
			},
			telephone :{
				   rangelength: "Please enter correct recipient phone number. ",
			},
			message: {
					required: "Please enter recipient message",
					minlength: "Your recipient message must consist of at least 3 characters"
			},
			email: {
				    required: "Please enter a valid recipient email address",
				    multiemail: "Please enter a valid Recipient email address"
			},
			senderfirstname: {
					required: "Please enter a sender first name",
					minlength: "Your sender first Name must consist of at least 3 characters"
			},
			senderlastname: {
					required: "Please enter a sender last name",
					minlength: "Your sender last name must consist of at least 3 characters"
			},
			senderemail: "Please enter a valid sender email address",
		
	},
/*	errorPlacement: function(error, element) {
     if(element.attr("name") == "gendertype"){
        error.appendTo($('.errorbox1'));
     }
     if(element.attr("name") == "firstname"){
        error.appendTo($('.errorbox2'));
     }
     if(element.attr("name") == "lastname"){
        error.appendTo($('.errorbox3'));
     }
     if(element.attr("name") == "telephone"){
        error.appendTo($('.errorbox4'));
     }     
     if(element.attr("name") == "message"){
        error.appendTo($('.errorbox6'));
     }
     if(element.attr("name") == "email"){
        error.appendTo($('.errorbox5'));
     }          
     if(element.attr("name") == "emailto[]"){
        error.appendTo($('.errorbox7'));
     }  
     if(element.attr("name") == "friendemail"){
        error.appendTo($('.errorbox8'));
     }       
    },	*/
	submitHandler: function() {
		jQuery.ajax({
			url: AJAXURL,
			data: {
				'action' : 'share_wishlistvia_email',
				'data': jQuery("#wishlist_form").serialize(), 
			},
			type: 'POST',
			beforeSend: function() {
				jQuery('.success-div').html('<img class="loading-info" src=' + IMAGE_URL + '>');
			},
			success: function(data) {		
				//alert(data);
				if(data == 'captcha')
				{
					jQuery('.success-div').html('');
					$('.errorbox9').html('<div class="error">Please verify that you are not a robot.</div>');
					
				}
				else
				{
					$('.errorbox9').html('');
					
					jQuery('.success-div').html(data);
					jQuery('#wishlist_form')[0].reset();
					grecaptcha.reset();
				}
			}	
		});		
	}
});

jQuery('#relatedslider').owlCarousel({
loop:false,
nav:true,
items:4,
margin:30,
autoplay:true,
autoplayTimeout:4000,
autoplayHoverPause:true,
autoplaySpeed:2000,
	responsiveClass:true,
	responsive:{
		0:{
			items:2,
			margin:5,
			nav:true
		},
		768:{
			items:3,
			nav:false
		},
		1024:{
			items:4,
			nav:true,
			loop:false
		}
	}
});

jQuery('#customrelatedslider').owlCarousel({
	loop:false,
	nav:true,
	items:4,
	margin:30,
	autoplay:true,
	autoplayTimeout:4000,
	autoplayHoverPause:true,
	autoplaySpeed:2000,
	responsiveClass:true,
	responsive:{
		0:{
		items:2,
		margin:5,
		nav:true
		},
		768:{
		items:3,
		nav:false
		},
		1024:{
		items:4,
		nav:true,
		loop:false
		}
	}
});

jQuery('.sendfriend input[type=checkbox]').click(function(){
		 jQuery('.showmail').toggleClass('show');
});

if(historyison == 'on')
{
	jQuery(".cd-timeline-content").each(function() {
		if ($(this).find('figure').length == 0) {
			$(this).find('p').addClass('pspace');
		}
	});

	var container = document.querySelector('#historytimeline');
	var msnry = new Masonry(container, {
		itemSelector: '.ht-item'
	});

	function Arrow_Points() {
		var s = jQuery('#historytimeline').find('.ht-item');
		jQuery.each(s, function(i, obj) {
			var posLeft = jQuery(obj).css("left");
			jQuery(obj).addClass('borderclass');
			if (posLeft == "15px") {
				html = "<span class='rightCorner'></span>";
				jQuery(obj).prepend(html);
				jQuery(obj).find('.cd-timeline-content').addClass('align-right');
			} else {
				html = "<span class='leftCorner'></span>";
				jQuery(obj).prepend(html);
				jQuery(obj).find('.cd-timeline-content').addClass('align-left');

			}
		});
	}
	//Hiding existing Arrows
	$('.rightCorner').hide();
	$('.leftCorner').hide();

	Arrow_Points();
	
}
});



function checkvalue()
{
	 if (document.searchformtop.s.value == '')
        return false;
        //when it return false - your form will not submit and will not redirect too
    else
        return true;
}

function add_Wishlist(postid)
{
	jQuery.ajax({
		url: AJAXURL,
		data: {
			'action' : 'wishlist_cookie',
			'postid': postid, 
		},
		type: 'POST',
		beforeSend: function() {
		//	jQuery('#loader-wrap').html('<img class="loading-info" src=' + IMAGE_URL + '>');
		},
		success: function(data) {	
			if(data == 'no')
			{
				jQuery('.wishlist_message').show();
				jQuery('.wishlist_message').html("Wishlist Limit only 20.");
			}
			else if(data == 'wishliston')
			{
				jQuery('#wishlist_id').show();
				jQuery('#wishlist_li').html("<a href='javascript:void(0)' title='Wishlist' onclick='remove_Wishlist("+postid+");'><i class='sprite sprite-wishlist active-wlist'></i> Wishlist</a>");	
				jQuery('.wishlist_message').html("");
				jQuery('.wishlist_message').hide();				
			}
			else
			{	
				//jQuery('.wishlist_message').html("Item added to wishlist")	;
				jQuery('#wishlist_id').show();
				jQuery('#wishlist_li').html("<a href='javascript:void(0)' title='Wishlist' onclick='remove_Wishlist("+postid+");'><i class='sprite sprite-wishlist active-wlist'></i> Wishlist</a>");	
				jQuery('.wishlist_message').html("");	
				jQuery('.wishlist_message').hide();			
			}	
		}
	});
}

function remove_Wishlist(postid, redirect)
{
	jQuery.ajax({
		url: AJAXURL,
		data: {
			'action' : 'remove_wishlist_cookie',
			'postid': postid, 
		},
		type: 'POST',
		beforeSend: function() {
		//	jQuery('#loader-wrap').html('<img class="loading-info" src=' + IMAGE_URL + '>');
		},
		success: function(data) {		
			if(redirect == 'y')
			{
				location.reload(); 
			}
			else if(data == 'wishlistremove')
			{
				jQuery('#wishlist_id').hide();
				jQuery('#wishlist_li').html("<a href='javascript:void(0)' title='Wishlist' onclick='add_Wishlist("+postid+");'><i class='sprite sprite-wishlist'></i> Wishlist</a>");	
				jQuery('.wishlist_message').html("");
				jQuery('.wishlist_message').hide();					
			}
			else
			{	
				//jQuery('.wishlist_message').html("Item removed from wishlist")	;
				jQuery('#wishlist_li').html("<a href='javascript:void(0)' title='Wishlist' onclick='add_Wishlist("+postid+");'><i class='sprite sprite-wishlist'></i> Wishlist</a>");
				jQuery('.wishlist_message').html("");	
				jQuery('.wishlist_message').hide();	
			}
		}	
	});
}
function enablelink()
{
	jQuery('#sharelink').show();
	copyToClipboard(document.getElementById("sharelink"));
}

function copyToClipboard(elem) 
{
	  // create hidden text element, if it doesn't already exist
    var targetId = "_hiddenCopyText_";
    var isInput = elem.tagName === "INPUT" || elem.tagName === "TEXTAREA";
    var origSelectionStart, origSelectionEnd;
    if (isInput) {
        // can just use the original source element for the selection and copy
        target = elem;
        origSelectionStart = elem.selectionStart;
        origSelectionEnd = elem.selectionEnd;
    } else {
        // must use a temporary form element for the selection and copy
        target = document.getElementById(targetId);
        if (!target) {
            var target = document.createElement("textarea");
            target.style.position = "absolute";
            target.style.left = "-9999px";
            target.style.top = "0";
            target.id = targetId;
            document.body.appendChild(target);
        }
        target.textContent = elem.textContent;
    }
    // select the content
    var currentFocus = document.activeElement;
    target.focus();
    target.setSelectionRange(0, target.value.length);
    
    // copy the selection
    var succeed;
    try {
    	  succeed = document.execCommand("copy");
    } catch(e) {
        succeed = false;
    }
    // restore original focus
    if (currentFocus && typeof currentFocus.focus === "function") {
        currentFocus.focus();
    }
    
    if (isInput) {
        // restore prior selection
        elem.setSelectionRange(origSelectionStart, origSelectionEnd);
    } else {
        // clear temporary content
        target.textContent = "";
    }
    return succeed;
}


/*---------------- SLIDER INSIDE THE BOX---------------*/

jQuery( document ).ready(function() {
    var windowWidth = jQuery(window).width();
if(sliderison == 'yes' &&  windowWidth >= 768 )
{	
    
	jQuery('#jssor_1').css('height','800');
               
               
                  jssor_1_slider_init = function() {

            var jssor_1_options = {
              $SlideWidth: 1200,
              $SlideHeight:800,
              $Cols: 2,
              $Align: 360,
              $ArrowNavigatorOptions: {
                $Class: $JssorArrowNavigator$
              },
              $BulletNavigatorOptions: {
                $Class: $JssorBulletNavigator$
              }
            };

            var jssor_1_slider = new $JssorSlider$("jssor_1", jssor_1_options);

            /*responsive code begin*/
            /*remove responsive code if you don't want the slider scales while window resizing*/
            function ScaleSlider() {
                var refSize = jssor_1_slider.$Elmt.parentNode.clientWidth;
                if (refSize) {
                    refSize = Math.min(refSize, 1920);
                    jssor_1_slider.$ScaleWidth(refSize);
                }
                else {
                    window.setTimeout(ScaleSlider, 30);
                }
            }
            ScaleSlider();
            $Jssor$.$AddEvent(window, "load", ScaleSlider);
            $Jssor$.$AddEvent(window, "resize", ScaleSlider);
            $Jssor$.$AddEvent(window, "orientationchange", ScaleSlider);
            /*responsive code end*/
        };
	jssor_1_slider_init();
}
else if (sliderison == 'yes' &&  windowWidth <= 767) {
                     jssor_1_slider_init = function() {

            var jssor_1_options = {
              $SlideWidth: 1920,
              $Cols: 1,
              $SlideHeight:1280,
              $ArrowNavigatorOptions: {
                $Class: $JssorArrowNavigator$
              },
              $BulletNavigatorOptions: {
                $Class: $JssorBulletNavigator$
              }
            };

            var jssor_1_slider = new $JssorSlider$("jssor_1", jssor_1_options);

            /*responsive code begin*/
            /*remove responsive code if you don't want the slider scales while window resizing*/
            function ScaleSlider() {
                var refSize = jssor_1_slider.$Elmt.parentNode.clientWidth;
                if (refSize) {
                    refSize = Math.min(refSize, 1920);
                    jssor_1_slider.$ScaleWidth(refSize);
                }
                else {
                    window.setTimeout(ScaleSlider, 30);
                }
            }
            ScaleSlider();
            $Jssor$.$AddEvent(window, "load", ScaleSlider);
            $Jssor$.$AddEvent(window, "resize", ScaleSlider);
            $Jssor$.$AddEvent(window, "orientationchange", ScaleSlider);
            /*responsive code end*/
        };   
        jssor_1_slider_init();
    }
    
/*---------------- Search-function---------------*/
    
jQuery('body').on('click touchstart', function(){
    
jQuery(".searchbox  #auto").hide();

});
     
jQuery("#search, .searchbox-icon").click(function(e){
e.stopPropagation();
jQuery(".searchbox #auto").show();
});
/*---------------- Search-Open---------------*/
var submitIcon = jQuery('.searchbox-icon');
var inputBox = jQuery('.searchbox-input');
var searchBox = jQuery('.searchbox');
var isOpen = false;
submitIcon.on('click', function(e){
    e.stopPropagation();
    if(isOpen == false){
        searchBox.addClass('searchbox-open');
        inputBox.focus();
        isOpen = true;
    } else {
        searchBox.removeClass('searchbox-open');
        inputBox.focusout();
        isOpen = false;
    }
});  
 submitIcon.mouseup(function(){
        return false;
    });
searchBox.mouseup(function(){
        return false;
    });
jQuery(document).mouseup(function(){
        if(isOpen == true){
            jQuery('.searchbox-icon').css('display','block');
            submitIcon.click();
        }
    });
jQuery('#relatedslider').owlCarousel({
	loop:false,
	nav:true,
	items:4,
	margin:30,
	autoplay:true,
	autoplayTimeout:4000,
	autoplayHoverPause:true,
	autoplaySpeed:2000,
	responsiveClass:true,
	responsive:{
		0:{
			items:2,
			margin:5,
			nav:true
		},
		768:{
			items:3,
			nav:false
		},
		1024:{
			items:4,
			nav:true,
			loop:false
		}
	}
});
if(is_product != "")
{
     jQuery.browser = {};
        (function () {
            jQuery.browser.msie = false;
            jQuery.browser.version = 0;
            if (navigator.userAgent.match(/MSIE ([0-9]+)\./)) {
                jQuery.browser.msie = true;
                jQuery.browser.version = RegExp.$1;
            }
        })();

	jQuery('#lightSlider').lightSlider({
		gallery: true,
		item: 1,
		loop: true,
		slideMargin: 0,
		thumbItem: 4,
			controls: true,
			thumbMargin: 15,
			adaptiveHeight: true,
			onSliderLoad: function() {
						jQueryholder = jQuery(".lSAction").detach(); /* dettaching */
						jQuery(".lSPager").append(jQueryholder); /* Attaching */
			},
		  
			responsive : [
		
				{
					breakpoint:767,
					settings: {
						item:1,
						thumbItem: 4
					  }
				}
			]
	});
}    
});

function buttonUp(){
	var inputVal = jQuery('.searchbox-input').val();
	inputVal = jQuery.trim(inputVal).length;
	if( inputVal !== 0){
		jQuery('.searchbox-icon').css('display','none');    
	} else {
		jQuery('.searchbox-input').val('');
		jQuery('.searchbox-icon').css('display','block');
	}
}

