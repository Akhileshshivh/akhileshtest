var windowWidth = jQuery(window).width();
var loading_filter = false; 
designer_product_nopost = true;
jQuery(window).scroll(function() 
{ 	
	var box_footer=jQuery('.footer').height();
	if(jQuery(window).scrollTop() >= jQuery(document).height() - (jQuery(window).height()+box_footer))
	{ 
		if(loading_filter==false && designer_product_nopost == true )
		{
			paged = jQuery('#paged').val();
			designer_product_pagination(paged);
		}
		setTimeout(function(){
		},300);
	}
});
function designer_product_pagination(paged)
{	
	if(loading_filter == false)
	{
		loading_filter = true;
		var counter = 1;
		counter = parseInt(+paged + +counter);
		jQuery.ajax({
			url: AJAXURL,
			data: {
				'action' : 'designer_product',
				'id': id, 
				'paged' : paged, 
			},
			type: 'POST',
			beforeSend: function() {
				jQuery('#loader-wrap').html('<img class="loading-info" src=' + IMAGE_URL + '>');
			},
			success: function(data) {
				loading_filter = false;
				jQuery('#loader-wrap').html('');
				if(data == 0)
				{
					designer_product_nopost = false;
					if(paged == 1)
					{
						jQuery('#loader-wrap').html("<h2 style='text-align:center;'>No Products !</h2>");
					}
					else
					{
						jQuery('#loader-wrap').html("<h2 style='text-align:center;'>That's all folks !</h2>");
					}
				}
				else
				{	
					jQuery('#paged').val(counter);
					setTimeout(function(){
					},300);					
					jQuery("#load_searchdata").append(data);
					equalheight('.equalizer .item');				
				}
			}
		});	
	 }
}
