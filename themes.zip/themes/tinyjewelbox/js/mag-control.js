(function (root, factory) {
  'use strict'; // eslint-disable-line semi

  var name = 'MagnificentControl'
  if (typeof define === 'function' && define.amd) {
    define(['jquery', './mag-analytics', 'jquery-bridget'], function (jQuery, MagnificentAnalytics) {
      return (root[name] = factory(jQuery, MagnificentAnalytics, root.screenfull))
    })
  } else if (typeof exports === 'object') {
    module.exports = factory(require('jquery'), require('./mag-analytics'), require('jquery-bridget'), require('screenfull'))
  } else {
    root[name] = factory(root.jQuery, root.MagnificentAnalytic, root.screenfull)
  }
}(this, function (jQuery, MagnificentAnalytics, screenfull) {
  'use strict'; // eslint-disable-line semi

  var MagnificentControl = function (element, options) {
    this.element = jQuery(element)
    this.options = jQuery.extend(true, {}, this.options, options)
    this._init()
  }

  MagnificentControl.prototype._init = function () {
    var jQueryel = this.element

    this.jQuerymag = jQuery(this.options.mag)
    this.mag = this.jQuerymag.get(0)
    this.magInst = this.jQuerymag.data('mag')

    var mag = this.mag
    var magInst = this.magInst

    jQueryel.find('[mag-ctrl-zoom-by], [data-mag-ctrl-zoom-by]')
    .on('click', function () {
      var attr = jQuery(this).attr('mag-ctrl-zoom-by') || jQuery(this).attr('data-mag-ctrl-zoom-by')
      var zoomBy = jQuery.parseJSON(attr)
      magInst.zoomBy(zoomBy)
    })

    jQueryel.find('[mag-ctrl-move-by-x], [mag-ctrl-move-by-y], [data-mag-ctrl-move-by-x], [data-mag-ctrl-move-by-y]')
    .on('click', function () {
      var attr = jQuery(this).attr('mag-ctrl-move-by-x') || jQuery(this).attr('data-mag-ctrl-move-by-x')
      var x = attr
      if (x) {
        x = jQuery.parseJSON(x)
      }
      attr = jQuery(this).attr('mag-ctrl-move-by-y') || jQuery(this).attr('data-mag-ctrl-move-by-y')
      var y = attr
      if (y) {
        y = jQuery.parseJSON(y)
      }
      var moveBy = {
        x: x,
        y: y
      }
      magInst.moveBy(moveBy)
    })

    jQueryel.find('[mag-ctrl-fullscreen], [data-mag-ctrl-fullscreen]')
    .on('click', function () {
      if (screenfull) {
        if (screenfull.enabled) {
          screenfull.request(mag)
        }
      }
    })

    jQueryel.find('[mag-ctrl-destroy], [data-mag-ctrl-destroy]')
    .on('click', function () {
      magInst.destroy()
    })
  }

  jQuery.bridget('magCtrl', MagnificentControl)

  if (MagnificentAnalytics) {
    MagnificentAnalytics.track('mag-control.js')
  }

  return MagnificentControl
}))
