<?php
/**
 * The template for displaying all single posts and attachments
 *
 * @package WordPress
 * @subpackage Twenty_Fifteen
 * @since Twenty Fifteen 1.0
 */

get_header(); ?>
<!-- Breadcrumbs -->
<div class="container">
	<div class="row">
		<div class="col-xs-12">
			<div class="breadcrumb hidden-xs">
				<ul>
					<li class="breadcrumb-item"><a href="<?php echo get_permalink(ot_get_option('newsevents_url_page') ); ?>">return to News & Events <i class="brd-icon"></i></a></li>
				</ul>
			</div>  <!-- breadcrumb -->
			
		</div>
	</div>
</div>
<section>
<div class="container single-newsevent product-spacer"> 
	<div class="row">
	<?php
	// Start the loop.
	while ( have_posts() ) : the_post();
	$image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ),'full');
	?>
     <div class="col-xs-12 col-sm-5">
		<div class="designer-figure">
		<?php 
		if(!empty($image))
		{ ?>
		  <a href="<?php the_field('customurl'); ?>" title="<?php the_title(); ?>">
		   <img src="<?php echo $image[0]; ?>" class="img-responsive" alt="<?php the_title(); ?>">  
		  </a>
		<?php 
		} ?>
		</div>
	</div>	

	 <div class="col-xs-12 col-sm-7">
		<div class="news-details">
			<?php  if ( in_category('events') ) { ?>
			<div class="ne-date"><?php the_field('event_date'); ?></div>
			<?php } ?>
			<h1 class="designer-title"> <?php the_title(); ?> </h1>
			<?php the_content(); ?>
		    <a href="<?php the_field('customurl'); ?>" class="readmore-red-medium email">Read in Full</a>
		</div>
     </div>
	
	<?php
		endwhile;
	?>
	</div>
	</div>
</section>

<?php get_footer(); ?>
