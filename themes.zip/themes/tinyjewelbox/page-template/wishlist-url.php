<?php
/*
Template Name: User wishlist via link
*/
get_header(); 
if(isset($_GET["id"]) && (get_option( $_GET["id"] )))
{
?>
	<section>
		<div class="container visible-overflow no-zoom wishlist">

		<div class="row">
			<div class="col-xs-12 text-center">
				<div class="wish-heading">
				<?php while ( have_posts() ) : the_post(); ?>
				<?php the_content(); ?>
				<?php endwhile; wp_reset_query();  ?>
				</div>
			   
			</div>
		</div>

		<div class="row">
			<div class="col-xs-12 ">
			  <div class="row equalizer">
					<?php 
						$products = unserialize(base64_decode(get_option($_GET["id"]))); 
						unset($products[0]);
						foreach( $products as $post) : setup_postdata($post);
						$post = get_post( $post );
						$_product = wc_get_product( $post );
						if(!empty($_product))
						{
						?>
						<?php get_template_part( 'common/common', 'result' ); ?>
						<?php 
						}
						endforeach; 
					?>
			  </div>
			 </div>
		</div>
		</div>
	</section>
<?php 
}
else
{
?>
	<section>
		<div class="container visible-overflow wishlist">
		<div class="row">
			<div class="col-xs-12 text-center">
				<div class="no-heading">
                    <h3 class="no-result-found"> No wishlist available ... </h3>
				</div>
			</div>
		</div>
        </div>
	</section>				
<?php	
}
?>
<?php get_footer(); ?>
