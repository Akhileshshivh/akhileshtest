<?php
/*
Template Name: All about Diamond
*/
get_header();
while ( have_posts() ) : the_post();
if( have_rows('add_row') ):

	 while ( have_rows('add_row') ) : the_row();
			$content_type = get_sub_field('selectcontenttype');
			switch ($content_type) {

			case "WYS":
				the_sub_field('add_content');
			break;

			case "Section":
		//	$i_diamnmond = 1;
				if( have_rows('section_box') ):
				$i_diamnmond = 1;
					while ( have_rows('section_box') ) : the_row(); 
						//get_template_part( 'section/section', 'diamond12' );
						include(locate_template('section/section-diamond12.php'));
					
					endwhile;
				endif;		

			break;

			case "Slider":

				get_template_part( 'common/common', 'staticbox' );
				
			break;
			case "default":

				//get_template_part( 'product/product', 'latest' );

			break;
		}
	endwhile;
	
endif;
endwhile;
?>

<?php get_footer(); ?>
