<?php
/*
Template Name: Common Template
*/
get_header();
 while ( have_posts() ) : the_post(); 

	if( have_rows('add_section') ): 

		   while ( have_rows('add_section') ) : the_row();
				$content_type = get_sub_field('choose_box_type');
				switch ($content_type)
				{
					case "sstaticbox":

					get_template_part( 'common/common', 'staticbox' );

					break;

					case "visitcontent":

					get_template_part( 'common/common', 'visitcontent' );

					break;
				
					case "customcontent":

					get_template_part( 'common/common', 'customcontent' );

					break;
					
					case "menu":

					get_template_part( 'common/common', 'menu' );

					break;

					case "section":

					get_template_part( 'common/common', 'section' );

					break;

					case "policybox":

					get_template_part( 'common/common', 'policybox' );

					break;

					case "contentbox":

					get_template_part( 'common/common', 'contentbox' );

					break;

					case "custom_content":

					get_template_part( 'common/common', 'customcontentbox' );

					break;
					
					case "repair":

					get_template_part( 'common/common', 'repair' );

					break;

					case "department":

					get_template_part( 'common/common', 'department' );

					break;

					case "everything":

					get_template_part( 'common/common', 'everything' );

					break;

					case "faqquestion":

					get_template_part( 'common/common', 'faqquestion' );

					break;

					case "faqanswer":

					get_template_part( 'common/common', 'faqanswer' );

					break;

					case "shotcode":

					get_template_part( 'common/common', 'shortcode' );

					break;

					case "onlyshortcode":

					if(!empty(get_sub_field('only_shortcode')))
					{
						echo do_shortcode(get_sub_field('only_shortcode'));
					}

					break;

					case "boxImageleft":

					get_template_part( 'common/common', 'boxImageleft' );

					break;

					case "boxImageright":

					get_template_part( 'common/common', 'boxImageright' );

					break;
					
					case "imageslider":
					
					get_template_part( 'common/common', 'imageslider' );
					
					break;
					
					case "imagecrousel" :
					
					get_template_part( 'common/common', 'imagecrousel' );
					
					break;					
							
					case "historybox":
					
					get_template_part( 'common/common', 'history' );
					
					break;
						
					default:
					echo '';

				}
		endwhile;

	endif;
endwhile;

get_footer(); ?>
