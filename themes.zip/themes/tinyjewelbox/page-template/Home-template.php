<?php
/*
Template Name: Home Page
*/
get_header();
while ( have_posts() ) : the_post();
if( have_rows('add_row') ):

	 while ( have_rows('add_row') ) : the_row();
			$content_type = get_sub_field('selectcontenttype');
			switch ($content_type) {

			case "WYS":
				the_sub_field('add_content');
			break;

			case "Section":

				 while ( have_rows('section_box') ) : the_row();

						switch (get_sub_field('width')) {

							case "col-sm-4":

								get_template_part( 'section/section', 'col4' );

							break ;
							case "col-sm-6":

								get_template_part( 'section/section', 'col6' );

							break ;
							case "col-sm-8":

								get_template_part( 'section/section', 'col8' );

							break ;
							case "col-sm-12":

								get_template_part( 'section/section', 'col12' );

							break ;

					  }
				 endwhile;

			break;

			case "Slider":

				get_template_part( 'slider/slider', 'center' );

			break;

			case "sstatic_box":

				get_template_part( 'slider/slider', 'staticbox' );

			break;

			case "Latestproduct":

				get_template_part( 'woocommerce/product', 'latest' );

			break;

			case "default":

				//get_template_part( 'product/product', 'latest' );

			break;
		}
	endwhile;
	
endif;
endwhile;
?>

<?php get_footer(); ?>
