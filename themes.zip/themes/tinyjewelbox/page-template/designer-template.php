<?php
/*
Template Name: Designer Page
*/
get_header();
?>
<script>var designer = <?php echo $_POST['designer']; ?></script>
	<section class="archive-designer">
		<div class="container archive-spacer">
				<div class="row">
						<div class="col-xs-12">
								 <div class="designer-details">
         <?php
					if(have_posts()){
								while(have_posts()):the_post();
							  the_content();
								endwhile;
					   }
					 ?>
								</div>
						</div>

				</div>
		</div>
</section>
<!-- Latest Additions -->
<section class="designer-listing">
<div class="container">
	<script>
	var IMAGE_URL = '<?php echo get_template_directory_uri(); ?>/images/product_loader.gif';
	</script>
		<div class="row">
		 <div class="col-xs-12 equalizer" >
			 <input type="hidden" name="paged" id="paged" value="1"/>
				 <ul id="load_searchdata">
				 </ul>
		 </div>

		</div>
</div>
<div id="loader-wrap"></div>
</section>
<!-- Scroll To Top -->
<script type='text/javascript' src='<?php bloginfo('template_directory'); ?>/js/designer.js'></script>
<script>designer_result_pagination(1);</script>

<?php get_footer(); ?>
