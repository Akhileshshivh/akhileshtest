<?php
/*
Template Name: Designer Page with items
*/
get_header();
?>
<script>
var id = <?php echo $_GET['id']; ?>; 
</script>
<?php $title = getdesigner_name($_GET['id']); ?> 
<input type="hidden" name="paged" id="paged" value="1"/>

    <div class="container">
        <div class="row">
            <div class="col-xs-12">
                <div class="breadcrumb hidden-xs">
                    <ul>
					
                        <li class="breadcrumb-item"><a href="#"> Product By :</a></li>
                     
                        <li class="breadcrumb-item active"><?php echo $title; ?></li>
            
                    </ul>
                </div>
                <!-- breadcrumb -->
                <div class="visible-xs category-name-mobile">
                    <h1><?php echo $title; ?></h1> </div>
                <!-- product-name-mobile -->
            </div>
            
        </div>
    </div>
    <section>
        <div class="container visible-overflow product-listing search-results">
		<div class="row equalizer"> 	

			<div class="more-info clearfix" style="" id="show-data">					
				<div id="load_searchdata">
				
				</div>
			</div>
			<div id="loader-wrap">
			
			</div>
		</div>
		</div>
	</section>
<!-- Will add it enque before final go-->
<script type='text/javascript' src='<?php bloginfo('template_directory'); ?>/js/designerpage.js'></script>
<script>designer_product_pagination(1);</script>
<?php get_footer( 'shop' ); ?>
