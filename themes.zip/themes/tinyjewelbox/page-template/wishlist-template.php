<?php
/*
Template Name: User wishlist
*/
get_header(); 
if(isset($_COOKIE["tiny_wishlist"]))
{
?>
	<section>
		<div class="container visible-overflow product-spacer wishlist">

		<div class="row">
			<div class="col-xs-12 text-center">
				<div class="wish-heading">
				<?php while ( have_posts() ) : the_post(); ?>
				<?php the_content(); ?>
				<?php endwhile; wp_reset_query();  ?>
				</div>
			   
			</div>
		</div>

		<div class="row">
			<div class="col-xs-12 ">
			  <div class="row equalizer">
				<?php 
				get_template_part( 'common/wishlist', 'product' ); ?>
			  </div>
			 </div>
		</div>
		</div>
	</section>
	<!-- Page Static Banner -->
	<section>
	<div class="container wishlist-form">
	<div class="row">
	  <div class="col-xs-12 text-center">
		  <div class="share-head">
		   <h3> Share Your Dreams</h3>
		  </div>
		  
	</div>
	<div class="clearfix">
	   <div class="col-xs-12 col-sm-8">
		<div class="contact-form">
			<h4>SEND YOUR WISHLIST VIA EMAIL</h4>
			<form name="wishlist_form" id="wishlist_form" method="post">
			<div class="form-group">
			<label for="title"> Recipients Title</label>
			<select name="gendertype" id="gendertype" class="form-control" id="title" placeholder="Please Select">
			<option selected="" disabled="">Please select</option>
			<option>Ms.</option>
			<option>Mr.</option>
			<option>Mrs.</option>
			</select>
			<div class="errorbox1" ></div>
			</div>
			<div class="form-group">
			<label for="firstname">Recipients First Name*</label>
			<input type="text" class="form-control" id="firstname" name="firstname">
			<div class="errorbox2" ></div>
			</div>
			<div class="form-group">
			<label for="lastname">Recipients Last Name *</label>
			<input type="text" class="form-control" id="lastname" name="lastname">
			<div class="errorbox3" ></div>
			</div>
			<div class="form-group">
			<label for="telephone">Recipients Telephone</label>
			<input type="number"  class="form-control" id="telephone" placeholder="(             )" name="telephone" rangelength="[2,10]">
			<div class="errorbox4" ></div>
			</div>
			<div class="form-group">
			<label for="email">Recipients Email*</label>
			<input type="text" class="form-control" id="email"  name="email">
			<div class="errorbox5" ></div>
			</div>
			<div class="form-group">
			<label for="message">Message to Recipient*</label>
			<textarea class="form-control" id="message" rows="5" name="message"></textarea>
			<div class="errorbox6" ></div>
			</div>
			<!--div class="form-group">
				<label class="checkbox inline"><input type="checkbox" checked="checked" name="emailto[]" value="tjb" required><span><i>Send to Us</i></span></label>
				<label class="checkbox inline sendfriend"><input type="checkbox" name="emailto[]" value="friend"><span><i>Send to Friend</i></span> </label>
			<div class="errorbox7" ></div>
		    </div-->
		    
			<!--div class="form-group showmail">
			<input type="text" name="friendemail" class="form-control" id="friendemail" placeholder=" ENTER Email ADDRESS">
			<div class="errorbox8" ></div>
			</div-->
			<div class="form-group">
			<label for="title"> Senders Title</label>
				<select name="sendergendertype" id="sendergendertype" class="form-control" id="title" placeholder="Please Select">
				<option selected="" disabled="">Please select</option>
				<option>Ms.</option>
				<option>Mr.</option>
				<option>Mrs.</option>
				</select>
				<div class="errorbox1" ></div>
			</div>
			<div class="form-group">
				<label for="firstname">Senders First Name* *</label>
				<input type="text" class="form-control" id="senderfirstname" name="senderfirstname">
				<div class="errorbox12" ></div>
			</div>
			<div class="form-group">
				<label for="lastname">Senders Last Name *</label>
				<input type="text" class="form-control" id="senderlastname" name="senderlastname">
				<div class="errorbox13" ></div>
			</div>
			<div class="form-group">
			<label for="email">Senders Email*</label>
			<input type="email" class="form-control" id="senderemail"  name="senderemail">
			<div class="errorbox14" ></div>
			</div>						
			<div class="form-group">
				<div class="g-recaptcha" data-sitekey="<?php echo ot_get_option('g_site_key'); ?>"></div>
				<div class="errorbox14" ></div>
			</div>
			<input type="submit" class="readmore-red-big-image" value="send" /> 
			<div class="success-div"></div>
			</form>
		</div> 
	   </div>
		
	   <div class="col-xs-12 col-sm-4 ">
		   <div class="sharelink">
			<h4>Share with a link:</h4>
			<p>Share with a link Or share your wishlist with a link! Click the button below to copy the unique URL for your wishlist. Then send to who ever needs a little hint. 
			</p>
			   <p>
			Anyone with the link can view the wishlist. The list will remain active until you clear your internet cache and cookies. </p>
			<?php $uniqkey = wishlistuniquekey(); ?> 
			<a href="javascript:void(0)" class="share-link-btn" onclick="enablelink()">Copy link</a>
               <div class="form-group">
               <input type="text" id="sharelink" class="form-control copy-input" name="sharelink" value="<?php echo  add_query_arg( array('id' => $uniqkey), get_permalink(ot_get_option('share_link') )); ?>" style="display:none;"/>
               </div>
		   </div>
		
	   </div>
	</div>
	<!-- row ends -->
	</div>
	<!-- box ends -->
	</div>
	<!-- wishlist-forms ends -->
	</section>
<?php 
}
else
{
?>
	<section>
		<div class="container visible-overflow wishlist">
		<div class="row">
			<div class="col-xs-12 text-center">
				<div class="wish-heading">
					No product in the wishlist
				</div>
			</div>
		</div>
	</section>				
<?php	
}
?>
<?php get_footer(); ?>
