<?php
/**
* Function:- tinyjewlbox_setup
* Type :- Predefined Action
* Purpose:- Include Menus and thumbnail setting at the Intial stage.
* Returns: Menu , meta tites and thumbnail setting in the admin panel
**/
function tinyjewlbox_setup() {

	//add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'title-tag' );
    register_nav_menu( 'top', __( 'Top Menu', 'tinyjewlbox' ) );
    register_nav_menu( 'iconmenu', __( 'Icon Menu', 'tinyjewlbox' ) );
    register_nav_menu( 'main', __( 'Main Menu', 'tinyjewlbox' ) );
    register_nav_menu( 'FooterMenuOne', __( 'Footer Menu One', 'tinyjewlbox' ) );
    register_nav_menu( 'FooterMenuTwo', __( 'Footer Menu Two', 'tinyjewlbox' ) );
    register_nav_menu( 'FooterMenuThree', __( 'Footer Menu Three', 'tinyjewlbox' ) );
    register_nav_menu( 'SocialMenu', __( 'Social Menu', 'tinyjewlbox' ) );
    add_theme_support( 'post-thumbnails' );
	add_image_size( 'home_slider', '945', '532' );
	add_image_size( 'social_bootom_box', '200', '200' );
	add_image_size( 'col-sm-4', '644', '560', true ); //644*560
	add_image_size( 'col-sm-6', '966', '560', true ); //966*560
	add_image_size( 'col-sm-8', '1268', '560', true ); //1268*560
	add_image_size( 'col-sm-12', '1920', '560', true ); //1920*560
	add_image_size( 'product-home-image', '296', '311', true );
	add_image_size( 'sectionbox', '640', '430', true ); //1920*560
	add_image_size( 'single-post-thumbnail', '264', '264', true ); //1920*560
	add_image_size( 'full-thumbnail', '450', '450', true ); //1920*560
}
add_action( 'after_setup_theme', 'tinyjewlbox_setup' );

/**
* Function:- tinyjewlbox_setup
* Type :- Predefined Action
* Purpose:- Include Menus and thumbnail setting at the Intial stage.
* Returns: Menu , meta tites and thumbnail setting in the admin panel
**/
function tinyjewlbox_scripts_styles() {
    global $map_key;
    $map_key = ot_get_option('key_api');
	if(isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == "on") {
		 $http = "https";
	} else {
		$http = "http";
	}
	wp_enqueue_style( 'tinyjewlbox-stylesheet', get_stylesheet_uri() );
	wp_enqueue_style( 'tinyjewlbox-owlcarousel', get_template_directory_uri() . '/css/owl.carousel.min.css', array(), '' );
    wp_enqueue_style( 'tinyjewlbox-datepiker', get_template_directory_uri() . '/css/jquery.timepicker.css', array(), '' );
    wp_enqueue_style( 'tinyjewlbox-timelinecss', get_template_directory_uri() . '/css/timeline.css', array(), '' );
	wp_enqueue_style( 'tinyjewlbox-themecss', get_template_directory_uri() . '/css/theme.css', array(), '' );
	//if single product//
	if(is_product())
	{
    wp_enqueue_style( 'tinyjewlbox-lightslider', get_template_directory_uri() . '/css/lightslider.css', array(), '' );
	}
	//if single product//
	wp_enqueue_style( 'tinyjewlbox-fontcss', $http.'://fonts.googleapis.com/css?family=Oxygen:400,700%7CEconomica:400,700', array(), '' );
	wp_enqueue_style( 'tinyjewlbox-date', $http.'://code.jquery.com/ui/1.9.2/themes/base/jquery-ui.css', array(), '' );
	/*****************Js section in footer*********************/
	wp_enqueue_script( 'tinyjewlbox-typekitfont-js', $http.'://use.typekit.net/uvo3xdg.js', array( 'jquery' ), '', false );
	wp_enqueue_script( 'tinyjewlbox-bootstrap-js', get_template_directory_uri() . '/js/bootstrap.min.js', array( 'jquery' ), '', true );
	wp_enqueue_script( 'tinyjewlbox-owl-crousel-js', get_template_directory_uri() . '/js/owl.carousel.min.js', array( 'jquery' ), '', true );
	/*****************Product page*****************************/
	if(is_product())
	{
	wp_enqueue_script( 'tinyjewlbox-modern-js', get_template_directory_uri() . '/js/modernizr.custom.js', array( 'jquery' ), '', true );
	wp_enqueue_script( 'tinyjewlbox-lightslider', get_template_directory_uri() . '/js/lightslider.min.js', array( 'jquery' ), '', true );
    wp_enqueue_script( 'tinyjewlbox-cloud-zoom', get_template_directory_uri() . '/js/cloud-zoom.1.0.2.min.js', array( 'jquery' ), '', true );

	}
	wp_enqueue_script( 'tinyjewlbox-masonry.pkgd.min.js', get_template_directory_uri() . '/js/masonry.pkgd.min.js', array( 'jquery' ), '', true );
	wp_enqueue_script( 'tinyjewlbox-custom-js', get_template_directory_uri() . '/js/custom.min.js', array( 'jquery' ), '', true );
	wp_enqueue_script( 'tinyjewlbox-datepiker-js', get_template_directory_uri() . '/js/jquery.timepicker.js', array( 'jquery' ), '', true );
    wp_enqueue_script( 'tinyjewlbox-date-js', $http.'://code.jquery.com/ui/1.9.2/jquery-ui.js', array( 'jquery' ), '', false );
	wp_enqueue_script( 'tinyjewlbox-jqueryvalidate-js', get_template_directory_uri() . '/js/jquery.validate.js', array( 'jquery' ), '', true );
	wp_enqueue_script( 'tinyjewlbox-jssor.slider-22.2.16.min.js', get_template_directory_uri() . '/js/jssor.slider-22.2.16.min.js', array( 'jquery' ), '', true );
	wp_enqueue_script( 'tinyjewlbox-theme-js', get_template_directory_uri() . '/js/theme.js', array( 'jquery' ), '', true );
    wp_enqueue_script( 'tinyjewlbox-googlefont-js', $http.'://ajax.googleapis.com/ajax/libs/webfont/1.5.3/webfont.js', array( 'jquery' ), '', false );
	wp_enqueue_script( 'tinyjewlbox-googlemap-js', $http.'://maps.googleapis.com/maps/api/js?libraries=places&key='.$map_key, array( 'jquery' ), '', true );
	/****************** tinyjewelbox wishlist************************/

}
add_action( 'wp_enqueue_scripts', 'tinyjewlbox_scripts_styles' );

add_action( 'init', 'jk_remove_wc_breadcrumbs' );
function jk_remove_wc_breadcrumbs() {
    remove_action( 'woocommerce_before_main_content', 'woocommerce_breadcrumb', 20, 0 );
}

function get_excerpt(){
	$excerpt = get_the_content();
	$excerpt = preg_replace(" ([.*?])",'',$excerpt);
	$excerpt = strip_shortcodes($excerpt);
	$excerpt = strip_tags($excerpt);
	$excerpt = substr($excerpt, 0, 70);
	return $excerpt;
}


function implement_category_ajax(){
	         global $post, $wp_query;
	         $post_count=1;
			 $queried_object = get_queried_object();
			 $total_no_post= $queried_object->count;
			 $viewType = 0;
			 $sectionOne = 4;
			 $sectionTwo = 1;
			 $counter = 0;
			 $output='';
			 $page_number='';
			 $img_url=get_template_directory_uri();
			 $total_no_post=$_REQUEST['total_no_post'];
			 $page_number = filter_var($_REQUEST["pageno"], FILTER_SANITIZE_NUMBER_INT, FILTER_FLAG_STRIP_HIGH);
/*			 query_posts(array(
				 'post_type' => 'product',
				 'product_cat' =>$_REQUEST['catid'],
				 'post_status' => 'publish',
				 'showposts' =>10,
				 'paged' =>$page_number
			  ) );
*/
				$args = array(
					'post_type' => 'product',
					'posts_per_page' => '10',
					'post_status' => 'publish',
					'paged' => $page_number,
					'tax_query' => array(
									'relation' => 'AND',
									 array(
										'taxonomy' => 'product_cat',
										'field'    => 'slug',
										'terms'    => $_REQUEST['catid'],
									 ),
					),
				);
				$postt = new WP_Query( $args );
				if ( $postt->have_posts() )
				{

				 while ($postt->have_posts()) : $postt->the_post();
					include(locate_template('content-category.php'));
				  endwhile;
			   }
		    die();
	}
add_action('wp_ajax_category_product_call_action', 'implement_category_ajax');
add_action('wp_ajax_nopriv_category_product_call_action', 'implement_category_ajax');//for users that are not logged in.

/*------ Department Team ----*/
add_action('init', 'TeamMembers_init');

function TeamMembers_init()
{
    //Labels for cusotm post type.
    $TeamMembers_labels = array(
        'name' => _x('Team Members', 'post type general name'),
        'singular_name' => _x('TeamMembers', 'post type singular name'),
        'all_items' => __('All TeamMembers'),
        'add_new' => _x('Add new TeamMembers', 'TeamMembers'),
        'add_new_item' => __('Add new TeamMembers'),
        'edit_item' => __('Edit TeamMembers'),
        'new_item' => __('New TeamMembers'),
        'view_item' => __('View TeamMembers'),
        'search_items' => __('Search in TeamMembers'),
        'not_found' =>  __('No TeamMembers found'),
        'not_found_in_trash' => __('No TeamMembers found in trash'),
        'parent_item_colon' => ''
    );

//Arguments
    $args = array(
        'labels' => $TeamMembers_labels,
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'query_var' => true,
        'rewrite' => true,
        'capability_type' => 'post',
        'hierarchical' => false,
        'menu_position' => 5,
        'supports' => array('title','editor','custom-fields'),
        'taxonomies' => array( 'TeamMembers_cat' ),
        'has_archive' => 'TeamMembers'
    );
    register_post_type('TeamMembers',$args);
}
add_action( 'init', 'TeamMembers_create_taxonomies', 0 );

function TeamMembers_create_taxonomies()
{
    // TeamMembers Categories
    register_taxonomy('TeamMembers_cat',array('TeamMembers'),array(
        'hierarchical' => true,
        'label' => 'Team Members Categories',
        'singular_name' => 'TeamMembers Category',
        'show_ui' => true,
        'query_var' => true,
        'rewrite' => array('slug' => 'TeamMembers_cat' )
    ));
}

/**
* Function:- tiny_remove_ver_css_js
* Type :- Predefined Filter
* Purpose:- to remove ?ver from css and js.
* Returns: front end link and script tag without ver in the url
**/

function tiny_remove_ver_css_js( $src ) {
	if ( strpos( $src, 'ver=' ) )
		$src = remove_query_arg( 'ver', $src );
	return $src;
}
add_filter( 'style_loader_src', 'tiny_remove_ver_css_js', 9999 );
add_filter( 'script_loader_src', 'tiny_remove_ver_css_js', 9999 );


// Add new post type for Map upon WordPress initialization
add_action('init', 'Map_init');

function Map_init()
{
    //Labels for cusotm post type.
    $Map_labels = array(
        'name' => _x('Map', 'post type general name'),
        'singular_name' => _x('Map', 'post type singular name'),
        'all_items' => __('All Map'),
        'add_new' => _x('Add new Map', 'Map'),
        'add_new_item' => __('Add new Map'),
        'edit_item' => __('Edit Map'),
        'new_item' => __('New Map'),
        'view_item' => __('View Map'),
        'search_items' => __('Search in Map'),
        'not_found' =>  __('No Map found'),
        'not_found_in_trash' => __('No Map found in trash'),
        'parent_item_colon' => ''
    );

//Arguments
    $args = array(
        'labels' => $Map_labels,
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'query_var' => true,
        'rewrite' => true,
        'capability_type' => 'post',
        'hierarchical' => false,
        'menu_position' => 5,
        'supports' => array('title','custom-fields'),
        'taxonomies' => array( 'Map_cat' ),
        'has_archive' => 'Map'
    );
    register_post_type('Map',$args);
}


//ADD a Header Icon massage post Type
// Add new post type for popupsetting upon WordPress initialization
add_action('init', 'popupsetting_init');

function popupsetting_init()
{
	 //Labels for cusotm post type.
	 $popupsetting_labels = array(
			 'name' => _x('Popup Setting', 'post type general name'),
			 'singular_name' => _x('popupsetting', 'post type singular name'),
			 'all_items' => __('All popupsetting'),
			 'add_new' => _x('Add new popupsetting', 'popupsetting'),
			 'add_new_item' => __('Add new popupsetting'),
			 'edit_item' => __('Edit popupsetting'),
			 'new_item' => __('New popupsetting'),
			 'view_item' => __('View popupsetting'),
			 'search_items' => __('Search in popupsetting'),
			 'not_found' =>  __('No popupsetting found'),
			 'not_found_in_trash' => __('No popupsetting found in trash'),
			 'parent_item_colon' => ''
	 );

//Arguments
	 $args = array(
			 'labels' => $popupsetting_labels,
			 'public' => true,
			 'publicly_queryable' => true,
			 'show_ui' => true,
			 'query_var' => true,
			 'rewrite' => true,
			 'capability_type' => 'post',
			 'hierarchical' => false,
			 'menu_position' => 5,
			 'supports' => array('title','custom-fields'),
			 'taxonomies' => array( 'popupsetting_cat' ),
			 'has_archive' => 'popupsetting'
	 );
	 register_post_type('popupsetting',$args);
}
// Add new post type for Map Section  initialization

function my_acf_google_map_api( $api ){
		$api['key'] = 'AIzaSyC3T2Jwtyr4dqnG-qqB1qfqsls8iaQndko'; //$map_key;; //
	return $api;
}

add_filter('acf/fields/google_map/api', 'my_acf_google_map_api');

function map_shortcode_save( $post_id )
{
	global $post_id;
	$post = get_post( $post ) ;
	if($post->post_type == "map" && (is_admin))
	{
			$shortcode = "[MAP id='".$post_id."']";
			//add_post_meta($post_id,'_shortcode', $shortcode);
			update_field('shortcode', $shortcode , $post_id);
	}
}
add_action( 'save_post', 'map_shortcode_save' );


function format_value_for_api_wysiwyg( $value, $post_id, $field )
{
	$value = apply_filters( 'the_content', $value );
	return $value;
}
add_filter('acf/format_value_for_api/type=wysiwyg', 'format_value_for_api_wysiwyg', 10, 3);

//---------- Designer Post Type --------///


add_action('init', 'designer_init');

function designer_init()
{
    //Labels for cusotm post type.
    $designer_labels = array(
        'name' => _x('Designer', 'post type general name'),
        'singular_name' => _x('designer', 'post type singular name'),
        'all_items' => __('All designer'),
        'add_new' => _x('Add new designer', 'designer'),
        'add_new_item' => __('Add new designer'),
        'edit_item' => __('Edit designer'),
        'new_item' => __('New designer'),
        'view_item' => __('View designer'),
        'search_items' => __('Search in designer'),
        'not_found' =>  __('No designer found'),
        'not_found_in_trash' => __('No designer found in trash'),
        'parent_item_colon' => ''
    );

//Arguments
    $args = array(
        'labels' => $designer_labels,
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'query_var' => true,
        'rewrite' => true,
        'capability_type' => 'post',
        'hierarchical' => false,
        'menu_position' => 5,
        'supports' => array('title','editor','author','thumbnail','excerpt','comments','custom-fields'),
        'taxonomies' => array( 'designer_cat' ),
        'has_archive' => 'designer'
    );
    register_post_type('designer',$args);
}

/**
* Function:- wp_ajax_designer_result_pagination
**/

add_action( 'wp_ajax_designer_result_pagination', 'wp_ajax_designer_result_pagination' );
add_action( 'wp_ajax_nopriv_designer_result_pagination', 'wp_ajax_designer_result_pagination' );

function wp_ajax_designer_result_pagination()
{
	 global $wpdb, $post;
	 	 $args = array(
	 	 'post_type' => 'designer',
	 	 'posts_per_page' => 8,
	 	 'order' => 'DESC',
		 'paged' => $_POST['paged']
	  );
	 	$designer= new WP_Query( $args );
		if ( $designer->have_posts() ) :
	 	while ($designer->have_posts()) : $designer->the_post();
   ?>
	<li class="item">
		 <a href="<?php the_permalink(); ?> " title="Designer-name">
			   <?php
				    $deginer_image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'single-post-thumbnail' );
             if(!empty($deginer_image)){
					?>
				 <figure> <img src="<?php echo $deginer_image[0]; ?>" class="img-responsive"> </figure>
				 <?php } ?>

				 <figcaption><?php the_title(); ?></figcaption>
		 </a>
	 </li>
<?php
	endwhile; endif;
		 die;
	}
add_filter( 'wpcf7_validate_text*', 'custom_text_confirmation_validation_filter', 20, 2 );
add_filter( 'wpcf7_validate_select', 'custom_text_confirmation_validation_filter', 20, 2 );
function custom_text_confirmation_validation_filter( $result, $tag ) {
    $tag = new WPCF7_FormTag( $tag );
    date_default_timezone_set('Asia/Kolkata');
    if ( 'menu-766' == $tag->name ) {
			$date = $_POST['text-192'].' '.$_POST['menu-766'];
		    $newDate = date("Y-m-d H:i:s", strtotime($date));
		    $new = strtotime($newDate);
			$check_time = humanTiming ($new);
			if(isset($_POST['menu-766']) && $check_time != '1 second')
			{
				$result->invalidate( $tag, 'Please choose correct date and time slot.' );
			}
    }

    return $result;
}

function humanTiming ($time)
{
	date_default_timezone_set('Asia/Kolkata');
    $time = time() - $time; // to get the time since that moment
    $time = ($time<1)? 1 : $time;
    $tokens = array (
        31536000 => 'year',
        2592000 => 'month',
        604800 => 'week',
        86400 => 'day',
        3600 => 'hour',
        60 => 'minute',
        1 => 'second'
    );

    foreach ($tokens as $unit => $text) {
        if ($time < $unit) continue;
        $numberOfUnits = floor($time / $unit);
        return $numberOfUnits.' '.$text.(($numberOfUnits>1)?'s':'');
    }

}

add_action('init', 'faq_init');

function faq_init()
{
    //Labels for cusotm post type.
    $faq_labels = array(
        'name' => _x('FAQ', 'post type general name'),
        'singular_name' => _x('faq', 'post type singular name'),
        'all_items' => __('All faq'),
        'add_new' => _x('Add new faq', 'faq'),
        'add_new_item' => __('Add new faq'),
        'edit_item' => __('Edit faq'),
        'new_item' => __('New faq'),
        'view_item' => __('View faq'),
        'search_items' => __('Search in faq'),
        'not_found' =>  __('No faq found'),
        'not_found_in_trash' => __('No faq found in trash'),
        'parent_item_colon' => ''
    );

//Arguments
    $args = array(
        'labels' => $faq_labels,
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'query_var' => true,
        'rewrite' => true,
        'capability_type' => 'post',
        'hierarchical' => false,
        'menu_position' => 5,
        'supports' => array('title','editor','author','thumbnail','excerpt','comments','custom-fields'),
        'taxonomies' => array( 'faq_cat' ),
        'has_archive' => 'faq'
    );
    register_post_type('faq',$args);
}

add_action('init', 'history_init');

function history_init()
{
    //Labels for cusotm post type.
    $history_labels = array(
        'name' => _x('History', 'post type general name'),
        'singular_name' => _x('History', 'post type singular name'),
        'all_items' => __('All History'),
        'add_new' => _x('Add new History', 'history'),
        'add_new_item' => __('Add new History'),
        'edit_item' => __('Edit History'),
        'new_item' => __('New History'),
        'view_item' => __('View History'),
        'search_items' => __('Search in History'),
        'not_found' =>  __('No History found'),
        'not_found_in_trash' => __('No History found in trash'),
        'parent_item_colon' => ''
    );

//Arguments
    $args = array(
        'labels' => $history_labels,
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'query_var' => true,
        'rewrite' => array( 'slug' => 'tjb-history' ),
        'capability_type' => 'post',
        'hierarchical' => false,
        'menu_position' => 5,
        'supports' => array('title','editor','author','thumbnail','excerpt'),
      //  'taxonomies' => array( 'faq_cat' ),
        'has_archive' => 'history'
    );
    register_post_type('history',$args);
}

function designer_post_count() {
	global $post;
	$args   =   array(
			 'post_type'     => 'product',
			 'posts_per_page' => -1,
			 'meta_query'    => array(
					 array(
								 'key' => 'product_designer',
								 'value' => $post->ID,
								 'compare' => '=',
								 'type' => 'NUMERIC'
					 ),
			 )

		);
		$query = new WP_Query($args);
		$count = $query->post_count;
		return $count;
}

require get_template_directory() . '/admin/acf-theme.php';
require get_template_directory() . '/admin/map-acf.php';
require get_template_directory() . '/admin/sub-acf.php';
require get_template_directory() . '/admin/shotcode.php';
require get_template_directory() . '/admin/theme-options.php';
require get_template_directory() . '/admin/function-sub.php';

