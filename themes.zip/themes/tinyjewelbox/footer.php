<div class="container visible-xs">
    <div class="row">
        <div class="col-xs-12">
            <p id="back-top">
             <a href="#top" title="Back To Top"><span>Back to Top <i class="glyphicon glyphicon-menu-up pull-right" aria-hidden="true"></i></span></a>
            </p>
        </div>
    </div>
</div>
<?php get_template_part( 'common/common', 'homepopup' ); ?>
<footer>
<div class="box footer">
    <div class="container-tjb">

    	<div class="grid_7 contactinformation">
			<?php
			$contactusbox = ot_get_option('contactusbox');
			if(!empty($contactusbox))
			{
				echo $contactusbox;
			} ?>


			<ul class="social-footer">
				<?php
					$facebook_url = ot_get_option('facebook_url');
					$twitter = ot_get_option('twitter');
					$google = ot_get_option('google');
					$Pinterest = ot_get_option('pinterest');
					$linkedin = ot_get_option('linkedin');
					$Instagram = ot_get_option('instagram');
					?>
					<?php if(!empty($Instagram)) { ?><li class="instagram"><a href="<?php echo $Instagram; ?>" target="__blank">Instagram</a></li>
					<?php } ?>
					
					<?php if(!empty($facebook_url)) { ?> <li class="facebook"><a href="<?php echo $facebook_url; ?>" target="__blank">Facebook</a></li><?php } ?>

					<?php if(!empty($Pinterest)) { ?> <li class="pinterest"><a href="<?php echo $Pinterest; ?>" target="__blank">Pinterest</a></li><?php } ?>
					
					<?php if(!empty($twitter)) { ?><li class="twitter"><a href="<?php echo $twitter; ?>" target="__blank">Twitter</a></li>
					<?php } ?>

					<?php if(!empty($google)) { ?><li class="google"><a href="<?php echo $google; ?>" target="__blank">Google</a></li>
					<?php } ?>

					<?php if(!empty($linkedin)) { ?><li class="linkedin"><a href="<?php echo $linkedin; ?>" target="__blank">Linkedin</a></li>
					<?php } ?>





			</ul>
		      <div id="newsletter">
          <?php echo do_shortcode(get_option_tree( 'footer_form' ));?>
          </div>

    	</div>

    	<div class="grid_3">
			<h6><?php echo ot_get_option('menu_one_title'); ?></h6>
			<?php wp_nav_menu(array('theme_location' => 'FooterMenuOne', 'container' => 'ul', 'container_class' => '')); ?>
    	</div>


    	<div class="grid_3">
			<h6><?php echo ot_get_option('menu_two_title'); ?></h6>
			<?php wp_nav_menu(array('theme_location' => 'FooterMenuTwo', 'container' => 'ul', 'container_class' => '')); ?>
    	</div>


    	<div class="grid_3">
			<h6><?php echo ot_get_option('menu_three_title'); ?></h6>
			<?php wp_nav_menu(array('theme_location' => 'FooterMenuThree', 'container' => 'ul', 'container_class' => '')); ?>
    	</div>
		<?php if(!empty(ot_get_option('copyright_text')))
		      { ?>
				<div class="grid_16"><?php echo ot_get_option('copyright_text'); ?></div>
	    <?php } ?>
    </div><!-- container ends -->
</div><!-- box ends -->
</footer>

<?php wp_footer(); ?>
<!--Static for now will dynamic it later when comes in sprint-->
</body>
</html>
