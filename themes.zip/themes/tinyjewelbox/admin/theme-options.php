<?php
/**
 * Initialize the custom theme options.
 */
add_action( 'init', 'custom_theme_options' );

/**
 * Build the custom settings & update OptionTree.
 */
function custom_theme_options() {
  
  /* OptionTree is not loaded yet, or this is not an admin request */
  if ( ! function_exists( 'ot_settings_id' ) || ! is_admin() )
    return false;
    
  /**
   * Get a copy of the saved settings array. 
   */
  $saved_settings = get_option( ot_settings_id(), array() );
  
  /**
   * Custom settings array that will eventually be 
   * passes to the OptionTree Settings API Class.
   */
  $custom_settings = array( 
    'contextual_help' => array( 
      'sidebar'       => ''
    ),
    'sections'        => array( 
      array(
        'id'          => 'header_setting',
        'title'       => 'Header Settings'
      ),
      array(
        'id'          => 'footer_setting',
        'title'       => 'Footer Setting'
      ),
      array(
        'id'          => 'social_media_setting',
        'title'       => 'Social Media Setting'
      ),
      array(
        'id'          => 'copy_right_area',
        'title'       => 'Copy Right Area'
      ),
      array(
        'id'          => 'message_us_section',
        'title'       => 'Message Us Section'
      ),
      array(
        'id'          => 'related_product',
        'title'       => 'Related Product'
      ),
      array(
        'id'          => 'product_advertisement_section',
        'title'       => 'Product advertisement Section'
      ),
      array(
        'id'          => 'product',
        'title'       => 'Product'
      ),
      array(
        'id'          => 'map_section',
        'title'       => 'Map And Massage Section'
      ),
      array(
        'id'          => 'wishlist_url',
        'title'       => 'Wishlist Url'
      ),
      array(
        'id'          => 'newsevents_url',
        'title'       => 'News and Events Page Url'
      ),
      array(
        'id'          => 'designer_product_url',
        'title'       => 'Designer Product Url'
      ),
      array(
        'id'          => 'rolex_image_header',
        'title'       => 'Rolex image Header'
      ),
      array(
        'id'          => 'wishlist_form',
        'title'       => 'Wishlist form'
      ),
      array(
        'id'          => 'designer_detail',
        'title'       => 'Designer Detail'
      ),
      array(
        'id'          => 'mapkeys',
        'title'       => 'Google Map'
      ),
      array(
        'id'          => 'faq',
        'title'       => 'FAQ'
      )
    ),
    'settings'        => array( 
      array(
        'id'          => 'sitelogo',
        'label'       => 'SiteLogo',
        'desc'        => 'Add Logo Image here',
        'std'         => '',
        'type'        => 'upload',
        'section'     => 'header_setting',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'contactusbox',
        'label'       => 'ContactusBox',
        'desc'        => 'Please Add your contact and address detail here.',
        'std'         => '',
        'type'        => 'textarea',
        'section'     => 'footer_setting',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'menu_one_title',
        'label'       => 'Menu One Title',
        'desc'        => '',
        'std'         => '',
        'type'        => 'textarea-simple',
        'section'     => 'footer_setting',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'menu_two_title',
        'label'       => 'Menu Two Title',
        'desc'        => '',
        'std'         => '',
        'type'        => 'textarea-simple',
        'section'     => 'footer_setting',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'menu_three_title',
        'label'       => 'Menu Three Title',
        'desc'        => '',
        'std'         => '',
        'type'        => 'textarea-simple',
        'section'     => 'footer_setting',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'footer_form',
        'label'       => 'Footer Form',
        'desc'        => '',
        'std'         => '',
        'type'        => 'textarea',
        'section'     => 'footer_setting',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'facebook_url',
        'label'       => 'Facebook',
        'desc'        => '',
        'std'         => '',
        'type'        => 'text',
        'section'     => 'social_media_setting',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'twitter',
        'label'       => 'Twitter',
        'desc'        => '',
        'std'         => '',
        'type'        => 'text',
        'section'     => 'social_media_setting',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'google',
        'label'       => 'Google',
        'desc'        => '',
        'std'         => '',
        'type'        => 'text',
        'section'     => 'social_media_setting',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'pinterest',
        'label'       => 'Pinterest',
        'desc'        => '',
        'std'         => '',
        'type'        => 'text',
        'section'     => 'social_media_setting',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'instagram',
        'label'       => 'Instagram',
        'desc'        => '',
        'std'         => '',
        'type'        => 'text',
        'section'     => 'social_media_setting',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'linkedin',
        'label'       => 'Linkedin',
        'desc'        => '',
        'std'         => '',
        'type'        => 'text',
        'section'     => 'social_media_setting',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'copyright_text',
        'label'       => 'Copyright text',
        'desc'        => '',
        'std'         => '',
        'type'        => 'textarea',
        'section'     => 'copy_right_area',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'contact_form',
        'label'       => 'Add Shortcode',
        'desc'        => '',
        'std'         => '',
        'type'        => 'textarea',
        'section'     => 'message_us_section',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'title',
        'label'       => 'Title',
        'desc'        => '',
        'std'         => '',
        'type'        => 'text',
        'section'     => 'related_product',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'sub_title',
        'label'       => 'Sub Title',
        'desc'        => '',
        'std'         => '',
        'type'        => 'text',
        'section'     => 'related_product',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'ad_title',
        'label'       => 'Advertisement Title',
        'desc'        => '',
        'std'         => '',
        'type'        => 'text',
        'section'     => 'product_advertisement_section',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'sub_title1',
        'label'       => 'Advertisement Sub Title',
        'desc'        => '',
        'std'         => '',
        'type'        => 'text',
        'section'     => 'product_advertisement_section',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'description',
        'label'       => 'Advertisement Description',
        'desc'        => '',
        'std'         => '',
        'type'        => 'textarea',
        'section'     => 'product_advertisement_section',
        'rows'        => '5',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'dvertise_button_url',
        'label'       => 'dvertise Button URL',
        'desc'        => '',
        'std'         => '',
        'type'        => 'text',
        'section'     => 'product_advertisement_section',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'advertise_button',
        'label'       => 'Advertise Button',
        'desc'        => '',
        'std'         => '',
        'type'        => 'text',
        'section'     => 'product_advertisement_section',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'advertise_image',
        'label'       => 'Advertise Image',
        'desc'        => '',
        'std'         => '',
        'type'        => 'upload',
        'section'     => 'product_advertisement_section',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'product_button',
        'label'       => 'product_button',
        'desc'        => '',
        'std'         => '',
        'type'        => 'text',
        'section'     => 'product',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'product_button_url',
        'label'       => 'product_button Url',
        'desc'        => '',
        'std'         => '',
        'type'        => 'text',
        'section'     => 'product',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'map_area',
        'label'       => 'Map Area  : Please add popup=\'yes\' in the shortcode.',
        'desc'        => '',
        'std'         => '',
        'type'        => 'textarea',
        'section'     => 'map_section',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'key_api',
        'label'       => 'API KEY',
        'desc'        => '',
        'std'         => '',
        'type'        => 'text',
        'section'     => 'map_section',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'massage_form',
        'label'       => 'Appointment Form',
        'desc'        => '',
        'std'         => '',
        'type'        => 'textarea',
        'section'     => 'map_section',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'wishlist_user_url',
        'label'       => 'Wishlist URl',
        'desc'        => '',
        'std'         => '',
        'type'        => 'page-select',
        'section'     => 'wishlist_url',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'share_link',
        'label'       => 'Share link',
        'desc'        => '',
        'std'         => '',
        'type'        => 'page-select',
        'section'     => 'wishlist_url',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'newsevents_url_page',
        'label'       => 'Select Page',
        'desc'        => '',
        'std'         => '',
        'type'        => 'page-select',
        'section'     => 'newsevents_url',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'products_designer_url_t',
        'label'       => 'Designer Products URL',
        'desc'        => '',
        'std'         => '',
        'type'        => 'page-select',
        'section'     => 'designer_product_url',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'rolex_desktop_image',
        'label'       => 'Rolex Desktop Image',
        'desc'        => '',
        'std'         => '',
        'type'        => 'upload',
        'section'     => 'rolex_image_header',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'rolex_phone_image',
        'label'       => 'Rolex Phone Image',
        'desc'        => '',
        'std'         => '',
        'type'        => 'upload',
        'section'     => 'rolex_image_header',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'rolex_url',
        'label'       => 'Rolex URL',
        'desc'        => '',
        'std'         => '',
        'type'        => 'text',
        'section'     => 'rolex_image_header',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'subject',
        'label'       => 'Subject',
        'desc'        => '',
        'std'         => '',
        'type'        => 'text',
        'section'     => 'wishlist_form',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'success_message',
        'label'       => 'Success Message',
        'desc'        => '',
        'std'         => '',
        'type'        => 'text',
        'section'     => 'wishlist_form',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'failed_message',
        'label'       => 'Failed Message',
        'desc'        => '',
        'std'         => '',
        'type'        => 'text',
        'section'     => 'wishlist_form',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'send_email',
        'label'       => 'Email IDs',
        'desc'        => '',
        'std'         => '',
        'type'        => 'text',
        'section'     => 'wishlist_form',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'more_product_title',
        'label'       => 'More Product Title',
        'desc'        => '',
        'std'         => '',
        'type'        => 'text',
        'section'     => 'designer_detail',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'by_this_designer_sub_title',
        'label'       => 'By This Designer Sub Title',
        'desc'        => '',
        'std'         => '',
        'type'        => 'text',
        'section'     => 'designer_detail',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'view_more_products_title',
        'label'       => 'View More Product Title',
        'desc'        => '',
        'std'         => '',
        'type'        => 'text',
        'section'     => 'designer_detail',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'error_massage_product',
        'label'       => 'Error Massage Product',
        'desc'        => '',
        'std'         => '',
        'type'        => 'text',
        'section'     => 'designer_detail',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'g_site_key',
        'label'       => 'Site Key',
        'desc'        => '',
        'std'         => '',
        'type'        => 'text',
        'section'     => 'mapkeys',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'g_secret_key',
        'label'       => 'Secret key',
        'desc'        => '',
        'std'         => '',
        'type'        => 'text',
        'section'     => 'mapkeys',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'question_title',
        'label'       => 'Question Title',
        'desc'        => '',
        'std'         => '',
        'type'        => 'text',
        'section'     => 'faq',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'answers_title',
        'label'       => 'Answers title',
        'desc'        => '',
        'std'         => '',
        'type'        => 'text',
        'section'     => 'faq',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'back_to_top_title',
        'label'       => 'Back To Top title',
        'desc'        => '',
        'std'         => '',
        'type'        => 'text',
        'section'     => 'faq',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      )
    )
  );
  
  /* allow settings to be filtered before saving */
  $custom_settings = apply_filters( ot_settings_id() . '_args', $custom_settings );
  
  /* settings are not the same update the DB */
  if ( $saved_settings !== $custom_settings ) {
    update_option( ot_settings_id(), $custom_settings ); 
  }
  
  /* Lets OptionTree know the UI Builder is being overridden */
  global $ot_has_custom_theme_options;
  $ot_has_custom_theme_options = true;
  
}
