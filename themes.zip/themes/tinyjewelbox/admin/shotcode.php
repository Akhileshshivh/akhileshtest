<?php
/**
* Function:- wp_map
* Type :- Predefined Action
* Purpose:- To add slider into page and post.
* Returns: Slider HTML
**/

function wp_map( $atts ) {
global $post;
$atts = shortcode_atts( array(
	'id' => '',
	'popup' => 'no'
), $atts, 'wp_map' );
setup_postdata($atts['id']);
$post = get_post( $atts['id'] );
if ( $post ) :
  $map_id = $atts['id'].uniqid();
 // $zoom_level = get_field('zoom_effect' , $atts['id'] );
?><div id="gmap_<?php echo $map_id; ?>" class="m<?php echo $icount; ?>" style="height:<?php echo get_field('map_height' , $atts['id'] );?>; width:100%;"></div>
  <?php
  $i = 0;
  $locations = "var locations".$map_id." =[";
   while ( have_rows('add_locations') ) : the_row();

	$location = get_sub_field('google_map_location');
	$location_text = "<span class='innerTxt'>".get_sub_field('location_text').'</span>';
	$locations .=  '["'.$location_text.'", '.$location['lat'].', '.$location['lng'].', '.$i.'],';
    $i++;
    endwhile;
	$locations .= "];";
	$finalcall = "";
    if($atts['popup'] == 'no')
    {
		$finalcall = "google.maps.event.addDomListener(window,'load',gmap_".$map_id.");";
	}
	else
	{
		$finalcall = ";jQuery('#myModal-map').on('shown.bs.modal', function(e) {gmap_".$map_id."();});";
	}

    ?>


  <?php $map_Script = "function gmap_".$map_id."() {
	".$locations."
	l='".get_bloginfo('template_directory')."/images/map-icon.png';
	var map = new google.maps.Map(document.getElementById('gmap_".$map_id."'), {
		zoom: 17,
		center: new google.maps.LatLng(locations".$map_id."[0][1], locations".$map_id."[0][2]),
		mapTypeId: google.maps.MapTypeId.ROADMAP,styles:[{elementType:'geometry',stylers:[{color:'#f5f5f5'}]},{elementType:'labels.icon',stylers:[{visibility:'off'}]},{elementType:'labels.text.fill',stylers:[{color:'#616161'}]},{elementType:'labels.text.stroke',stylers:[{color:'#f5f5f5'}]},{featureType:'administrative.land_parcel',elementType:'labels.text.fill',stylers:[{color:'#bdbdbd'}]},{featureType:'poi',elementType:'geometry',stylers:[{color:'#eeeeee'}]},{featureType:'poi',elementType:'labels.text.fill',stylers:[{color:'#757575'}]},{featureType:'poi.park',elementType:'geometry',stylers:[{color:'#e5e5e5'}]},{featureType:'poi.park',elementType:'labels.text.fill',stylers:[{color:'#9e9e9e'}]},{featureType:'road',elementType:'geometry',stylers:[{color:'#ffffff'}]},{featureType:'road.arterial',elementType:'labels.text.fill',stylers:[{color:'#757575'}]},{featureType:'road.highway',elementType:'geometry',stylers:[{color:'#dadada'}]},{featureType:'road.highway',elementType:'labels.text.fill',stylers:[{color:'#616161'}]},{featureType:'road.local',elementType:'labels.text.fill',stylers:[{color:'#9e9e9e'}]},{featureType:'transit.line',elementType:'geometry',stylers:[{color:'#e5e5e5'}]},{featureType:'transit.station',elementType:'geometry',stylers:[{color:'#eeeeee'}]},{featureType:'water',elementType:'geometry',stylers:[{color:'#c9c9c9'}]},{featureType:'water',elementType:'labels.text.fill',stylers:[{color:'#9e9e9e'}]}],
	});

	var infowindow = new google.maps.InfoWindow({});

	var marker, i;

	for (i = 0; i < locations".$map_id.".length; i++) {
		marker = new google.maps.Marker({
			icon:l,
			position: new google.maps.LatLng(locations".$map_id."[i][1], locations".$map_id."[i][2]),
			map: map
		});
		infowindow.setContent(locations".$map_id."[i][0]);
		infowindow.open(map, marker);
		google.maps.event.addListener(marker, 'click', (function (marker, i) {
			return function () {
				infowindow.setContent(locations".$map_id."[i][0]);
				infowindow.open(map, marker);
			}
		})(marker, i));
	}
}".$finalcall;
?>
  <?php wp_add_inline_script( 'tinyjewlbox-googlemap-js', $map_Script , 'after'); ?>
<?php
wp_reset_query();
endif;
}
add_shortcode( 'MAP', 'wp_map' );
