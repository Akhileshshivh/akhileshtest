<?php 
add_action( 'admin_enqueue_scripts', 'load_custom_script' );
function load_custom_script() {
	global $post;
  	$post = get_post( $post ) ;
	if($post->post_type == "product" && (is_admin))
	{
		wp_enqueue_script('adminscript', get_bloginfo('template_url').'/js/adminscript.js', array('jquery'));
	}
}

/**
* Function:- custom_posttype
* Type :- Predefined Action
* Purpose:- Include Post type into admin.
* Returns: another post type
**/
add_action( 'init', 'custom_posttype' );
function custom_posttype() 
{
	register_post_type( 'productadvertisement',
		array(
			'labels' => array(
				'name' => __( 'Product Advertisement' ),
				'singular_name' => __( 'productadvertisement' )
			),
		//	'taxonomies' => array('sider_type'),
			'public' => true,
			'has_archive' => true,
           // 'menu_icon' => 'dashicons-groups',
			'rewrite' => array('slug' => 'productadvertisement'),
			'supports'  => array( 'title', 'editor',  'thumbnail' )
		)
	);
	/**
	* Function:- register_taxonomy
	* Type :- Predefined Action
	* Purpose:- To include custom taxomony for product.
	* Returns: return custom taxonomy in admin panel
	**/
	$labels = array(
		'name'              => _x( 'Gemstone', 'taxonomy general name', 'tinyjewelbox' ),
		'singular_name'     => _x( 'Gemstone', 'taxonomy singular name', 'tinyjewelbox' ),
		'search_items'      => __( 'Search Gemstone', 'tinyjewelbox' ),
		'all_items'         => __( 'All Gemstone', 'tinyjewelbox' ),
		'parent_item'       => __( 'Parent Gemstone', 'tinyjewelbox' ),
		'parent_item_colon' => __( 'Parent Gemstone:', 'tinyjewelbox' ),
		'edit_item'         => __( 'Edit Gemstone', 'tinyjewelbox' ),
		'update_item'       => __( 'Update Gemstone', 'tinyjewelbox' ),
		'add_new_item'      => __( 'Add New Gemstone', 'tinyjewelbox' ),
		'new_item_name'     => __( 'New Gemstone Name', 'tinyjewelbox' ),
		'menu_name'         => __( 'Gemstone', 'tinyjewelbox' ),
	);

	$args = array(
		'hierarchical'      => true,
		'labels'            => $labels,
		'show_ui'           => true,
		'show_admin_column' => true,
		'query_var'         => true,
		'rewrite'           => array( 'slug' => 'gemstone' ),
	);
	register_taxonomy( 'gemstone', array( 'product' ), $args );	
	
	/**
	* Function:- register_taxonomy
	* Type :- Predefined Action
	* Purpose:- To include custom taxomony for product.
	* Returns: return custom taxonomy in admin panel
	**/
	$labels = array(
		'name'              => _x( 'Cut', 'taxonomy general name', 'tinyjewelbox' ),
		'singular_name'     => _x( 'Cut', 'taxonomy singular name', 'tinyjewelbox' ),
		'search_items'      => __( 'Search Cut', 'tinyjewelbox' ),
		'all_items'         => __( 'All Cut', 'tinyjewelbox' ),
		'parent_item'       => __( 'Parent Cut', 'tinyjewelbox' ),
		'parent_item_colon' => __( 'Parent Cut:', 'tinyjewelbox' ),
		'edit_item'         => __( 'Edit Cut', 'tinyjewelbox' ),
		'update_item'       => __( 'Update Cut', 'tinyjewelbox' ),
		'add_new_item'      => __( 'Add New Cut', 'tinyjewelbox' ),
		'new_item_name'     => __( 'New Cut Name', 'tinyjewelbox' ),
		'menu_name'         => __( 'Cut', 'tinyjewelbox' ),
	);

	$args = array(
		'hierarchical'      => true,
		'labels'            => $labels,
		'show_ui'           => true,
		'show_admin_column' => true,
		'query_var'         => true,
		'rewrite'           => array( 'slug' => 'cut' ),
	);
	register_taxonomy( 'cut', array( 'product' ), $args );	

	/**
	* Function:- register_taxonomy
	* Type :- Predefined Action
	* Purpose:- To include custom taxomony for product.
	* Returns: return custom taxonomy in admin panel
	**/	
	$labels = array(
		'name'              => _x( 'Metals', 'taxonomy general name', 'tinyjewelbox' ),
		'singular_name'     => _x( 'Metals', 'taxonomy singular name', 'tinyjewelbox' ),
		'search_items'      => __( 'Search Metals', 'tinyjewelbox' ),
		'all_items'         => __( 'All Metals', 'tinyjewelbox' ),
		'parent_item'       => __( 'Parent Metals', 'tinyjewelbox' ),
		'parent_item_colon' => __( 'Parent Metals:', 'tinyjewelbox' ),
		'edit_item'         => __( 'Edit Metals', 'tinyjewelbox' ),
		'update_item'       => __( 'Update Metals', 'tinyjewelbox' ),
		'add_new_item'      => __( 'Add New Metals', 'tinyjewelbox' ),
		'new_item_name'     => __( 'New Metals Name', 'tinyjewelbox' ),
		'menu_name'         => __( 'Metals', 'tinyjewelbox' ),
	);

	$args = array(
		'hierarchical'      => true,
		'labels'            => $labels,
		'show_ui'           => true,
		'show_admin_column' => true,
		'query_var'         => true,
		'rewrite'           => array( 'slug' => 'metals' ),
	);
	register_taxonomy( 'metals', array( 'product' ), $args );			
	
	/**
	* Function:- register_taxonomy
	* Type :- Predefined Action
	* Purpose:- To include custom taxomony for product.
	* Returns: return custom taxonomy in admin panel
	**/	
	$labels = array(
		'name'              => _x( 'Mixed Vintage', 'taxonomy general name', 'tinyjewelbox' ),
		'singular_name'     => _x( 'Mixed Vintage', 'taxonomy singular name', 'tinyjewelbox' ),
		'search_items'      => __( 'Mixed Vintage', 'tinyjewelbox' ),
		'all_items'         => __( 'All Mixed Vintage', 'tinyjewelbox' ),
		'parent_item'       => __( 'Parent Mixed Vintage', 'tinyjewelbox' ),
		'parent_item_colon' => __( 'Parent Mixed Vintage:', 'tinyjewelbox' ),
		'edit_item'         => __( 'Edit Mixed Vintage', 'tinyjewelbox' ),
		'update_item'       => __( 'Update Mixed Vintage', 'tinyjewelbox' ),
		'add_new_item'      => __( 'Add New Mixed Vintage', 'tinyjewelbox' ),
		'new_item_name'     => __( 'New Mixed Vintage Name', 'tinyjewelbox' ),
		'menu_name'         => __( 'Mixed Vintage', 'tinyjewelbox' ),
	);

	$args = array(
		'hierarchical'      => true,
		'labels'            => $labels,
		'show_ui'           => true,
		'show_admin_column' => true,
		'query_var'         => true,
		'rewrite'           => array( 'slug' => 'mixed-vintage' ),
	);
	register_taxonomy( 'mixed-vintage', array( 'product' ), $args );	

	/**
	* Function:- register_taxonomy
	* Type :- Predefined Action
	* Purpose:- To include custom taxomony for product.
	* Returns: return custom taxonomy in admin panel
	**/	
	$labels = array(
		'name'              => _x( 'Bands', 'taxonomy general name', 'tinyjewelbox' ),
		'singular_name'     => _x( 'Bands', 'taxonomy singular name', 'tinyjewelbox' ),
		'search_items'      => __( 'Bands', 'tinyjewelbox' ),
		'all_items'         => __( 'All Bands', 'tinyjewelbox' ),
		'parent_item'       => __( 'Parent Bands', 'tinyjewelbox' ),
		'parent_item_colon' => __( 'Parent Bands:', 'tinyjewelbox' ),
		'edit_item'         => __( 'Edit Bands', 'tinyjewelbox' ),
		'update_item'       => __( 'Update Bands', 'tinyjewelbox' ),
		'add_new_item'      => __( 'Add New Bands', 'tinyjewelbox' ),
		'new_item_name'     => __( 'New Bands Name', 'tinyjewelbox' ),
		'menu_name'         => __( 'Bands', 'tinyjewelbox' ),
	);

	$args = array(
		'hierarchical'      => true,
		'labels'            => $labels,
		'show_ui'           => true,
		'show_admin_column' => true,
		'query_var'         => true,
		'rewrite'           => array( 'slug' => 'bands' ),
	);
	register_taxonomy( 'bands', array( 'product' ), $args );

	/**
	* Function:- register_taxonomy
	* Type :- Predefined Action
	* Purpose:- To include custom taxomony for product.
	* Returns: return custom taxonomy in admin panel
	**/	
	$labels = array(
		'name'              => _x( 'Stone', 'taxonomy general name', 'tinyjewelbox' ),
		'singular_name'     => _x( 'Stone', 'taxonomy singular name', 'tinyjewelbox' ),
		'search_items'      => __( 'Stone', 'tinyjewelbox' ),
		'all_items'         => __( 'All Stone', 'tinyjewelbox' ),
		'parent_item'       => __( 'Parent Stone', 'tinyjewelbox' ),
		'parent_item_colon' => __( 'Parent Stone', 'tinyjewelbox' ),
		'edit_item'         => __( 'Edit Stone', 'tinyjewelbox' ),
		'update_item'       => __( 'Update Stone', 'tinyjewelbox' ),
		'add_new_item'      => __( 'Add New Stone', 'tinyjewelbox' ),
		'new_item_name'     => __( 'New Bands Stone', 'tinyjewelbox' ),
		'menu_name'         => __( 'Stone', 'tinyjewelbox' ),
	);

	$args = array(
		'hierarchical'      => true,
		'labels'            => $labels,
		'show_ui'           => true,
		'show_admin_column' => true,
		'query_var'         => true,
		'rewrite'           => array( 'slug' => 'stone' ),
	);
	register_taxonomy( 'stone', array( 'product' ), $args );

}


/**
* Function:- filter_option_available
* Type :-  Action
* Purpose:- To check filter option for every category page 
* Returns: return filter option from admin
**/	
function filter_option_availableto()
{	$term_id = get_queried_object()->term_id;	
	$term = 'term_'.$term_id;
	$filtering_option_setting = '';
	$filtering_option = get_field('filtering_option', $term);
	if(!empty($filtering_option))
	{  
		$filtering_option_setting = $filtering_option[0];
	}
	else
	{
		$filtering_option_setting = get_term_direct_parent($term_id, 'product_cat');
	}
	return $filtering_option_setting;
}

function filter_option_available()
{

	$filtering_option_setting = filter_option_availableto();
	$i  = 1;
	if(!empty($filtering_option_setting))
	{
		foreach($filtering_option_setting as $key => $value)
		{
			
			if($value == 1)
			{
				showcustomfilter($key, $i); 
			}
			else if($key == 'price_ranga' && ! empty( $value ) )
			{	
				
				$html = '';  $class= '';
				$termcount = count($key);
				$number_div = ceil($termcount/10);
					if($i == 1) { 
						$class = 'in'; 
						$iconclass = 'minus';
					} else
					{
						$iconclass = 'plus';
					}
				if($number_div >= 0)
				{
					$number_div = 1;
				}
				$html .= '<li role="tab" class="panel">';
				$html .= '<h3>Price <a class="f-toglr" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseprice" aria-expanded="true" aria-controls="collapseprice"><span class="tab-icon glyphicon-'.$iconclass.'"></span></a></h3>';
				$html .= ' <ul class="multi-column panel-collapse collapse fade '.$class.'" id="collapseprice" role="tabpanel"
							style="-moz-column-count: '.$number_div.';   -webkit-column-count: '.$number_div.';    column-count: '.$number_div.';">';

							foreach($value as $pricerange)
							{
								if(!empty($pricerange['and_under']))
								{
									if(!empty($pricerange['custom_value']))
									{
										$start_range = $pricerange['custom_value'];
									}
									else
									{
										$start_range = $pricerange['start_range'];
									}
									if($pricerange['and_under'][0] == 'yes') 
									{
										$html .= '<li><label class="checkbox"><input type="checkbox"  name="price[]" 
										value="'.$start_range.'-0000" ><span>Under $'.$start_range.'</span></label></li>';//onclick="filtermenu(1)"
										unset($start_range);
									}
								}
							
									$filterprice = '$'.$pricerange['start_range'].' - $'.$pricerange['end_range'];
									$filterpriceval = $pricerange['start_range'].'-'.$pricerange['end_range'];
									$html .= '<li><label class="checkbox"><input type="checkbox"  name="price[]" 
									value="'.$filterpriceval.'"><span>'.$filterprice.'</span></label></li>'; // onclick="filtermenu(1)"

								if(!empty($pricerange['and_above']))
								{
									if($pricerange['and_above'][0] == 'yes') 
									{
										if(!empty($pricerange['custom_value']))
										{
											$endrange_range = $pricerange['custom_value'];
										}
										else
										{
											$endrange_range = $pricerange['end_range'];
										}
										$html .= '<li><label class="checkbox"><input type="checkbox"  name="price[]" 
										value="'.$endrange_range.'-nobar" ><span>$'.$endrange_range.' and over</span></label></li>'; //onclick="filtermenu(1)"
									}
								}
							}
				$html .= '</ul>';
				$html .= '</li>';
				echo $html ;
			}
		$i++;
		}
	}

}
/**
* Function:- get_term_direct_parent
* Type :-  Action
* Purpose:- To Get category parent 
* Returns: return parent category filter option 
**/	
function get_term_direct_parent($term_id, $taxonomy){
    
    $parent  = get_term_by( 'id', $term_id, $taxonomy);
    $i = 0;
    while ($parent->parent != '0'){
        $term_id = $parent->parent;
        $parent  = get_term_by( 'id', $term_id, $taxonomy);
		$filtering_option = get_field('filtering_option', 'term_'.$parent->term_id);
		if(!empty($filtering_option))
		{  
			return $filtering_option[0];
			exit;
		}        
    }
}

function get_term_top_most_parent($term_id, $taxonomy){
    $parent  = get_term_by( 'id', $term_id, $taxonomy);
    while ($parent->parent != '0'){
        $term_id = $parent->parent;

        $parent  = get_term_by( 'id', $term_id, $taxonomy);
    }
    return $parent;
}

/**
* Function:- showcustomfilter
* Type :-  Action
* Purpose:- All filters
* Returns: return filtershtml
**/	
function showcustomfilter($filteractive, $i)
{
	$terms = get_terms( $filteractive, array('hide_empty' => false) );
	$number_div =  '';
	$html = '';
	if(!empty($terms))
	{
			$termcount = count($terms);
			$numberofdiv = ceil($termcount /10);
			
			?>
			<li role="tab" class="panel">
			<h3><?php echo $filteractive; ?><a class="f-toglr" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse<?php echo $terms[0]->term_id; ?>" aria-expanded="true" aria-controls="collapse<?php echo $terms[0]->term_id; ?>"><span class="tab-icon glyphicon-<?php if($i == 1){ ?>minus<?php }else{ ?>plus<?php } ?>"></span></a></h3>
				 <ul class="multi-column panel-collapse collapse fade <?php if($i == 1){ ?>in<?php } ?>" id="collapse<?php echo $terms[0]->term_id; ?>" role="tabpanel"
							style="-moz-column-count: <?php echo $numberofdiv; ?>;   -webkit-column-count: <?php echo $numberofdiv; ?>; column-count: <?php echo $numberofdiv; ?>;">
							<?php 
							foreach($terms as $filteroption)
							{
								?>
								<li><label class="checkbox"><input type="checkbox"  name="<?php echo $filteractive; ?>[]" value="<?php echo $filteroption->term_id; ?>" ><span>
									<?php echo $filteroption->name; ?>
									</span> </label></li>
								<?php //onclick="filtermenu(1)" 
							}
							?>
				</ul>
			</li>
			<?php
   }
}

function array_flatten($array) { 
  if (!is_array($array)) { 
    return FALSE; 
  } 
  $result = array(); 
  foreach ($array as $key => $value) { 
    if (is_array($value)) { 
      $result = array_merge($result, array_flatten($value)); 
    } 
    else { 
      $result[$key] = $value; 
    } 
  } 
  return $result; 
} 

/**
* Function:- wp_ajax_filter_menu
* Type: Action
* Purpose:- To load filter result
* Returns: HTML  
**/
add_action( 'wp_ajax_filter_menu', 'wp_ajax_filter_menu' );
add_action( 'wp_ajax_nopriv_filter_menu', 'wp_ajax_filter_menu' );

function wp_ajax_filter_menu()
{
	global $post, $wp_query;
	parse_str($_POST['data'], $output);
	if(empty($_POST['data']))
	{
		echo 'nodata';
	}
	else
	{
			
		$taxonomy_query = array(); 
		$i = 0 ;
		$gemstone = []; $cut = []; $metals = []; $mixedvintage = []; $bands = []; $type = []; $tax_query = ''; $meta_query = '';
		$max_range = ''; $min_range = ''; 
		foreach($output as $key => $value)
		{
			if($key == 'gemstone')
			{
				$gemstone =  array(
					'taxonomy' => $key,
					'field'    => 'term_id',
					'terms'    => $value,
				);
			}
			if($key == 'cut')
			{
				$cut =  array(
					'taxonomy' => $key,
					'field'    => 'term_id',
					'terms'    => $value,
				);
			}
			if($key == 'metals')
			{
				$metals =  array(
					'taxonomy' => $key,
					'field'    => 'term_id',
					'terms'    => $value,
				);
			}
			if($key == 'mixed-vintage')
			{
				$mixedvintage =  array(
					'taxonomy' => $key,
					'field'    => 'term_id',
					'terms'    => $value,
				);
			}				
			if($key == 'bands')
			{
				$bands =  array(
					'taxonomy' => $key,
					'field'    => 'term_id',
					'terms'    => $value,
				);
			}			
			if($key == 'stone')
			{
				$type =  array(
					'taxonomy' => $key,
					'field'    => 'term_id',
					'terms'    => $value,
				);
			}	
			if($key == 'price')
			{
				
				foreach( $value as $pricevalue )
				{
					$pricevalues[] = explode('-',$pricevalue);
					
				}
				$pricevalues = array_flatten($pricevalues);
				$max = max(array_flatten($pricevalues));
				$min = min(array_flatten($pricevalues));
				if($min == '0000') {$min = 0;}
				if($max == 'nobar')
				{	
					$min_range = array(
						'key' => '_price',
						'value' => $min,
						'compare' => '>=',
						'type'      => 'numeric'
					);	
					$max_range = '';				
				}
				else
				{
					$max_range = array(
							'key' => '_price',
							'value' => array($min, $max),
							'compare' => 'BETWEEN',
							'type'  => 'numeric'
					);
					$min_range = '';
			}
			$meta_query = array(
				'relation' => 'AND',
				'0' => $max_range,
				'1' => $min_range, 
			);
			}
			$i++;
		}	
		
		if(!empty($gemstone) || !empty($cut) || !empty($metals) || !empty($mixedvintage) || !empty($bands) || !empty($type))
		{
			 $tax_query = array(
				 'relation' => 'OR',
				 '0' => $gemstone ,
				 '1' => $cut,
				 '2' => $metals,
				 '3' => $mixedvintage,
				 '4' => $bands,
				 '5' => $type,
			 );
		}
		$args = array(
			'post_type' => 'product',
			'posts_per_page' => '8',
			'post_status' => 'publish',
			'paged' => $_POST['paged'],
			'meta_query' => $meta_query, 
			'tax_query' => array(
							'relation' => 'AND',
							 array(
								'taxonomy' => 'product_cat',
								'field'    => 'term_id',
								'terms'    => array($_POST['Cat_id']),
								//'operator' => 'AND'
							 ),
							'1' => $tax_query,
			),
		);
		$filteroption = new WP_Query( $args );
		if ( $filteroption->have_posts() ) :
		while ($filteroption->have_posts()) : $filteroption->the_post();
				get_template_part( 'common/common', 'result' );	
		endwhile; 
		else: return false; endif;
	}	
		die;
}

/**
* Function:- wp_ajax_search_result_pagination
* Type: Action
* Purpose:- To load search result
* Returns: HTML  
**/
add_action( 'wp_ajax_search_result_pagination', 'wp_ajax_search_result_pagination' );
add_action( 'wp_ajax_nopriv_search_result_pagination', 'wp_ajax_search_result_pagination' );

function wp_ajax_search_result_pagination()
{

		global $wpdb, $post, $product;
		$limit = 8; 
		$item_per_page = 8;
		//Get page number from Ajax
		if(!empty($_REQUEST['keyword']) && (strlen($_REQUEST['keyword']) > 2))
			if(isset($_REQUEST["paged"])){
				$page_number = filter_var($_REQUEST["paged"], FILTER_SANITIZE_NUMBER_INT, FILTER_FLAG_STRIP_HIGH); //filter number
				if(!is_numeric($page_number)){die('Invalid page number!');} //incase of invalid page number
			}else{
				$page_number = 1; //if there's no page number, set it to 1
			}
			$query = search_query($_REQUEST['keyword'] ,'');
			$totalcount = $wpdb->get_results($query, OBJECT );
			$get_total_rows = count($totalcount);
			$total_pages = ceil($get_total_rows[0]/$item_per_page);
			$page_position = (($page_number-1) * $item_per_page);
			$limit =  ' LIMIT '.$page_position.', '.$item_per_page;
			$query = search_query($_REQUEST['keyword'] ,$limit);
			$postids = $wpdb->get_results($query, OBJECT );
			if ( !empty($postids) ) 
			{
				foreach( $postids as $post) : setup_postdata($post);
				$post = get_post( $post->ID );
				get_template_part( 'common/common', 'result' );	
				endforeach;
			}
			else
			{
				return false;
			}
		die;
		
}

function totalnoofpost($keyword)
{
		global $wpdb, $post;
		$query = search_query($keyword ,'');
		$postids = $wpdb->get_results($query, OBJECT );
		return count($postids);
}

function search_query($keyword ,$limit)
{
		global $wpdb, $post;
		$keyword =  esc_sql($keyword);
		$term_query = "SELECT term_id  FROM wp_terms WHERE name LIKE '%".$keyword."%' OR slug LIKE '%".$keyword."%'";
		$term_id = $wpdb->get_results($term_query);
		
		$final_term = '';
		$query_part = '';
		$uppper_query = '';
		foreach($term_id as $termsfilter)
		{
			$final_term[] = $termsfilter->term_id;
		}
		if(!empty($final_term)){
		$termids = implode(', ', $final_term);
	    }
		if(!empty($termids)) {  
			 $uppper_query = 'LEFT JOIN wp_term_relationships ON (wp_posts.ID = wp_term_relationships.object_id)';
			 $query_part = "(wp_term_relationships.term_taxonomy_id IN (".$termids.")) OR "; 
		}
		$query = "SELECT SQL_CALC_FOUND_ROWS  wp_posts.ID  FROM wp_posts 
		".$uppper_query." 
		INNER JOIN wp_postmeta ON ( wp_posts.ID = wp_postmeta.post_id ) WHERE 1=1 
		AND (
		".$query_part."
		((wp_posts.post_title LIKE '%".$keyword."%') OR (wp_posts.post_excerpt LIKE '%".$keyword."%') OR 
		(wp_posts.post_content LIKE '%".$keyword."%')) OR 
		( (wp_postmeta.meta_key = '_sku' AND wp_postmeta.meta_value LIKE '%".$keyword."%' ) OR
		  (wp_postmeta.meta_key = 'product_designer_title' AND wp_postmeta.meta_value LIKE '%".$keyword."%' ) OR
		  (wp_postmeta.meta_key = 'product_designer' AND wp_postmeta.meta_value LIKE '%".$keyword."%' )
	    ) )
		AND wp_posts.post_type = 'product' 
		AND ((wp_posts.post_status = 'publish')) 
		GROUP BY wp_posts.ID ORDER BY wp_posts.ID DESC, wp_posts.post_date DESC".$limit;	
		return $query;
}


function wp_ajax_search_autosearchnewquery($keyword, $limit)
{
	$keyword =  esc_sql($keyword);
	$query = "SELECT DISTINCT post_title, ID  FROM wp_posts INNER JOIN wp_postmeta ON ( wp_posts.ID = wp_postmeta.post_id ) WHERE 1=1 AND ( ((wp_posts.post_title LIKE '%".$keyword."%') OR (wp_posts.post_excerpt LIKE '%".$keyword."%') OR (wp_posts.post_content LIKE '%".$keyword."%')) OR ( (wp_postmeta.meta_key = '_sku' AND wp_postmeta.meta_value LIKE '%".$keyword."%' ) OR (wp_postmeta.meta_key = 'product_designer_title' AND wp_postmeta.meta_value LIKE '%".$keyword."%') OR (wp_postmeta.meta_key = 'product_designer' AND wp_postmeta.meta_value LIKE '%".$keyword."%' ) ) ) AND wp_posts.post_type = 'product' AND ((wp_posts.post_status = 'publish')) GROUP BY wp_posts.post_title ORDER BY wp_posts.post_title ASC LIMIT 0, ".$limit;
	return $query;
}

function wp_taxonomy_querysearch($keyword)
{
	$keyword =  esc_sql($keyword);
	$query = "SELECT DISTINCT name FROM wp_terms 
	LEFT JOIN wp_term_taxonomy ON ( wp_terms.term_id = wp_term_taxonomy.term_taxonomy_id ) WHERE 1=1  
	AND ((wp_terms.name LIKE '%".$keyword."%') OR (wp_terms.slug LIKE '%".$keyword."%' ))
	AND (wp_term_taxonomy.taxonomy = 'gemstone' OR 
	wp_term_taxonomy.taxonomy = 'cut' OR 
	wp_term_taxonomy.taxonomy = 'bands' OR 
	wp_term_taxonomy.taxonomy = 'metals' OR 
	wp_term_taxonomy.taxonomy = 'mixed-vintage' OR 
	wp_term_taxonomy.taxonomy = 'stone' OR 
	wp_term_taxonomy.taxonomy = 'product_cat')
	ORDER BY wp_terms.name ASC LIMIT 0, 5";
	return $query;
	//AND (wp_term_taxonomy.count > 0 ) will add if required
}
add_action( 'wp_ajax_search_autosearch', 'wp_ajax_search_autosearch' );
add_action( 'wp_ajax_nopriv_search_autosearch', 'wp_ajax_search_autosearch' );

function wp_ajax_search_autosearch()
{
		global $post, $wp_query, $wpdb;
		$keyword = $_REQUEST['keyword'];
		$keyword = trim(preg_replace('/\s\s+/', ' ', str_replace("\n", " ", $keyword)));
		if((strlen($keyword) > 2) && !empty(($keyword)))
		{
			$query_tax = wp_taxonomy_querysearch($keyword);
			$taxids = $wpdb->get_results($query_tax, ARRAY_N );
			$autosearch_keyword = $taxids;
			$counttaxid = count($taxids);
			if($counttaxid < 15)
			{
				$limitfornextquery = 5 - $counttaxid;
				$query_post = wp_ajax_search_autosearchnewquery($keyword, $limitfornextquery);
				$postids = $wpdb->get_results($query_post, ARRAY_N );
				$autosearch_keyword =array_merge ($taxids, $postids );
			}
			if ( !empty($autosearch_keyword) ) 
			{
				foreach( $autosearch_keyword as $post ) 
				{
				if(!empty($post[1])){
					 $link = get_permalink($post[1]); 
				}else{ 
					$link = '/?'.http_build_query(array('s' => $post[0])); 
				}					
				?>
					<li><a href="<?php echo $link; ?>"><?php echo $post[0]; ?></a></li>
				<?php } ?>
				<?php
			}

		}
		die;
}


function wp_ajax_wishlist_cookie() 
{
	$productid = $_POST['postid'];
	$time = time()+86400*30;
	if(!isset($_COOKIE["tiny_wishlist"]))
	{
		$uniquekey = "tiny_".md5(microtime().rand());
		$value = array(0 => $uniquekey, 1 => $productid );
		$value = base64_encode(serialize($value));
		setcookie('tiny_wishlist', $value , $time , '/', $_SERVER['HTTP_HOST']);
		add_option( $uniquekey, $value );
		echo 'wishliston';
	}
	else
	{
		$cookie_value = unserialize(base64_decode($_COOKIE['tiny_wishlist']));
		$value = array_merge($cookie_value, array($productid));
		if(count($value) > 21)
		{
		  echo 'no';
		}
		else
		{
			$uniquekey = $value[0];
			$value = base64_encode(serialize($value));
			setcookie('tiny_wishlist', $value , $time , '/', $_SERVER['HTTP_HOST']);
			update_option( $uniquekey, $value );
			return true;
		}
	}	
die;			
}

add_action( 'wp_ajax_wishlist_cookie', 'wp_ajax_wishlist_cookie' );
add_action( 'wp_ajax_nopriv_wishlist_cookie', 'wp_ajax_wishlist_cookie' );


function wp_ajax_remove_wishlist_cookie() 
{
	$productid = $_POST['postid'];
	$time = time()+86400*30;
	if(isset($_COOKIE["tiny_wishlist"]))
	{
		$value = unserialize(base64_decode($_COOKIE['tiny_wishlist']));
		$uniquekey = $value[0];
		if(($key = array_search($productid , $value)) !== false) {
			unset($value[$key]);
		}
		if(count($value) == 1)
		{
			   unset($_COOKIE['tiny_wishlist']);
			   setcookie("tiny_wishlist", "", time()-3600, '/', $_SERVER['HTTP_HOST']);
			   delete_option( $uniquekey );
			   echo 'wishlistremove';
		}
		else
		{
			$value = base64_encode(serialize($value));
			setcookie('tiny_wishlist', $value , $time , '/', $_SERVER['HTTP_HOST']);
			update_option( $uniquekey, $value );
		}
	}
die;			
}

add_action( 'wp_ajax_remove_wishlist_cookie', 'wp_ajax_remove_wishlist_cookie' );
add_action( 'wp_ajax_nopriv_remove_wishlist_cookie', 'wp_ajax_remove_wishlist_cookie' );


function checkproduct_wishlist($postid)
{
	if(isset($_COOKIE["tiny_wishlist"]))
	{
		$cookie_value =  unserialize(base64_decode($_COOKIE['tiny_wishlist']));
		if (in_array($postid, $cookie_value )) {
			return true;
		}
		else
		{
			return false;
		}
	}
	else
	{
		return false;
	}
}

function wishlistuniquekey()
{
	$products = unserialize(base64_decode($_COOKIE['tiny_wishlist']));
	return $uniqkey = $products[0];
}
/*
function wp_ajax_share_wishlistvia_email() 
{
	global $post;
	parse_str($_POST['data'], $output);
	$from = $output['email'];
	$responseData = '';
	if(!empty($output['g-recaptcha-response']))
	{
		$secret =  ot_get_option('G_secret_key'); //'6LcDSRgUAAAAADRKV635xdlxDv5FhHzksGVg7aEe';
		//get verify response data
		$verifyResponse = file_get_contents('https://www.google.com/recaptcha/api/siteverify?secret='.$secret.'&response='.$output['g-recaptcha-response']);
		$responseData = json_decode($verifyResponse);
	}
    if($responseData->success && !empty($output['g-recaptcha-response']))
    {
		$firstname = $output['gendertype'].' '.ucfirst($output['firstname']).' '.ucfirst($output['lastname']);
		$to_emails = array();
		//print_r($output['emailto']);
		if($output['emailto'][0] == 'tjb')
		{
			$to_emails = explode(", ",ot_get_option( 'Send_email' ));
		}
		if($output['emailto'][0] == 'friend' || $output['emailto'][1] == 'friend')
		{
			//$output['friendemail'] = explode(", ",$output['friendemail']));
			array_push($to_emails, explode(",",$output['friendemail']));
		}
		//	echo $firstname ='sakshi ranga';
		//	echo $to_emails[0] = 'sakshi.ranga@sourcefuse.com';
		
		get_template_part( 'common/wishlist', 'mailer' );
		
		include(locate_template('common/wishlist-mailer.php'));
		$headers = array('Content-Type: text/html; charset=UTF-8');
		$headers[] = 'From:'.$from;
		$subject = ot_get_option('subject');
		$to_emails = array_flatten($to_emails);
		foreach($to_emails as $to)
		{
			//echo $to;
			$mail = wp_mail( $to, $subject, $html, $headers);
		}
		if($mail)
		{
			echo ot_get_option('success_message');
		}
		else
		{
			echo ot_get_option('failed_message');
		}
	}
	else
	{
		echo 'captcha';
	}
	
die;			
}
*/
function wp_ajax_share_wishlistvia_email() 
{
	global $post;
	parse_str($_POST['data'], $output);
	$from = $output['senderemail'];
	$responseData = '';

	if(!empty($output['g-recaptcha-response']))
	{
		$secret =  ot_get_option('g_secret_key'); //'6LcDSRgUAAAAADRKV635xdlxDv5FhHzksGVg7aEe';
		//get verify response data
		$verifyResponse = file_get_contents('https://www.google.com/recaptcha/api/siteverify?secret='.$secret.'&response='.$output['g-recaptcha-response']);
		$responseData = json_decode($verifyResponse);
	}

    if($responseData->success && !empty($output['g-recaptcha-response']))
    {
		$firstname = $output['sendergendertype'].' '.ucfirst($output['senderfirstname']).' '.ucfirst($output['senderlastname']);

		$to_emails = explode(",",$output['email']);
		if(count($to_emails) == 1 )
		{
			$recname = 'Hello '.$output['gendertype'].' '.ucfirst($output['firstname']).' '.ucfirst($output['lastname']);		
		}
		else
		{
			$recname = 'Hello';
		}
		$subtitle = '<h2 style="color:#c62034; text-align:center; font-family:Times New Roman, Times, serif; font-size:16px;letter-spacing:7px; margin-top:40px;margin-bottom:20px;padding:0;">'.$firstname.' LITTLE LIST</h2><p style="color:#454449;font-size:14px; text-align:center; line-height:24px;font-family:Arial, Helvetica, sans-serif; max-width:360px; margin:0 auto 10px auto;padding:0;">'.$recname.' '.$firstname.' wants to share this collection of handpicked items from Tiny Jewel Box with you.</p>';		
		get_template_part( 'common/wishlist', 'mailer' );	
		include(locate_template('common/wishlist-mailer.php'));
		$headers = array('Content-Type: text/html; charset=UTF-8');
		$headers[] = 'From:'.$output['senderfirstname'].' '.$output['senderlastname'].' <'.$from.'>';
		$subject = ot_get_option('subject');
		//$to_emails = array_flatten($to_emails);
		foreach($to_emails as $to)
		{
			//echo $to;
			$mail = wp_mail( $to, $subject, $html, $headers);
		}
		/* Confirmation mail*/
		unset($html);unset($subtitle);
		$subject =  'Your Wishlist Has Been Sent.';
		$subtitle = '<p style="color:#454449;font-size:14px; text-align:center; line-height:24px;font-family:Arial, Helvetica, sans-serif; max-width:360px; margin:0 auto 10px auto;padding:0;">Hello '.$firstname.', <br/> Thankyou for sending out your wishlist. The following items were included on your wishlist.</p>';
		include(locate_template('common/wishlist-mailer.php'));
		$mail = wp_mail( $from, $subject, $html, $headers);
		if($mail)
		{
			echo ot_get_option('success_message');
		}
		else
		{
			echo ot_get_option('failed_message');
		}
	}
	else
	{
		echo 'captcha';
	}
	
die;			
}
add_action( 'wp_ajax_share_wishlistvia_email', 'wp_ajax_share_wishlistvia_email' );
add_action( 'wp_ajax_nopriv_share_wishlistvia_email', 'wp_ajax_share_wishlistvia_email' );



function getdesigner_name($postid)
{
	//global $post;
	$post_Designer = get_post( $postid );
	 $title = isset( $post_Designer->post_title ) ? $post_Designer->post_title : '';
	//wp_reset_query();
	return  $title;
}


/**
* Function:- wp_ajax_designer_product_pagination
**/

add_action( 'wp_ajax_designer_product', 'wp_ajax_designer_product' );
add_action( 'wp_ajax_nopriv_designer_product', 'wp_ajax_designer_product' );

function wp_ajax_designer_product()
{
		global $post;
		$args   =   array(
			'post_type'     => 'product',
			'posts_per_page' =>  8,
			'paged' => $_POST['paged'],
			'post_status' => 'publish',
			'meta_query'    => array(
				array(
					  'key' => 'product_designer',
					  'value' => $_POST['id'],
					  'compare' => '=',
					  'type' => 'NUMERIC'
				),
			)

		 );
		 $query = new WP_Query($args);
		 while ($query->have_posts()) : $query->the_post();
		 get_template_part( 'common/common', 'result' );	
		 endwhile;
		 die;
}

function product_featured_image()
{
	if(have_rows('product_gallery'))
	{
		$i=1;
		while( have_rows('product_gallery') ): the_row();
			$thumbnail_image = get_sub_field('image');
			$checkbox = get_sub_field('is_featured');
			//print_r($checkbox);
			if($i==1)
			{
			$var=$thumbnail_image;

			}
			if(!empty($checkbox))
			{
			if($checkbox[0]=="Yes"){
			$var=$thumbnail_image;
			}
			}
			$i++;
		endwhile ;
		
		$html = '<img src="'.$var.'" class="img-responsive" alt="image">';
	} 
	else
	{ 
		$html = '<img src="'.get_bloginfo('template_directory').'/images/no-image.jpg" class="img-responsive" alt="image">';	
	} 
	return $html;
}
