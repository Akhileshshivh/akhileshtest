<?php
if(get_sub_field('visitcontent')) 
{
 ?>

<section>
<div class="container">
<div class="row">
<div class="col-xs-12 custom-bridal-form">
<div class="contact-form">
    <?php if(!empty(get_sub_field('visitcontent'))) {  echo get_sub_field('visitcontent'); } ?>
</div>
</div>
</div>
</div>
</section>
  <?php } ?>
