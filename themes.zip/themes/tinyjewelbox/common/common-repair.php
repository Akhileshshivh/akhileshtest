<?php if( have_rows('repair_box') ): ?>
   <section>
  <div class="container-fluid ">
          <div class="row">
            <?php while ( have_rows('repair_box') ) : the_row(); ?>

              <div class="col-sm-7">
                  <div class="static-content">
                        <h3><?php if(!empty(get_sub_field('repair_title'))) { echo get_sub_field('repair_title'); }?></h3>
                       <?php if(!empty(get_sub_field('repair_content'))) { echo get_sub_field('repair_content'); } ?>
                       <h3><?php if(!empty(get_sub_field('service_title'))) { echo get_sub_field('service_title');} ?></h3>
                       <p><?php if(!empty(get_sub_field('service_sub_title'))) { echo get_sub_field('service_sub_title'); }?></p>
                      <?php if(have_rows('service_list')){ ?>
                       <ul>
                        <?php while ( have_rows('service_list') ) : the_row(); $lists=get_sub_field('list');
                            if(!empty($lists)):
                        ?>
                          <li><?php echo get_sub_field('list'); ?></li>
                        <?php endif; endwhile; ?>
                      </ul>
                        <?php } ?>
                        <?php if(!empty(get_sub_field('repair_button_content'))) { echo get_sub_field('repair_button_content'); } ?>

                  </div>
              </div>

              <!-- item ends -->
              <div class="col-sm-5 repair-form">
                <div class="contact-form">
                  <?php if(!empty(get_sub_field('repair_contact_form'))) {  echo get_sub_field('repair_contact_form'); } ?>
                </div>

              </div>

              <!-- item ends -->
         <?php endwhile; ?>
          </div>
          <!-- row ends -->
      </div>
      <!-- box ends -->
  </section>
<?php endif; ?>
