<?php 
if( have_rows('section_box_with_image') ): 
		while ( have_rows('section_box_with_image') ) : the_row();	 
		$section_image = get_sub_field('section_image');
		$image = $section_image['url'];
		?>
		<section>
			<div class="container-fluid inside-the-box">
				<div class="row equalizer">
					<div class="col-sm-8 tab-to-mob item">
						<div class="box-wrap">
							<div class="box-content ">
									<div class="inside-left">
									<h3><?php echo  get_sub_field('title'); ?> </h3>
									<?php if(!empty(get_sub_field('description'))) { echo get_sub_field('description'); } ?>
									</div>
							</div>
						</div>
					</div>
					<!-- item ends -->
					<div class="col-sm-4 tab-to-mob item no-pad">
						<div class="infographic">
							<figure 
							style="background-image:url('<?php if(!empty($image)) { echo $image; } else { bloginfo('template_directory'); ?>/images/diamond-bg.jpg <?php } ?> ');">
								 <?php if(!empty($image)) { ?>
									 <img src="<?php  echo $image; ?>" alt="slide" style="opacity:0;" class="img-responsive">
								 <?php } else
								 {
								 ?>
									<img src="<?php  bloginfo('template_directory'); ?>/images/sr-img.jpg " alt="slide" style="opacity:0;" class="img-responsive">
								 <?php } ?>
							</figure>
						</div>
					</div>
					<!-- item ends -->
				</div>
				<!-- row ends -->
			</div>
			<!-- box ends -->
		</section> 
		<?php 
		endwhile;
endif; 
?>
