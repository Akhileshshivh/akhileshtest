<!-- Page Static Banner -->
<section>
    <div class="container-fluid">
        <div class="row equalizer">
            <div class="col-xs-12 col-sm-8 col-md-8 item nopad-mb">
                <div class="box-wrap">
                    <div class="box-content ">
                        <div class="inner-box-content">
                            <h3><?php echo get_sub_field('box_title'); ?> </h3>
                                <?php echo get_sub_field('box_content'); ?>
                        </div>
                    </div>
                </div>
            </div>
            <!-- item ends -->
            <div class="col-xs-12 col-sm-4 col-md-4 item nopad-mb">
                <div class="contact-box">
				<?php
					if(get_sub_field('sidebar_type') == "editor" )
					{ 
						echo get_sub_field('add_content');
					}
					else
					{
							$i = 1; 
							if( have_rows('visit_us_sidebar') ):  
							while ( have_rows('visit_us_sidebar') ) : the_row();
							
								if($i == 1){ $tag = 'p'; $inner = 'b'; }else{ $tag = 'h4'; $inner = ''; }	?>
								<<?php echo $tag; ?>>
								<?php if(!empty($inner)) { echo '<'.$inner.'>'; } ?> 
								<?php echo get_sub_field('title'); ?>
								<?php if(!empty($inner)) { echo '</'.$inner.'>'; } ?> 
								</<?php echo $tag; ?>>
								<?php
								if( have_rows('content') ):  
								while ( have_rows('content') ) : the_row(); ?>
									<?php echo get_sub_field('add_text'); ?>
								<?php endwhile; endif; ?>
								<?php if((!empty(get_sub_field('custom_url'))) && (!empty(get_sub_field('label_text')))) { ?>
									<a href="<?php echo get_sub_field('custom_url'); ?>"><?php echo get_sub_field('label_text') ; ?> </a>
								<?php } ?>
	
								
						     <?php  $i++;  endwhile; endif; 
					}
				?>


                </div>
            </div>
            <!-- item ends -->
        </div>
        <!-- row ends -->
    </div>
    <!-- box ends -->
</section>

