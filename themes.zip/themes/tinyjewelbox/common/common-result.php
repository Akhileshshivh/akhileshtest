<?php 
//$image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'product-home-image');
$_product = wc_get_product( get_the_ID() );
?>
<div class="col-xs-6 col-sm-4 col-md-3 pd-adj item">
<div class="feat-prod-wrap">
<figure>
<div class="product-thumb"> 
	<a href="<?php the_permalink(); ?>">
<span class="image-wrap">
<?php
	echo product_featured_image();
?>
</span>
	<div class="product-name"><?php the_title(); ?></div>
	</a> 
</div>

</figure>
</div>
</div>
