<section>
    <div class="container">
        <div class="row equalizer">
            <div class="col-xs-12">
                <div class="custom-info">
					<?php 
					if(!empty(get_sub_field('add_shortcode')))
					{
						echo get_sub_field('add_shortcode');
					} ?>
                </div>
            </div>
        </div>
        <!-- row ends -->
    </div>
    <!-- box ends -->
</section>
