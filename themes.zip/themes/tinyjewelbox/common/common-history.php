<?php while ( have_rows('history_box') ) : the_row();	  ?>
<section class="history-timeline">
	<div class="container history-spacer">
		<div class="row">
			<div class="col-xs-12">
				<div class="history-details">
					<h1 class="designer-title"> <?php echo  get_sub_field('title'); ?> </h1>
					<p> <?php echo  get_sub_field('sub_title'); ?> </p>
				</div>
			</div>
		</div>
	</div>
</section> 
<?php if(get_sub_field('history_enable')) { ?>
	<section id="cd-timeline" class="cd-container"> 
	<div class="container" id="historytimeline">
	<?php 
		 global $post;
	 	 $args = array(
	 	 'post_type' => 'history',
	 	 'posts_per_page' => -1,
	 	 'order' => 'ASC',
	     );
	 	$history= new WP_Query( $args );
		if ( $history->have_posts() ) :
	 	while ($history->have_posts()) : $history->the_post(); ?>	
		<div class="ht-item">
			<div class="cd-timeline-content">
				<h2><?php the_title(); ?></h2>
				<?php the_content(); ?>
				<?php $image =get_the_post_thumbnail_url( $post->ID ); 
				if(! empty($image))
				{
				?>
					<figure><img src="<?php echo $image; ?>" class="img-responsive"></figure>
				<?php } ?>
			</div>
			<!-- cd-timeline-content -->
		</div>
		<?php endwhile; endif;?>
		<!-- ht-item -->
	</div>
	</section>  
<?php } ?> 
<?php endwhile; ?>
<script>
historyison = 'on';
</script>
