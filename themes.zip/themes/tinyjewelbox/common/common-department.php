<?php if( have_rows('department_team') ):
    //<!-- Page Static Banner -->

 while ( have_rows('department_team') ) : the_row();

         switch (get_sub_field('dep_section_box_width')) {

           case "col-sm-6":
           get_template_part( 'common/section', 'col50' );

         break ;
           case "col-sm-7":

        get_template_part( 'common/section', 'col40' );

           break ;
       }
        endwhile;
 endif;
 ?>
