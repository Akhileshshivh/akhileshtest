<?php
	$ii = 1;
	$j = 1;
	$loopcount = 0;
	$image_url = get_template_directory_uri();
	//$sitelogo = ot_get_option('sitelogo');	
	$html = '<table align="center" style="width:600px;" border="0" cellpadding="0" cellspacing="0">
	<tr><td colspan="4" style="width:407px; height:28px; background-color:#c62034;"></td><td style="width:193px; height:28px; background:url('.$image_url.'/mailerimages/Wishlist-Email_02.png) no-repeat;"><a href='.get_site_url().' target="_blank" style="width: 100%;display: block;height: 28px;"> </a></td> </tr> <tr> <td style="width:240px; height:140px; background:url('.$image_url.'/images/Wishlist-Email_03.png) no-repeat;"></td><td style="width:121px; height:140px; background:url('.$image_url.'/images/Wishlist-Email_04.png) no-repeat;"><a href='.get_site_url().' style="width:100%; height:140px; display:block" title="Tiny Jewelbox"></a>	</td><td colspan="3" style="width:239px; height:140px; background:url('.$image_url.'/images/Wishlist-Email_05.png) no-repeat;"></td></tr><tr><td colspan="5" style="width:600px;">
	'.$subtitle.'
	</td></tr><tr><td colspan="5" style="width:600px; height:110px; background:url('.$image_url.'/images/Wishlist-Email_07.png) no-repeat;"> </td></tr><tr><td colspan="5" style="padding:15px 20px 40px 20px;width: 100%;" ><table style="width: 100%;">';
	$products = unserialize(base64_decode($_COOKIE['tiny_wishlist']));
	$uniqkey = $products[0];
	unset($products[0]);
	$total_count = count($products);
	foreach( $products as $post) : setup_postdata($post);
	$post = get_post( $post );
	if($ii == 1){
		 $html .="<tr>"; 
		 $j = $ii + 2;
	}
	$html .="<td style='width:186px;'><a href='".get_permalink()."' title='thumb' style='text-decoration:none;display: block;border: 1px solid #f8f6f7;background: #fafafa;text-align: center;width: 162px;margin: 7px;'>";
	if(have_rows('product_gallery'))
	{
	$i=1;
	while( have_rows('product_gallery') ): the_row();
	$thumbnail_image = get_sub_field('image');
	$checkbox = get_sub_field('is_featured');
	//print_r($checkbox);
	if($i==1)
	{
	$var=$thumbnail_image;

	}
	if($checkbox[0]=='Yes'){
	$var=$thumbnail_image;
	}
	$i++;
	endwhile ;
	$html .="<img src='".$var."' class='img-responsive' title='Thumb' style='max-width:100%;'>";
	} 
	else
	{ 	
	$html .="<img src='".$image_url."/images/no-image.jpg' title='Thumb' style='max-width:100%;'>"; }
	$html .="<p style='color:#454449; text-align:center; font-family:Times New Roman, Times, serif; font-size:12px;letter-spacing:1px; text-transform:uppercase;margin: 7px 0;'>".get_the_title()."</p>
	</a></td>";
	if($j == $ii || $loopcount == $total_count)
	{
		 $html .="</tr>"; 
		 $j = 1;
		 $ii = 0;
		 
	}
	$ii++; $loopcount++;
	endforeach;
	$html .= "</table></td></tr><tr><td colspan='5' style='height:30px;width: 100%;'></td></tr>	<tr><td colspan='3' rowspan='7' style='width:399px; height:338px; background:url(".$image_url."/images/Wishlist-Email_11.png) no-repeat;'></td><td colspan='2' style='width:201px; height:100px; background:url(".$image_url."/images/Wishlist-Email_12.png) no-repeat;'></td></tr><tr><td colspan='2'  style='width:201px; height:43px; background:url(".$image_url."/images/Wishlist-Email_13.png) no-repeat;'><a href='#' title='Inside the Box' style='width: 100%;display: block;height: 43px;'> </a></td></tr><tr><td colspan='2'  style='width:201px; height:41px; background:url(".$image_url."/images/Wishlist-Email_14.png) no-repeat;'><a href='#' title='Visit The Store' style='width: 100%;display: block;height: 41px;'> </a></td></tr><tr><td colspan='2'  style='width:201px; height:41px; background:url(".$image_url."/images/Wishlist-Email_15.png) no-repeat;'><a href='#' title='Jewelry' style='width: 100%;display: block;height: 41px;'> </a></td></tr><tr><td colspan='2'  style='width:201px; height:35px; background:url(".$image_url."/images/Wishlist-Email_16.png) no-repeat;'><a href='#' title='Bridal' style='width: 100%;display: block;height: 35px;'> </a></td></tr><tr><td colspan='2'  style='width:201px; height:46px; background:url(".$image_url."/images/Wishlist-Email_17.png) no-repeat;'><a href='#' title='Watches' style='width: 100%;display: block;height: 46px;'> </a></td></tr><tr><td colspan='2'  style='width:201px; height:32px; background:url(".$image_url."/images/Wishlist-Email_18.png) no-repeat;'> </td></tr><tr><td colspan='5'  style='width:600px; height:163px; background:url(".$image_url."/images/Wishlist-Email_19.png) no-repeat;'></td></tr><tr><td width='240' height='1'>
	</td><td  width='121' height='1'></td><td  width='38' height='1'></td><td  width='8' height='1'></td><td  width='193' height='1'>
	</td></tr></table>";

?>
