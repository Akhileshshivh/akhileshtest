<?php 
if( have_rows('slider') ): 
		?>
		<section>
		<div class="container-fluid partial-slider">
			<div class="row">
			<div id="jssor_1" style="position:relative;margin:0 auto;top:0px;left:0px;width:1920px;height:1280px;overflow:hidden;visibility:hidden;">
				<div data-u="slides" style="cursor:default;position:relative;top:0px;left:0px;width:1920px;height:1280px;overflow:hidden;">
					<?php 
						while ( have_rows('slider') ) : the_row();	
						$add_slides = get_sub_field('add_slides');
						$is_video = get_sub_field('is_video');
						if(!empty($add_slides) && ($is_video == 1))
						{
						?>
							<div>
								<video width="100%" height="800" controls>
								<source src="<?php echo $add_slides; ?>" type="video/mp4">
								<source src=<?php echo $add_slides; ?>" type="video/ogg">
								</video>
							</div>
						<?php
						} 
					    else if(!empty($add_slides))
					    {
						?>	
							<div>
								<img data-u="image" src="<?php echo $add_slides; ?>" />
							</div>
					    <?php
						}
					    ?>
					<?php endwhile; ?>	
				</div>
				<!-- Arrow Navigator -->
				<span data-u="arrowleft" class="jssora13l" data-autocenter="2"></span>
				<span data-u="arrowright" class="jssora13r"  data-autocenter="2"></span>
			</div>

		<!-- #endregion Jssor Slider End -->
			</div>
			<!-- row ends -->
		</div>
		<!-- box ends -->
		</section> 
		<script>sliderison = 'yes'; </script>
		<?php 
endif; 
?>
