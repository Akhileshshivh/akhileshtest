<?php 
$products = unserialize(base64_decode($_COOKIE['tiny_wishlist']));
$uniqkey = $products[0];
unset($products[0]);
foreach( $products as $post) : setup_postdata($post);
$post = get_post( $post );
$_product = wc_get_product( $post );
?>
<div class="col-xs-6 col-sm-4 col-md-3 pd-adj item">
<div class="feat-prod-wrap">
	<figure>
	   <div class="product-thumb">
			  <div class="remove-item">
				  <a href="javascript:void(0)" title="Remove-Product" onclick="remove_Wishlist(<?php echo $post->ID ?>, 'y');">
					<img src="<?php bloginfo('template_directory'); ?>/images/close-w.png">
				  </a>
			   </div>
			   <a href="<?php the_permalink(); ?>">
				   <span class="image-wrap">
					<?php
						echo product_featured_image();
					?>		   
					</span>
					<div class="product-name"><?php the_title(); ?></div>
		   </a>
		</div>
	</figure>
</div>
<!-- feat-prod-wrap -->
</div>
<?php endforeach; ?>
