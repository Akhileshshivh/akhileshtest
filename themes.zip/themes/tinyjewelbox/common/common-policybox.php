<?php if( have_rows('policy_box') ): ?>    
<section class="silver-bg">
    <div class="container section-spacer">
	<?php while ( have_rows('policy_box') ) : the_row();	
		 $slide_image = get_sub_field('section_image');
		 $image = '';
		 if(!empty($slide_image))
		 {
			 if(!empty($slide_image['sizes']['social_bootom_box']))
			 {
				$image = $slide_image['sizes']['social_bootom_box'];
			 }
			 else
			 {
				 $image = $slide_image['url'];
			 }
		 }	
	 ?>
        <div class="row">
            <div class="small-pattern clearfix">
               <div class="col-xs-12 col-sm-2 col-md-2">
                 <div class="cat-icon">
				   <?php if(!empty($image))
				   { ?>
					   <img src="<?php echo $image; ?>" class="img-responsive"> 
				   <?php }
				   else
				   {
				   ?>
						<img src="<?php bloginfo('template_directory'); ?>/images/icon-elephant.png" class="img-responsive">  
				   <?php 
				   } ?>
                 </div><!-- cat-icon -->
                </div> 
               <div class="col-xs-12 col-sm-10 col-md-10 ">
                <div class="short-content">
                    <h3><?php echo  get_sub_field('title'); ?></h3>                   
                   <?php if(!empty(get_sub_field('description'))) {  echo  get_sub_field('description');  } ?>
                </div><!-- short-content -->
               </div>  
            </div><!-- small-pattern -->
          </div>  
      <?php endwhile; ?>    
    </div>   
</section>
<?php endif; ?>

