<?php if( have_rows('every_thing') ):
while ( have_rows('every_thing') ) : the_row(); ?>

  <section>
     <div class="container-fluid ">
         <div class="row equalizer">
           <?php while ( have_rows('our_expert') ) : the_row(); ?>
             <div class="col-sm-8 tab-to-mob peach-bg nopad-mb item">
                 <div class="box-wrap">
                     <div class="box-content ">
                         <div class="static-content">
                             <?php if(!empty(get_sub_field('text_box'))) { echo get_sub_field('text_box'); }?>
                        </div>
                     </div>
                 </div>
             </div>
             <!-- item ends -->
             <div class="col-sm-4 tab-to-mob no-pad item">
              <div class="infographic">
                <?php if(!empty(get_sub_field('expert_image'))){ ?>
                     <figure style="background-image:url('<?php echo get_sub_field('expert_image'); ?>');">
                         <a href="javascript:void(0)" title="image-name"><img src="<?php echo get_sub_field('expert_image'); ?>" alt="slide" style="opacity:0;" class="img-responsive"></a>
                     </figure>
                <?php } ?>
                 </div>
             </div>
             <!-- item ends -->
          <?php endwhile; ?>
         </div>
         <!-- row ends -->
     </div>
     <!-- box ends -->
 </section>


 <section>
   <div class="container">
     <div class="row">
      <div class="col-xs-12 faq nopad-mb">
  <div class="panel-group" id="faq" role="tablist" aria-multiselectable="true">
       <?php  $i=1; while ( have_rows('toggle_section') ) : the_row(); ?>
           <div class="panel panel-default">
             <div class="panel-heading" role="tab" id="heading<?php echo  $i; ?>">
                 <h4 class="panel-title">
                   <a role="button" data-toggle="collapse" data-parent="#faq" href="#collapse<?php echo  $i; ?>" aria-expanded="true" aria-controls="collapse<?php echo  $i; ?>">
                      <?php if(!empty(get_sub_field('title'))) { echo get_sub_field('title'); } ?> <span class="faq-icon"></span>
                   </a>
                 </h4>
             </div>
             <div id="collapse<?php echo  $i; ?>" class="panel-collapse collapse fade <?php if($i == 1){ ?>in <?php } ?>" role="tabpanel" aria-labelledby="heading<?php echo  $i; ?>">
                 <div class="panel-body">
                    <div class="col-xs-12  <?php if(!empty(get_sub_field('box_images'))){ ?> col-sm-8 <?php } ?>">
                    <?php if(!empty(get_sub_field('content_box'))) { echo get_sub_field('content_box'); } ?>
                </div>
                   <?php if(!empty(get_sub_field('box_images'))){ ?>
                  <div class="col-xs-12 col-sm-4">
                       <figure>
                        <img src="<?php echo get_sub_field('box_images'); ?>" class="img-responsive" alt="Image">
                       </figure>
                  </div>
                  <?php } ?>
                 </div>
             </div>
         </div>
      <?php  $i++; endwhile; ?>
 </div>

      </div>
     </div>
   </div>
 </section>
         <!-- Page Static Banner -->
 <section class="visible-xs silverbg">
         <div class="container section-spacer-65-b">
             <div class="clearfix">
                 <div class="col-xs-12  no-pad">
                     <div class="box-wrap">
                         <div class="box-content">
                             <h3><?php if(!empty(get_sub_field('let_us_show_title'))) { echo get_sub_field('let_us_show_title'); } ?> </h3>
                             <p><?php if(!empty(get_sub_field('let_us_show_content'))) { echo get_sub_field('let_us_show_content'); } ?></p>
                             <a href="<?php echo get_sub_field('appointment_button_url'); ?>" class="readmore-red-medium">  <?php if(!empty(get_sub_field('appointment_button_text'))) { echo get_sub_field('appointment_button_text'); } ?></a>
                         </div>
                     </div>
                 </div>
                 <!-- item ends -->

                 <!-- item ends -->
             </div>
             <!-- row ends -->
         </div>
         <!-- box ends -->
   </section>
     <!-- Scroll To Top -->


  <?php endwhile;  endif; ?>
