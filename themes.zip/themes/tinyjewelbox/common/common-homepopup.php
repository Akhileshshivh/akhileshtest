<section>

<!-- Modal -->
<div class="tjb-modal">

    <!-- GLobal Contact Modal -------->
    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <div class="modal-body">
                    <div class="modal-wrap clearfix">
                        <div class="col-xs-12 col-sm-6">
                            <div class="store-box">
                                <div class="contact-box">
                              <?php
                                  $args = array(
                              	'post_type' => 'popupsetting',
                              	'order' => 'DESC',
                                'posts_per_page'=>1);
                              $popupset = new WP_Query( $args );
                              //echo "<pre>";
                              //print_r(have_rows);
                              while ($popupset->have_posts()) : $popupset->the_post();
                              while ( have_rows('popupbox') ) : the_row();
                              $massage_title= get_sub_field('massage_box_title',$id);
                              $map_title= get_sub_field('map_box_title',$id);
                              $massage_map_title= get_sub_field('massage_and_map_box_content',$id);
                              $hour_title= get_sub_field('massage_and_map_hour_title',$id);
                              $parking_title= get_sub_field('parking_validation_title',$id);
                              $parking_conatct= get_sub_field('parking_validation_conatct',$id);
                              ?>
                              <h3><?php if(!empty($massage_title)) { echo $massage_title;} ?></h3>
                              <?php  if(!empty($massage_map_title)) { echo $massage_map_title;} ?>
                              <h4><?php echo $hour_title; ?></h4>
                              <?php while ( have_rows('monday') ) : the_row(); ?>
                              <p data-id="0"><b><?php echo get_sub_field('day_name',$id);?></b> <span class="st_time"><?php echo get_sub_field('stime_mo',$id);?></span>–<span class="ent_time"><?php echo get_sub_field('etime_mo',$id);?></span></p>
                              <?php endwhile; ?>
                              <?php while (have_rows('tuesday') ) : the_row(); ?>
                              <p data-id="1"><b><?php echo get_sub_field('day_name_tuesday',$id);?></b><span class="st_time"> <?php echo get_sub_field('stime_tu',$id);?></span>–<span class="ent_time"><?php echo get_sub_field('etime_tu',$id);?></span></p>
                              <?php endwhile; ?>
                              <?php while ( have_rows('wednesday') ) : the_row(); ?>
                              <p data-id='2'><b><?php echo get_sub_field('day_name_wednesday',$id);?></b> <span class="st_time"><?php echo get_sub_field('stime_we',$id);?></span>–<span class="ent_time"><?php echo get_sub_field('etime_we',$id);?></span></p>
                              <?php endwhile; ?>
                              <?php while ( have_rows('thursday') ) : the_row(); ?>
                              <p data-id="3"><b><?php echo get_sub_field('day_name_thus',$id);?></b> <span class="st_time"><?php echo get_sub_field('stime_thu',$id);?></span>–<span class="ent_time"><?php echo get_sub_field('etime_thu',$id);?> </span></p>
                              <?php endwhile; ?>
                              <?php while ( have_rows('friday') ) : the_row(); ?>
                              <p data-id="4"><b><?php echo get_sub_field('day_name_fr',$id);?></b> <span class="st_time"><?php echo get_sub_field('stime_fr',$id);?></span>–<span class="ent_time"><?php echo get_sub_field('etime_fr',$id);?></span</p>
                              <?php endwhile; ?>
                              <?php while ( have_rows('saturday') ) : the_row(); ?>
                              <p data-id="5"><b><?php echo get_sub_field('day_sat',$id);?></b> <span class="st_time"><?php echo get_sub_field('stime_sat',$id);?></span>–<span class="ent_time"><?php echo get_sub_field('etime_sat',$id);?></span></p>
                              <?php endwhile; ?>
                              <?php while ( have_rows('sunday') ) : the_row(); ?>
                              <p data-id="6"><b><?php echo get_sub_field('day_sunday',$id);?></b> <span class="st_time"><?php echo get_sub_field('sunday_closed',$id);?></span><span class="ent_time"><?php //echo get_sub_field('sunday_closed1',$id);?></span></p>
                              <?php endwhile; ?>
                                <div class="parking-area">
                                    <h4><?php if(!empty($parking_title)){echo $parking_title;} ?></h4>
                              <?php if(!empty($parking_conatct)) { echo $parking_conatct;} ?>
                              <?php endwhile;
                                endwhile; ?>
                                  </div>
                             </div>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-6">
                            <div class="contact-form">
                            <?php echo do_shortcode(get_option_tree( 'massage_form' ));?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- GLobal Contact Modal -------->
    <div class="modal fade" id="myModal-map" tabindex="-1" role="dialog" aria-labelledby="myModalLabels">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <div class="modal-body">
                    <div class="modal-wrap clearfix">
                        <div class="col-xs-12 col-sm-6">
                            <div class="store-box">
                                <div class="contact-box">
                                  <?php
                                    $args = array(
                                    	'post_type' => 'popupsetting',
                                    	'order' => 'DESC',
                                      'posts_per_page'=>1);
                                      $popupset = new WP_Query( $args );
                                      while ($popupset->have_posts()) : $popupset->the_post();
                                      while ( have_rows('popupbox') ) : the_row();
                                      $massage_title= get_sub_field('massage_box_title',$id);
                                      $map_title= get_sub_field('map_box_title',$id);
                                      $massage_map_title= get_sub_field('massage_and_map_box_content',$id);
                                      $hour_title= get_sub_field('massage_and_map_hour_title',$id);
                                      $parking_title= get_sub_field('parking_validation_title',$id);
                                      $parking_conatct= get_sub_field('parking_validation_conatct',$id);
                                        ?>
                                      <h3><?php if(!empty($map_title)) { echo $map_title;} ?></h3>
                                      <?php  if(!empty($massage_map_title)) { echo $massage_map_title;} ?>
                                    <!-- hour time -->
                                      <h4><?php echo $hour_title; ?></h4>
                                      <?php while ( have_rows('monday') ) : the_row(); ?>
                                      <p><b><?php echo get_sub_field('day_name',$id);?></b><?php echo get_sub_field('stime_mo',$id);?>–<?php echo get_sub_field('etime_mo',$id);?></p>
                                      <?php endwhile; ?>
                                      <?php while (have_rows('tuesday') ) : the_row(); ?>
                                      <p><b><?php echo get_sub_field('day_name_tuesday',$id);?></b><?php echo get_sub_field('stime_tu',$id);?>–<?php echo get_sub_field('etime_tu',$id);?></p>
                                      <?php endwhile; ?>
                                      <?php while ( have_rows('wednesday') ) : the_row(); ?>
                                      <p><b><?php echo get_sub_field('day_name_wednesday',$id);?></b><?php echo get_sub_field('stime_we',$id);?>–<?php echo get_sub_field('etime_we',$id);?></span></p>
                                      <?php endwhile; ?>
                                      <?php while ( have_rows('thursday') ) : the_row(); ?>
                                      <p><b><?php echo get_sub_field('day_name_thus',$id);?></b><?php echo get_sub_field('stime_thu',$id);?>–<?php echo get_sub_field('etime_thu',$id);?></p>
                                      <?php endwhile; ?>
                                      <?php while ( have_rows('friday') ) : the_row(); ?>
                                      <p><b><?php echo get_sub_field('day_name_fr',$id);?></b><?php echo get_sub_field('stime_fr',$id);?>–<?php echo get_sub_field('etime_fr',$id);?></p>
                                      <?php endwhile; ?>
                                      <?php while ( have_rows('saturday') ) : the_row(); ?>
                                      <p><b><?php echo get_sub_field('day_sat',$id);?></b><?php echo get_sub_field('stime_sat',$id);?>–<?php echo get_sub_field('etime_sat',$id);?></p>
                                      <?php endwhile; ?>
                                      <?php while ( have_rows('sunday') ) : the_row(); ?>
                                      <p><b><?php echo get_sub_field('day_sunday',$id);?></b><?php echo get_sub_field('sunday_closed',$id);?><?php //echo get_sub_field('sunday_closed1',$id);?></p>
                                      <?php endwhile; ?>
                                        <div class="parking-area">
                                            <h4><?php if(!empty($parking_title)){echo $parking_title;} ?></h4>
                                      <?php if(!empty($parking_conatct)) { echo $parking_conatct;} ?>
                                      <?php endwhile;
                                        endwhile; ?>
                                       </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-6">
                          <div class="Google-map">

                              <?php echo do_shortcode(get_option_tree( 'map_area' ));?>
                          </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

</section>
<script>
          /*********** datepicker ****/
          jQuery( document ).ready( function($){
        
            jQuery('.modal').on('hidden.bs.modal', function(){
                jQuery(this).find('form')[0].reset();
                  jQuery('#datepicker_10').html('<option>--</option>');
                  jQuery('.wpcf7-response-output,.wpcf7-mail-sent-ng').hide();
                });
            var weekday=new Array(7);
           weekday[0]="monday";
           weekday[1]="tuesday";
           weekday[2]="wednesday";
           weekday[3]="thursday";
           weekday[4]="friday";
           weekday[5]="saturday";
           weekday[6]="sunday";
           jQuery("#datepicker_12").datepicker({
           minDate: 0,
           onSelect: function (date, dayNamesMin) {
           var date = jQuery(this).datepicker('getDate');
          // var dayOfWeek = weekday[date.getUTCDay()];
          //console.log('dayOfWeek:', dayOfWeek);
          var timePIcker = jQuery('#datepicker_10');
          var dayNo = date.getUTCDay();
          var intervalT = "30";
          //l.setMinutes(l.getMinutes()+30);
          //var tolowerCase = dayOfWeek
          //alert("[data-id='"+dayNo+"']");;
           var stTime = jQuery("[data-id='"+dayNo+"']").find('.st_time').text().trim().toLowerCase();
           var etTime = jQuery("[data-id='"+dayNo+"']").find('.ent_time').text().trim().toLowerCase();
           //console.log([stTime, etTime]);
           function convertTo24Hour(time) {
               var hours = parseInt(time.substr(0, 2));
               if(time.indexOf('am') != -1 && hours == 12) {
                   time = time.replace('12', '0');
               }
               if(time.indexOf('pm')  != -1 && hours < 12) {
                   time = time.replace(hours, (hours + 12));
               }
               return time.replace(/(am|pm)/, '');
           }
           console.log([stTime, etTime]);
           function timeDisplay(stTime, etTime, intervalT) {
             var count = (stTime.match(/AM/g) || stTime.match(/am/g) || stTime.match(/PM/g) || stTime.match(/pm/g) || []).length;
             console.log(stTime, ' count====> ', count);
             if(parseInt(count) > 0) {
               var stTime = convertTo24Hour(stTime);
               var etTime = convertTo24Hour(etTime);
               /************* start time **********************/
               var l = new Date();
               var times = stTime.split(':');
               var h = (times[0]);
               var m = (times[1]) ? times[1]:0;
               l.setHours(h);
               l.setMinutes(m);
              /************* end time **********************/
               var enT = new Date();
               var enTimes = etTime.split(':');
               var eh = (enTimes[0]);
               var em = (enTimes[1]) ? enTimes[1]:0;
               enT.setMinutes(em);
               enT.setHours(eh);

                var timeStrig = '';
                var currTime = l;
                //console.log([l, enT]);
                $('#datepicker_10').empty();
                var optionHtml = '';
                while(l.getTime() <= enT.getTime()) {
                  //console.log(l.getMinutes());
                  var hours = (l.getHours() % 12 || 12);
                  hours = parseInt(hours) < 10 ? ('0' + hours) : hours;
                  var minute = parseInt(l.getMinutes()) < 10 ? ('0' + l.getMinutes()) : l.getMinutes();
                  var ampm = l.getHours() >= 12 ? 'PM':'AM';
                  var temps = [hours, minute].join(':') +ampm;
                  l.setMinutes(l.getMinutes()+parseInt(intervalT));
                  optionHtml += "<option value='"+temps+"'>"+temps+"</option>";
                }
                $('#datepicker_10').html(optionHtml);
             } else {
                $('#datepicker_10').html("<option value='"+stTime+"'>"+stTime+"</option>");
             }

            }
            timeDisplay(stTime, etTime, intervalT);

            }
           });
          });
</script>
