<?php 
if(get_sub_field('menu_enable_'))
{
 ?>
<div class="container-fluid">
    <div class="row">
        <div class="inner-nav">
            <div class="box global">
                <input type="checkbox" name="accordion-2" id="ac-menu-inner">
                <label for="ac-menu-inner"><span>NAVIGATION</span></label>
                <div class="inner-nav accordian">
				<?php
				   if(!empty(get_sub_field('menu_name')))
				   {
					   wp_nav_menu(array('menu' => get_sub_field('menu_name'), 'container' => 'ul', 'container_class' => '')); 
				   }
				   else
				   {
						wp_nav_menu(array('theme_location' => 'SocialMenu', 'container' => 'ul', 'container_class' => '')); 
				   }
                ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php } ?>
