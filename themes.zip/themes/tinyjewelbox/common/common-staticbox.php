<?php if( have_rows('slider_static_box') ): 
 while ( have_rows('slider_static_box') ) : the_row();	
 $slide_image = get_sub_field('banner_image');
 $background_color_for_box = get_sub_field('background_color_for_box');
 $font_color = get_sub_field('font_color');
 $image = '';
 if(!empty($slide_image))
 {
	 if(!empty($slide_image['sizes']['col-sm-8']))
	 {
		$image = $slide_image['sizes']['col-sm-8'];
	 }
	 else
	 {
		 $image = $slide_image['url'];
	 }
 }
 ?>
<section>
    <div class="container-fluid">
        <div class="row equalizer">
            <div class="col-sm-8 col-sm-push-4 item no-pad">
                <div class="infographic">
                    <figure style="background-image:url('<?php if(!empty($image)) { echo $image; } else { bloginfo('template_directory'); ?>/images/sr-img.jpg <?php } ?> ');">
						 <?php if(!empty($image)) { ?>
							 <img src="<?php  echo $image; ?>" alt="slide" style="opacity:0;" class="img-responsive">
						 <?php } else
						 {
						 ?>
							<img src="<?php  bloginfo('template_directory'); ?>/images/sr-img.jpg " alt="slide" style="opacity:0;" class="img-responsive">
						 <?php } ?>
                    </figure>
                </div>
            </div>
            <!-- item ends -->
            <div class="col-sm-4 col-sm-pull-8 item  darkgrey-bg no-pad" <?php if(!empty($background_color_for_box)){ ?> style="background: <?php echo $background_color_for_box; ?> none repeat scroll 0 0;" <?php } ?>>
                <div class="box-wrap">
                    <div class="box-content">
                        <h2 <?php if(!empty($font_color)){ ?>style="color:<?php echo $font_color;?>"<?php } ?>><?php echo  get_sub_field('title'); ?> </h2>
                        <?php if(!empty(get_sub_field('sub_title'))) { ?><h3 <?php if(!empty($font_color)){ ?>style="color:<?php echo $font_color;?>"<?php } ?>><?php echo  get_sub_field('sub_title'); ?></h3> <?php } ?>
                    </div>
                </div>
            </div>
            <!-- item ends -->
        </div>
        <!-- row ends -->
    </div>
    <!-- box ends -->
</section>
<?php 
	
	endwhile; 
	endif; 
?>
