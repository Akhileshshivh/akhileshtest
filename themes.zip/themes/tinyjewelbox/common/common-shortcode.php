<?php 
if(!empty(get_sub_field('add_shortcode')))
{
	echo get_sub_field('add_shortcode');
}
//die;

