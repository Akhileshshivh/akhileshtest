<section>
    <div class="container">
         <div class="row">
            <div class="col-xs-12 faq-wrap">
                <div class="question">
                  <?php $question = ot_get_option('question_title');	if(!empty(question_title)){?>
                    <h3><?php echo $question;?></h3>
                    <?php } ?>
                   <ul>
                     <?php
                       $i=1;
                        $args = array(
                        'post_type' => 'faq',
                        'posts_per_page' => -1,
                        'order' => 'DESC'
                       );
                       $faqid= new WP_Query( $args );
                       if ( $faqid->have_posts() ) :
                     $i=1;  while ($faqid->have_posts()) : $faqid->the_post();
                     ?>
                     <li><a href="#answer<?php echo  $i; ?>" id="question<?php echo  $i; ?>" title="Question">
                       <?php  if(!empty(get_the_title($ID))){ echo get_the_title($ID); } ?><i class="q-right pull-right" aria-hidden="true"></i></a>
                     </li>
                      <?php $i++; endwhile; endif; ?>
                   </ul>
                </div>

            </div>
        </div>
        <!-- row ends -->
    </div>
    <!-- box ends -->
</section>
