
 <section>
	<div class="container-fluid">
			<div class="row equalizer">
						<div class="col-sm-7 item col-sm-push-5 silver-2">
							<div class="box-wrap">
									<div class="box-content ">
											<div class="department-right">
												 <?php
													$cat_id1= get_sub_field('category_name',$id);
													$term_id1 = get_term( $cat_id1, $taxonomy );
													$cat_name = $term_id1->name;
												 ?>
													<h3> <?php echo $cat_name; ?>:</h3>
												 <?php
													$posts14 = get_posts(array('post_type' => 'teammembers', 'posts_per_page' => -1,'tax_query' => array(array('taxonomy' => 'TeamMembers_cat', 'terms'=>$cat_id1))));
													foreach ($posts14 as $postvalues) {
												 ?>
													<p><b><?php echo $postvalues->post_title; ?></b>
                            <?php if(!empty($postvalues->post_content)){ ?>|
                            <?php echo $postvalues->post_content?>
                            <?php } ?>
                          </p>
												<?php	} ?>
											</div>
									</div>
							</div>
					</div>
					<!-- item ends -->
					<div class="col-sm-5 col-sm-pull-7 item no-pad">
							<div class="infographic">
								<figure style="background-image:url('<?php  echo get_sub_field('category_image',$id);?>');">
											<a href="javascript:void(0)" title="image-name"><img src="<?php echo get_sub_field('category_image',$id);?>" alt="<?php the_sub_field('title'); ?>" style="opacity:0;" class="img-responsive"></a>
								</figure>
						 </div>
					</div>
					<!-- item ends -->
			</div>
			<!-- row ends -->
	</div>
	<!-- box ends -->
 </section>
