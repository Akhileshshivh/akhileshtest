<section>
 <div class="container-fluid">
		 <div class="row equalizer">
			 <div class="col-sm-6 item">
						 <div class="box-wrap">
								 <div class="box-content ">
										<div class="department-left">
    											 <?php
    													 $cat_id= get_sub_field('category_name',$id);
    													 $term_id = get_term( $cat_id, $taxonomy );
    													 $cat_name = $term_id->name;
    											 ?>
    												 <h3> <?php echo $cat_name; ?>:</h3>
    											 <?php
    													 $posts14 = get_posts(array('post_type' => 'teammembers', 'posts_per_page' => -1,'tax_query' => array(array('taxonomy' => 'TeamMembers_cat', 'terms'=>$cat_id))));
    													 foreach ($posts14 as $postvalue) { ?>
    													 <p><b><?php echo $postvalue->post_title; ?></b>
                               <?php if(!empty($postvalue->post_content)){ ?>|
                               <?php echo $postvalue->post_content; ?>
                               <?php } ?>
                              </p>
    											 <?php } ?>
										</div>
								 </div>
						 </div>
				 </div>
				 <!-- item ends -->
				 <div class="col-sm-6 item no-pad">
						 <div class="infographic">
  							 <figure style="background-image:url('<?php  echo get_sub_field('category_image',$id);?>');">
  										 <a href="javascript:void(0)" title="image-name"><img src="<?php echo get_sub_field('category_image',$id);?>" alt="<?php the_sub_field('title'); ?>" style="opacity:0;" class="img-responsive"></a>
  								</figure>
  					</div>
				 </div>
				 <!-- item ends -->

		 </div>
		 <!-- row ends -->
 </div>
 <!-- box ends -->
</section>
