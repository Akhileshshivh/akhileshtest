<?php 
if( have_rows('slider') ): 
?>
<section>
 <div class="clearfix">
    <div class="custom-products-slider">
    <ul id="customrelatedslider" class="owl-carousel">
	<?php 
		while ( have_rows('slider') ) : the_row();	
		$add_slides = get_sub_field('add_slides');
		$is_video = get_sub_field('is_video');
		if(!empty($add_slides) && ($is_video == 1))
		{
		?>
			<li class="c-slide-item">
				<video width="100%" height="800" controls>
				<source src="<?php echo $add_slides; ?>" type="video/mp4">
				<source src=<?php echo $add_slides; ?>" type="video/ogg">
				</video>
			</li>
		<?php
		} 
		else if(!empty($add_slides))
		{
		?>	
        <li class="c-slide-item">
            <figure class="c-product"><a href="#" title="image"> <img src="<?php echo $add_slides; ?>" class="img-responsive" alt="image-name"></a></figure>
        </li>
		<?php
		}
		?>
	<?php endwhile; ?>	       
    </ul>
</div>
 </div>    
</section>
<?php endif; ?>
