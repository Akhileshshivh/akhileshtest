<?php 
		//	while(have_posts()):the_post();
//		echo $post->ID;
				if($counter > 0 && ($counter % $sectionOne) == 0) { ?>
					<?php if($viewType == 0) { ?>
								</div>
							</div>
						</div>
						<div class="col-xs-6 col-sm-6 col-md-6 item">
							<div class="row">
								<div class="col-xs-12 big-box">
					<?php }	?>
					<?php }	?>
					<?php if($counter == 0) { ?>
						<?php if($viewType == 0) { ?>
							<div class="col-xs-12 col-sm-6 col-md-6 item">
								<div class="row">
									<div class="clearfix">
						<?php } else { ?>
							<div class="col-xs-6 col-sm-6 col-md-6 item">
								<div class="row">
									<div class="col-xs-12 big-box">
						<?php }	?>
					<?php }	?>
								<?php if((($counter % $sectionOne != 0 || $counter == 0) && $viewType == 0) ||
									($counter % ($sectionTwo+$sectionOne) != 0 && $viewType == 1)) { ?>
									<div class="col-xs-6 col-sm-6 pd-adj">
								<?php } ?>
									<div class="feat-prod-wrap">
										<figure>
											<div class="product-thumb"> <a href="<?php the_permalink(); ?>">
                                                <span class="image-wrap">
												<?php
													echo product_featured_image();
												?>
												</span>
												<div class="product-name"><?php the_title(); ?></div>
												</a>
											</div>
											<div class="product-details">
												<div class="product-brief">
													<p><?php echo get_excerpt(); ?></p>
														<!-- Price, author   Section -->
													<div class="price-author"><span class="price">
												<?php $_product = new WC_Product(get_the_ID());
												 echo wc_price($_product->get_price_including_tax(1,$_product->get_price()));?></span> 
												  <?php if(!empty(get_field('product_designer'))) { ?>
												 | <span class="author">By <?php echo getdesigner_name(get_field('product_designer')); ?> 
												 <?php } ?>
												 </span></div>
												</div>
											
												<a href="<?php the_permalink(); ?>" title="View More" class="readmore-red">View More</a>
												
											</div>
										</figure>
									</div>
								<?php if((($counter % $sectionOne != 0 || $counter == 0) && $viewType == 0) ||
									(($counter % $sectionTwo != 0 ||  $counter > 0)&& $viewType == 1)) { ?>
									</div>
								<?php }	?>
								<?php if($counter%4 == 0 && $counter > 0) { ?>
											</div>
										</div>
									</div>
								<?php }	?>
								<?php  if($counter == 0 && $viewType == 1) 
								     {   ?>
													</div>
												</div>
											</div>
									
											<div class="col-xs-12 col-sm-6 col-md-6 item">
												<div class="row">
													<div class="clearfix">
								<?php 
									 }	 ?>
										<?php $counter++; ?>
								<?php if(($counter % ($sectionOne + $sectionTwo) == 0) && $counter > 0) { ?>
									<?php
										$temp = $sectionOne;
										$sectionOne = $sectionTwo;
										$sectionTwo = $temp;
										$viewType = ($viewType == 0 ? 1 : 0);
										$counter = 0;
									?>
										
								<?php 
							  }
								 $post_count++;
							  if(($total_no_post)<$post_count)
								{  ?>
								      </div></div></div>
								 <?php }
			//					endwhile;
								
								//exit();
									?>
